import { Base64 } from 'js-base64';
import _ from 'lodash';
import $ from '@/core/app';
import { ENV } from '@/vendor/open-api';
import { failed, success } from '@/restful/response';
import { updateArtifactStore } from '@/restful/settings';
import resourceCache from '@/utils/resource-cache';
import scriptResourceCache from '@/utils/script-resource-cache';
import headersResourceCache from '@/utils/headers-resource-cache';
import {
    GIST_BACKUP_FILE_NAME,
    GIST_BACKUP_KEY,
    SETTINGS_KEY,
} from '@/constants';
import { InternalServerError, RequestInvalidError } from '@/restful/errors';
import Gist from '@/utils/gist';
import migrate from '@/utils/migration';
import env from '@/utils/env';
import { formatDateTime } from '@/utils';
import {
    AGE_SECRET_KEY,
    decryptArmorIfPresent,
    derivePublicKey,
    encryptArmor,
    isAgeArmor,
} from '@/utils/age';

const GIST_TOKEN_PATH = 'settings.gistToken';
const GIST_DOWNLOAD_TOKEN_STRATEGY_PATH = 'settings.gistDownloadTokenStrategy';

export default function register($app) {
    // utils
    $app.get('/api/utils/env', getEnv); // get runtime environment
    $app.get('/api/utils/backup', gistBackup); // gist backup actions
    $app.get('/api/utils/refresh', refresh);

    // Storage management
    $app.route('/api/storage')
        .get((req, res) => {
            res.set('content-type', 'application/json')
                .set('access-control-expose-headers', 'content-disposition')
                .set(
                    'content-disposition',
                    `attachment; filename="${encodeURIComponent(
                        `sub-store_data_${formatDateTime(new Date())}.json`,
                    )}"`,
                )
                .send(
                    $.env.isNode
                        ? JSON.stringify($.cache)
                        : $.read('#sub-store'),
                );
        })
        .post((req, res) => {
            try {
                let { content } = req.body;
                try {
                    content = JSON.parse(Base64.decode(content));
                    if (!(Object.keys(content.settings).length >= 0)) {
                        throw new Error('备份文件应该至少包含 settings 字段');
                    }
                } catch (err) {
                    try {
                        content = JSON.parse(content);
                        if (!(Object.keys(content.settings).length >= 0)) {
                            throw new Error(
                                '备份文件应该至少包含 settings 字段',
                            );
                        }
                    } catch (err) {
                        $.error(
                            `备份文件校验失败, 无法还原\nReason: ${
                                err.message ?? err
                            }`,
                        );
                        throw new Error('备份文件校验失败, 无法还原');
                    }
                }
                $.write(JSON.stringify(content, null, `  `), '#sub-store');
                if ($.env.isNode) {
                    $.cache = content;
                    $.persistCache();
                }
                migrate();
                success(res);
            } catch (e) {
                $.error(
                    `Failed to restore backup data.\nReason: ${e.message ?? e}`,
                );
                failed(
                    res,
                    new RequestInvalidError(
                        'INVALID_BACKUP_DATA',
                        'Invalid backup data, failed to restore!',
                        `Reason: ${e.message ?? e}`,
                    ),
                );
            }
        });

    if (ENV().isNode) {
        $app.get('/', getEnv);
    } else {
        // Redirect sub.store to vercel webpage
        $app.get('/', async (req, res) => {
            // 302 redirect
            res.set('location', 'https://sub-store.vercel.app/')
                .status(302)
                .end();
        });
    }

    // handle preflight request for QX
    if (ENV().isQX) {
        $app.options('/', async (req, res) => {
            res.status(200).end();
        });
    }

    $app.all('/', (_, res) => {
        res.send('Hello from sub-store, made with ❤️ by Peng-YM');
    });
}

function getEnv(req, res) {
    env.feature = env.feature || {};
    env.feature.archive = true;
    if (req.query.share) {
        env.feature.share = true;
    }
    res.set('Content-Type', 'application/json;charset=UTF-8').send(
        JSON.stringify(
            {
                status: 'success',
                data: {
                    guide: '⚠️⚠️⚠️ 您当前看到的是后端的响应. 若想配合前端使用, 可访问官方前端 https://sub-store.vercel.app 后自行配置后端地址, 或一键配置后端 https://sub-store.vercel.app?api=https://a.com/xxx (假设 https://a.com 是你后端的域名, /xxx 是自定义路径). 需注意 HTTPS 前端无法请求非本地的 HTTP 后端(部分浏览器上也无法访问本地 HTTP 后端). 请配置反代或在局域网自建 HTTP 前端. 如果还有问题, 可查看此排查说明: https://telegram.me/zhetengsha/1068',
                    ...env,
                },
            },
            null,
            2,
        ),
    );
}

async function refresh(_, res) {
    // 1. get artifact store
    // await updateAvatar();
    await updateArtifactStore();

    // 2. clear resource cache
    resourceCache.revokeAll();
    scriptResourceCache.revokeAll();
    headersResourceCache.revokeAll();
    success(res);
}

function readCurrentBackupContent() {
    let content = $.read('#sub-store');
    content = content ? JSON.parse(content) : {};
    if ($.env.isNode) content = JSON.parse(JSON.stringify($.cache));
    return content;
}

function serializeGistBackupContent(content, encoding, options = {}) {
    const backup = JSON.parse(JSON.stringify(content || {}));
    if (!options.keepAgeSecretKey && backup.settings?.[AGE_SECRET_KEY]) {
        delete backup.settings[AGE_SECRET_KEY];
    }
    if (encoding === 'plaintext') {
        backup.settings = backup.settings || {};
        backup.settings.gistToken = '恢复后请重新设置 GitHub Token';
        return JSON.stringify(backup, null, `  `);
    }

    return Base64.encode(JSON.stringify(backup, null, `  `));
}

function normalizeGistBackupEncoding(encoding) {
    return ['base64', 'plaintext', 'age'].includes(encoding)
        ? encoding
        : 'base64';
}

function getGistBackupPayloadEncoding(encoding) {
    return encoding === 'plaintext' ? 'plaintext' : 'base64';
}

function isAgeGistBackupEncoding(encoding) {
    return encoding === 'age';
}

async function encryptGistBackupContent(content, settings, encoding) {
    if (!isAgeGistBackupEncoding(encoding)) return content;

    const ageSecretKey = settings?.[AGE_SECRET_KEY];
    if (!ageSecretKey) {
        throw new Error('age 加密模式需要配置 age 解密私钥');
    }

    $.info(`使用 age 加密 Gist 备份内容`);
    return encryptArmor(content, await derivePublicKey(ageSecretKey));
}

async function decryptGistBackupContent(content, settings, encoding) {
    if (!isAgeGistBackupEncoding(encoding)) return content;

    const ageSecretKey = settings?.[AGE_SECRET_KEY];
    if (!ageSecretKey) {
        throw new Error('age 加密模式需要配置 age 解密私钥');
    }

    $.info(`尝试使用 age 解密 Gist 备份内容`);
    return decryptArmorIfPresent(content, ageSecretKey);
}

function resolveGistDownloadTokenStrategy(storedStrategy, queryStrategy, keep) {
    if (queryStrategy !== undefined) {
        if (queryStrategy !== 'overwrite' && queryStrategy !== 'keep') {
            throw new RequestInvalidError(
                'INVALID_GIST_DOWNLOAD_TOKEN_STRATEGY',
                'Token 处理方式仅支持 overwrite 或 keep',
            );
        }
        return queryStrategy;
    }

    if (keep !== undefined) {
        return String(keep).split(',').includes(GIST_TOKEN_PATH)
            ? 'keep'
            : 'overwrite';
    }

    return storedStrategy === 'keep' ? 'keep' : 'overwrite';
}

async function gistBackupAction(
    action,
    { keep, encode, tokenStrategy: queryTokenStrategy } = {},
) {
    const settings = $.read(SETTINGS_KEY) || {};
    const { gistToken, syncPlatform } = settings;
    if (!gistToken) throw new Error('GitHub Token is required for backup!');

    const gist = new Gist({
        token: gistToken,
        key: GIST_BACKUP_KEY,
        syncPlatform,
    });
    let currentContent = readCurrentBackupContent();
    let content;
    const updated = settings.syncTime;

    const encoding = normalizeGistBackupEncoding(
        encode || settings.gistUpload || 'base64',
    );
    const tokenStrategy =
        action === 'download'
            ? resolveGistDownloadTokenStrategy(
                  settings.gistDownloadTokenStrategy,
                  queryTokenStrategy,
                  keep,
              )
            : undefined;
    $.info(
        `Gist backup action: ${action}, keep: ${keep}, token strategy: ${queryTokenStrategy}, settings token strategy: ${settings.gistDownloadTokenStrategy}, final token strategy: ${tokenStrategy}, encode: ${encode}, settings encode: ${settings.gistUpload}, final encoding: ${encoding}`,
    );
    switch (action) {
        case 'upload':
            let backupContent;
            try {
                const keepAgeSecretKey = isAgeGistBackupEncoding(encoding);

                backupContent = serializeGistBackupContent(
                    readCurrentBackupContent(),
                    getGistBackupPayloadEncoding(encoding),
                    { keepAgeSecretKey },
                );

                $.info(`下载备份, 与本地内容对比...`);

                const downloadedContent = await gist.download(
                    GIST_BACKUP_FILE_NAME,
                );

                const onlineContent = await decryptGistBackupContent(
                    downloadedContent,
                    settings,
                    encoding,
                );

                const canReuseOnlineContent =
                    !isAgeGistBackupEncoding(encoding) ||
                    isAgeArmor(downloadedContent);

                if (canReuseOnlineContent && onlineContent === backupContent) {
                    $.info(`内容一致, 无需上传备份`);
                    return;
                }
            } catch (error) {
                $.error(`${error.message ?? error}`);
            }

            // update syncTime
            settings.syncTime = new Date().getTime();
            $.write(settings, SETTINGS_KEY);

            // 重新生成，避免前面的逻辑改变了状态
            backupContent = serializeGistBackupContent(
                readCurrentBackupContent(),
                getGistBackupPayloadEncoding(encoding),
                {
                    keepAgeSecretKey: isAgeGistBackupEncoding(encoding),
                },
            );

            const uploadContent = await encryptGistBackupContent(
                backupContent,
                settings,
                encoding,
            );

            $.info(`上传备份中...`);
            await $.wait(100);
            try {
                await gist.upload(
                    {
                        [GIST_BACKUP_FILE_NAME]: {
                            content: uploadContent,
                        },
                    }
                );

                $.info(`上传备份完成`);
            } catch (err) {
                $.error(`上传请求异常: ${err?.message ?? err}`);

                /*
                 * PATCH 可能已经成功，
                 * 只是没有收到 callback。
                 *
                 * 因此先重新 GET 确认。
                 */
                try {
                    $.info(`重新获取备份, 确认上传结果...`);
                    await $.wait(500);
                    const downloadedContent = await gist.download(
                        GIST_BACKUP_FILE_NAME,
                        gists,
                    );

                    const onlineContent = await decryptGistBackupContent(
                        downloadedContent,
                        settings,
                        encoding,
                    );

                    const canReuseOnlineContent =
                        !isAgeGistBackupEncoding(encoding) ||
                        isAgeArmor(downloadedContent);

                    if (
                        canReuseOnlineContent &&
                        onlineContent === backupContent
                    ) {
                        $.info(`线上内容与本次上传内容一致, 上传实际已成功`);

                        break;
                    }

                    $.error(`线上内容与本次上传内容不一致, 上传确认失败`);
                } catch (verifyError) {
                    $.error(
                        `上传结果确认失败: ${
                            verifyError?.message ?? verifyError
                        }`,
                    );
                }

                settings.syncTime = updated;
                $.write(settings, SETTINGS_KEY);
                throw err;
            }
            break;
        case 'download': {
            $.info(`还原备份中...`);
            content = await gist.download(GIST_BACKUP_FILE_NAME);
            content = await decryptGistBackupContent(
                content,
                settings,
                encoding,
            );
            try {
                content = JSON.parse(Base64.decode(content));
                if (!(Object.keys(content.settings).length >= 0)) {
                    throw new Error('备份文件应该至少包含 settings 字段');
                }
            } catch (err) {
                try {
                    content = JSON.parse(content);
                    if (!(Object.keys(content.settings).length >= 0)) {
                        throw new Error('备份文件应该至少包含 settings 字段');
                    }
                } catch (err) {
                    $.error(
                        `Gist 备份文件校验失败, 无法还原\nReason: ${
                            err.message ?? err
                        }`,
                    );
                    throw new Error('Gist 备份文件校验失败, 无法还原');
                }
            }
            const keepPaths = keep
                ? String(keep)
                      .split(',')
                      .map((path) => path.trim())
                      .filter(Boolean)
                : [];
            const tokenPathIndex = keepPaths.indexOf(GIST_TOKEN_PATH);
            if (tokenStrategy === 'keep' && tokenPathIndex === -1) {
                keepPaths.push(GIST_TOKEN_PATH);
            } else if (tokenStrategy === 'overwrite' && tokenPathIndex !== -1) {
                keepPaths.splice(tokenPathIndex, 1);
            }
            if (!keepPaths.includes(GIST_DOWNLOAD_TOKEN_STRATEGY_PATH)) {
                keepPaths.push(GIST_DOWNLOAD_TOKEN_STRATEGY_PATH);
            }
            $.info(`保留原有设置 ${keepPaths}`);
            keepPaths.forEach((path) => {
                if (_.has(currentContent, path)) {
                    _.set(content, path, _.get(currentContent, path));
                } else {
                    _.unset(content, path);
                }
            });
            // restore settings
            $.write(JSON.stringify(content, null, `  `), '#sub-store');
            if ($.env.isNode) {
                $.cache = content;
                $.persistCache();
            }
            $.info(`perform migration after restoring from gist...`);
            migrate();
            $.info(`migration completed`);
            $.info(`还原备份完成`);
            break;
        }
    }
}
async function gistBackup(req, res) {
    const { action, keep, encode, tokenStrategy } = req.query;
    // read token
    const { gistToken } = $.read(SETTINGS_KEY) || {};
    if (!gistToken) {
        failed(
            res,
            new RequestInvalidError(
                'GIST_TOKEN_NOT_FOUND',
                `GitHub Token is required for backup!`,
            ),
        );
    } else {
        try {
            await gistBackupAction(action, {
                keep,
                encode,
                tokenStrategy,
            });
            success(res);
        } catch (err) {
            $.error(
                `Failed to ${action} gist data.\nReason: ${err.message ?? err}`,
            );
            failed(
                res,
                err instanceof RequestInvalidError
                    ? err
                    : new InternalServerError(
                          'BACKUP_FAILED',
                          `Failed to ${action} gist data!`,
                          `Reason: ${err.message ?? err}`,
                      ),
            );
        }
    }
}

export { gistBackupAction };
