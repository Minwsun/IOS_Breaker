import { expect } from 'chai';
import { after, before, beforeEach, describe, it } from 'mocha';

import {
    SETTINGS_KEY,
    SUBS_KEY,
    TOKENS_KEY,
} from '@/constants';

let $;
let createTokenItem;
let consumeShareToken;
let findShareToken;
let state;
let originalRead;
let originalWrite;
let originalInfo;
let originalError;
let ageUtils;

describe('token routes', function () {
    before(async function () {
        ({ default: $ } = require('@/core/app'));
        ({ createTokenItem, consumeShareToken, findShareToken } = require(
            '@/restful/token'
        ));
        ageUtils = require('@/utils/age');

        originalRead = $.read.bind($);
        originalWrite = $.write.bind($);
        originalInfo = $.info.bind($);
        originalError = $.error.bind($);
    });

    after(function () {
        if ($) {
            $.read = originalRead;
            $.write = originalWrite;
            $.info = originalInfo;
            $.error = originalError;
        }
    });

    beforeEach(function () {
        state = {
            [SUBS_KEY]: [{ name: 'shared-sub' }],
            [TOKENS_KEY]: [],
            [SETTINGS_KEY]: {},
        };

        $.read = (key) => state[key];
        $.write = (data, key) => {
            state[key] = data;
            return true;
        };
        $.info = () => {};
        $.error = () => {};
    });

    it('stores exact datetime shares without converting them to expiresIn', function () {
        const exp = Date.now() + 5 * 60 * 1000;

        const token = createTokenItem(
            {
                type: 'sub',
                name: 'shared-sub',
                token: 'datetime-token',
            },
            {
                mode: 'datetime',
                exp,
            },
        );

        expect(token.token).to.equal('datetime-token');
        expect(token.mode).to.equal('datetime');
        expect(token.exp).to.equal(exp);
        expect(token).to.not.have.property('expiresIn');
        expect(state[TOKENS_KEY][0].mode).to.equal('datetime');
        expect(state[TOKENS_KEY][0].exp).to.equal(exp);
    });

    it('allows exact datetime shares in the past', function () {
        const exp = Date.now() - 5 * 60 * 1000;

        const token = createTokenItem(
            {
                type: 'sub',
                name: 'shared-sub',
                token: 'expired-token',
            },
            {
                mode: 'datetime',
                exp,
            },
        );

        expect(token.mode).to.equal('datetime');
        expect(token.exp).to.equal(exp);
        expect(state[TOKENS_KEY]).to.have.length(1);
    });

    it('rejects invalid exact datetime shares', function () {
        let capturedError;

        try {
            createTokenItem(
                {
                    type: 'sub',
                    name: 'shared-sub',
                    token: 'bad-token',
                },
                {
                    mode: 'datetime',
                    exp: 'not-a-timestamp',
                },
            );
        } catch (error) {
            capturedError = error;
        }

        expect(capturedError).to.include({
            type: 'RequestInvalidError',
            code: 'INVALID_EXPIRATION_DATETIME',
        });
        expect(state[TOKENS_KEY]).to.deep.equal([]);
    });

    it('rejects exact datetime shares that are not positive millisecond timestamps', function () {
        for (const invalidExp of [
            0,
            -1,
            1713753600,
            '1713753600',
            1713753600000.5,
            '1713753600000.5',
        ]) {
            let capturedError;

            try {
                createTokenItem(
                    {
                        type: 'sub',
                        name: 'shared-sub',
                        token: `invalid-ms-${String(invalidExp)}`,
                    },
                    {
                        mode: 'datetime',
                        exp: invalidExp,
                    },
                );
            } catch (error) {
                capturedError = error;
            }

            expect(capturedError).to.include({
                type: 'RequestInvalidError',
                code: 'INVALID_EXPIRATION_DATETIME',
            });
        }

        expect(state[TOKENS_KEY]).to.deep.equal([]);
    });

    it('rejects empty exact datetime shares', function () {
        for (const invalidExp of [null, '', '   ']) {
            let capturedError;

            try {
                createTokenItem(
                    {
                        type: 'sub',
                        name: 'shared-sub',
                        token: `bad-token-${String(invalidExp)}`,
                    },
                    {
                        mode: 'datetime',
                        exp: invalidExp,
                    },
                );
            } catch (error) {
                capturedError = error;
            }

            expect(capturedError).to.include({
                type: 'RequestInvalidError',
                code: 'INVALID_EXPIRATION_DATETIME',
            });
        }

        expect(state[TOKENS_KEY]).to.deep.equal([]);
    });

    it('rejects duration shares when expiresIn is missing', function () {
        let capturedError;

        try {
            createTokenItem(
                {
                    type: 'sub',
                    name: 'shared-sub',
                    token: 'duration-missing-expiration',
                },
                {
                    mode: 'duration',
                },
            );
        } catch (error) {
            capturedError = error;
        }

        expect(capturedError).to.include({
            type: 'RequestInvalidError',
            code: 'INVALID_EXPIRES_IN',
        });
        expect(state[TOKENS_KEY]).to.deep.equal([]);
    });

    it('keeps legacy duration behavior when mode is omitted', function () {
        const token = createTokenItem(
            {
                type: 'sub',
                name: 'shared-sub',
                token: 'legacy-duration',
            },
            {
                expiresIn: '1d',
                exp: Date.now() + 10 * 24 * 60 * 60 * 1000,
            },
        );

        expect(token.mode).to.equal('duration');
        expect(token.expiresIn).to.equal('1d');
        expect(token.exp).to.be.a('number');
    });

    it('stores original duration input for frontend restoration', function () {
        const token = createTokenItem(
            {
                type: 'sub',
                name: 'shared-sub',
                token: 'duration-input',
            },
            {
                mode: 'duration',
                expiresIn: '35d',
                expiresValue: '35',
                expiresUnit: 'day',
            },
        );

        expect(token.mode).to.equal('duration');
        expect(token.expiresIn).to.equal('35d');
        expect(token.expiresValue).to.equal('35');
        expect(token.expiresUnit).to.equal('day');
        expect(state[TOKENS_KEY][0].expiresValue).to.equal('35');
        expect(state[TOKENS_KEY][0].expiresUnit).to.equal('day');
    });

    it('accepts season duration input when it matches expiresIn', function () {
        const token = createTokenItem(
            {
                type: 'sub',
                name: 'shared-sub',
                token: 'duration-season',
            },
            {
                mode: 'duration',
                expiresIn: '90d',
                expiresValue: '1',
                expiresUnit: 'season',
            },
        );

        expect(token.mode).to.equal('duration');
        expect(token.expiresIn).to.equal('90d');
        expect(token.expiresValue).to.equal('1');
        expect(token.expiresUnit).to.equal('season');
        expect(state[TOKENS_KEY][0].expiresValue).to.equal('1');
        expect(state[TOKENS_KEY][0].expiresUnit).to.equal('season');
    });

    it('stores lifetime duration shares without expiration', function () {
        const token = createTokenItem(
            {
                type: 'sub',
                name: 'shared-sub',
                token: 'duration-lifetime',
            },
            {
                mode: 'duration',
                expiresValue: '35',
                expiresUnit: 'lifetime',
            },
        );

        expect(token.mode).to.equal('duration');
        expect(token.expiresUnit).to.equal('lifetime');
        expect(token).to.not.have.property('exp');
        expect(token).to.not.have.property('expiresIn');
        expect(token).to.not.have.property('expiresValue');
        expect(state[TOKENS_KEY][0].expiresUnit).to.equal('lifetime');
        expect(state[TOKENS_KEY][0]).to.not.have.property('exp');

        const found = findShareToken({
            token: 'duration-lifetime',
            type: 'sub',
            name: 'shared-sub',
        });
        expect(found.token).to.equal('duration-lifetime');
    });

    it('rejects lifetime duration shares with expiresIn', function () {
        let capturedError;

        try {
            createTokenItem(
                {
                    type: 'sub',
                    name: 'shared-sub',
                    token: 'duration-lifetime-conflict',
                },
                {
                    mode: 'duration',
                    expiresIn: '1d',
                    expiresUnit: 'lifetime',
                },
            );
        } catch (error) {
            capturedError = error;
        }

        expect(capturedError).to.include({
            type: 'RequestInvalidError',
            code: 'INVALID_DURATION_INPUT',
        });
        expect(state[TOKENS_KEY]).to.deep.equal([]);
    });

    it('rejects invalid duration input metadata', function () {
        for (const options of [
            {
                mode: 'duration',
                expiresIn: '35d',
                expiresValue: '0',
                expiresUnit: 'day',
                code: 'INVALID_EXPIRES_VALUE',
            },
            {
                mode: 'duration',
                expiresIn: '35d',
                expiresValue: '35',
                expiresUnit: 'week',
                code: 'INVALID_EXPIRES_UNIT',
            },
            {
                mode: 'duration',
                expiresIn: '1d',
                expiresValue: '2',
                expiresUnit: 'year',
                code: 'INVALID_DURATION_INPUT',
            },
        ]) {
            let capturedError;

            try {
                createTokenItem(
                    {
                        type: 'sub',
                        name: 'shared-sub',
                        token: `duration-input-${options.code}`,
                    },
                    options,
                );
            } catch (error) {
                capturedError = error;
            }

            expect(capturedError).to.include({
                type: 'RequestInvalidError',
                code: options.code,
            });
        }

        expect(state[TOKENS_KEY]).to.deep.equal([]);
    });

    it('infers legacy exact datetime behavior when mode is omitted but exp exists', function () {
        const exp = Date.now() - 5 * 60 * 1000;

        const token = createTokenItem(
            {
                type: 'sub',
                name: 'shared-sub',
                token: 'legacy-datetime',
            },
            {
                exp,
            },
        );

        expect(token.mode).to.equal('datetime');
        expect(token.exp).to.equal(exp);
        expect(token).to.not.have.property('expiresIn');
        expect(state[TOKENS_KEY][0].mode).to.equal('datetime');
        expect(state[TOKENS_KEY][0].exp).to.equal(exp);
    });

    it('ignores expiration metadata injected through payload', function () {
        const token = createTokenItem(
            {
                type: 'sub',
                name: 'shared-sub',
                token: 'payload-mode-ignored',
                mode: 'datetime',
                exp: Date.now() + 60 * 1000,
                expiresIn: '1d',
                expiresValue: '35',
                expiresUnit: 'day',
            },
            {},
        );

        expect(token).to.not.have.property('mode');
        expect(token).to.not.have.property('exp');
        expect(token).to.not.have.property('expiresIn');
        expect(token).to.not.have.property('expiresValue');
        expect(token).to.not.have.property('expiresUnit');
        expect(state[TOKENS_KEY][0]).to.not.have.property('mode');
        expect(state[TOKENS_KEY][0]).to.not.have.property('exp');
        expect(state[TOKENS_KEY][0]).to.not.have.property('expiresIn');
        expect(state[TOKENS_KEY][0]).to.not.have.property('expiresValue');
        expect(state[TOKENS_KEY][0]).to.not.have.property('expiresUnit');
    });

    it('preserves age-public-key in share token payload', async function () {
        const pair = await ageUtils.generateKeyPair();
        const token = createTokenItem(
            {
                type: 'sub',
                name: 'shared-sub',
                token: 'age-token',
                'age-public-key': pair['age-public-key'],
                mode: 'datetime',
                exp: Date.now() + 60 * 1000,
            },
            {},
        );

        expect(token['age-public-key']).to.equal(pair['age-public-key']);
        expect(token).to.not.have.property('mode');
        expect(token).to.not.have.property('exp');
        expect(state[TOKENS_KEY][0]['age-public-key']).to.equal(pair['age-public-key']);
    });

    it('lets routes read consumed count token metadata without another count increment', async function () {
        const pair = await ageUtils.generateKeyPair();
        createTokenItem(
            {
                type: 'sub',
                name: 'shared-sub',
                token: 'count-age-token',
                'age-public-key': pair['age-public-key'],
            },
            {
                mode: 'count',
                count: 2,
            },
        );

        const consumed = consumeShareToken({
            token: 'count-age-token',
            type: 'sub',
            name: 'shared-sub',
        });
        const found = findShareToken({
            token: 'count-age-token',
            type: 'sub',
            name: 'shared-sub',
        });

        expect(consumed.usedCount).to.equal(1);
        expect(consumed['age-public-key']).to.equal(pair['age-public-key']);
        expect(found.usedCount).to.equal(1);
        expect(state[TOKENS_KEY][0].usedCount).to.equal(1);
    });
});
