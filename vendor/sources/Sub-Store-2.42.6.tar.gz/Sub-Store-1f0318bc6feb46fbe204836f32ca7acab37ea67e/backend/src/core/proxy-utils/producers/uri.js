/* eslint-disable no-case-declarations */
import { Base64 } from 'js-base64';
import $ from '@/core/app';
import { isIPv6, isPlainObject } from '@/utils';
import { getWireGuardAddressWithCIDR, normalizePluginMuxValue } from './utils';
import {
    normalizeXhttpIntegerValue,
    normalizeXhttpNonNegativeRange,
    normalizeXhttpPositiveRange,
    normalizeXhttpStrictPositiveRangeValue,
} from '../xhttp-utils';
import {
    extractPathQueryParam,
    parseSafeIntegerValue,
    setPathQueryParam,
} from '../transport-path';
import {
    buildXrayEchConfigListFromMihomo,
    buildXrayEchFieldsFromMihomo,
} from '../ech-utils';
import { normalizeVmessSecurity } from '../vmess-security';

function toStringHeaderMap(headers, { excludeHost = false } = {}) {
    if (!isPlainObject(headers)) {
        return undefined;
    }

    const parsedHeaders = {};
    for (const [key, value] of Object.entries(headers)) {
        if (typeof value !== 'string') {
            continue;
        }
        if (excludeHost && /^host$/i.test(key)) {
            continue;
        }
        parsedHeaders[key] = value;
    }

    return Object.keys(parsedHeaders).length > 0 ? parsedHeaders : undefined;
}

function getHttpUpgradeEarlyData(transportOpts, path) {
    const httpUpgradeEd = getSafeEarlyDataValue(
        transportOpts?.['_v2ray-http-upgrade-ed'],
    );
    if (httpUpgradeEd !== '') return httpUpgradeEd;

    const pathEd = getSafeEarlyDataValue(
        extractPathQueryParam(path || '/', 'ed').value,
    );
    return pathEd !== '' ? pathEd : 2560;
}

function setHttpUpgradeEarlyDataPath(path, transportOpts) {
    if (!transportOpts?.['v2ray-http-upgrade-fast-open']) {
        return path;
    }

    return setPathQueryParam(
        path || '/',
        'ed',
        getHttpUpgradeEarlyData(transportOpts, path),
    );
}

function setWebSocketEarlyDataPath(path, transportOpts) {
    const earlyDataValue = transportOpts?.['max-early-data'];
    const earlyData = getSafeEarlyDataValue(earlyDataValue);
    if (earlyData === '') {
        if (earlyDataValue != null && `${earlyDataValue}` !== '') {
            return path == null ? path : extractPathQueryParam(path, 'ed').path;
        }
        return path;
    }

    const earlyDataHeaderName = transportOpts?.['early-data-header-name'];
    if (
        earlyDataHeaderName &&
        earlyDataHeaderName !== 'Sec-WebSocket-Protocol'
    ) {
        return path == null ? path : extractPathQueryParam(path, 'ed').path;
    }

    return setPathQueryParam(path || '/', 'ed', earlyData);
}

function getSafeEarlyDataValue(value) {
    if (value == null || `${value}` === '') return '';
    return parseSafeIntegerValue(value) == null ? '' : `${value}`;
}

function parseIntegerLikeValue(value) {
    return normalizeXhttpIntegerValue(value);
}

function getSerializableXhttpRangeValue(value) {
    return normalizeXhttpNonNegativeRange(value);
}

function warnEchDefaultDns({
    defaultDns,
    dnsFieldPath,
    echOptsPath,
    proxyName,
    queryServerName,
}) {
    const proxyLabel = proxyName || '未命名节点';
    $.warn(
        `URI ECH: 节点 "${proxyLabel}" 的 ${echOptsPath} 已开启且设置 query-server-name="${queryServerName}", 但未设置 ${dnsFieldPath}; 已使用默认 DNS ${defaultDns}. 如需自定义, 请设置 ${dnsFieldPath}.`,
    );
}

function getTransportHost(network, transportOpts = {}) {
    if (network === 'h2') {
        return (
            transportOpts.host ??
            transportOpts.headers?.host ??
            transportOpts.headers?.Host
        );
    }
    if (network === 'xhttp') {
        return (
            transportOpts.host ??
            transportOpts.headers?.Host ??
            transportOpts.headers?.host
        );
    }
    return (
        transportOpts.headers?.Host ??
        transportOpts.headers?.host ??
        transportOpts.host
    );
}

function mapReuseSettingsToXmux(reuseSettings) {
    if (!isPlainObject(reuseSettings)) {
        return undefined;
    }

    const xmux = {};
    const reuseFieldMap = {
        'max-connections': 'maxConnections',
        'max-concurrency': 'maxConcurrency',
        'c-max-reuse-times': 'cMaxReuseTimes',
        'h-max-request-times': 'hMaxRequestTimes',
        'h-max-reusable-secs': 'hMaxReusableSecs',
    };

    for (const [sourceKey, targetKey] of Object.entries(reuseFieldMap)) {
        const normalizedValue = normalizeXhttpNonNegativeRange(
            reuseSettings[sourceKey],
        );
        if (normalizedValue != null) {
            xmux[targetKey] =
                typeof normalizedValue === 'number'
                    ? `${normalizedValue}`
                    : normalizedValue;
        }
    }

    const hKeepAlivePeriod = parseIntegerLikeValue(
        reuseSettings['h-keep-alive-period'],
    );
    if (hKeepAlivePeriod != null) {
        xmux.hKeepAlivePeriod = hKeepAlivePeriod;
    }

    return Object.keys(xmux).length > 0 ? xmux : undefined;
}

function applyStructuredXhttpExtraFields(
    target,
    xhttpOpts,
    { excludeHostHeader = true, xmuxTarget = 'root' } = {},
) {
    if (!isPlainObject(target) || !isPlainObject(xhttpOpts)) {
        return;
    }

    const headers = toStringHeaderMap(xhttpOpts.headers, {
        excludeHost: excludeHostHeader,
    });
    if (headers) {
        target.headers = headers;
    }

    if (xhttpOpts['no-grpc-header'] === true) {
        target.noGRPCHeader = true;
    }
    if (xhttpOpts['x-padding-bytes']) {
        target.xPaddingBytes = xhttpOpts['x-padding-bytes'];
    }
    if (xhttpOpts['x-padding-obfs-mode'] === true) {
        target.xPaddingObfsMode = true;
    }
    if (xhttpOpts['x-padding-key']) {
        target.xPaddingKey = xhttpOpts['x-padding-key'];
    }
    if (xhttpOpts['x-padding-header']) {
        target.xPaddingHeader = xhttpOpts['x-padding-header'];
    }
    if (xhttpOpts['x-padding-placement']) {
        target.xPaddingPlacement = xhttpOpts['x-padding-placement'];
    }
    if (xhttpOpts['x-padding-method']) {
        target.xPaddingMethod = xhttpOpts['x-padding-method'];
    }
    if (xhttpOpts['uplink-http-method']) {
        target.uplinkHTTPMethod = xhttpOpts['uplink-http-method'];
    }
    if (xhttpOpts['session-placement']) {
        target.sessionIDPlacement = xhttpOpts['session-placement'];
    }
    if (xhttpOpts['session-key']) {
        target.sessionIDKey = xhttpOpts['session-key'];
    }
    if (typeof xhttpOpts['session-table'] === 'string') {
        // NOTE: This mirrors the current structured field mapping only.
        // Xray-core/mihomo still apply coupled validation with
        // session-length when the table is non-empty: ASCII-only table,
        // strictly positive length range, and enough total ID space.
        target.sessionIDTable = xhttpOpts['session-table'];
    }
    if (xhttpOpts['session-length'] != null) {
        // NOTE: The normalized range here is only a local serialization check.
        // Upstream compatibility still depends on the session-table/session-
        // length pair satisfying the extra Xray-core/mihomo constraints.
        const sessionIDLength = normalizeXhttpStrictPositiveRangeValue(
            xhttpOpts['session-length'],
        );
        if (sessionIDLength != null) {
            target.sessionIDLength = sessionIDLength;
        }
    }
    if (xhttpOpts['seq-placement']) {
        target.seqPlacement = xhttpOpts['seq-placement'];
    }
    if (xhttpOpts['seq-key']) {
        target.seqKey = xhttpOpts['seq-key'];
    }
    if (xhttpOpts['uplink-data-placement']) {
        target.uplinkDataPlacement = xhttpOpts['uplink-data-placement'];
    }
    if (xhttpOpts['uplink-data-key']) {
        target.uplinkDataKey = xhttpOpts['uplink-data-key'];
    }

    const uplinkChunkSize = getSerializableXhttpRangeValue(
        xhttpOpts['uplink-chunk-size'],
    );
    if (uplinkChunkSize != null) {
        target.uplinkChunkSize = uplinkChunkSize;
    }

    if (xhttpOpts['sc-max-each-post-bytes'] != null) {
        const scMaxEachPostBytes = normalizeXhttpStrictPositiveRangeValue(
            xhttpOpts['sc-max-each-post-bytes'],
        );
        if (scMaxEachPostBytes != null) {
            target.scMaxEachPostBytes = scMaxEachPostBytes;
        }
    }

    if (xhttpOpts['sc-min-posts-interval-ms'] != null) {
        const scMinPostsIntervalMs = normalizeXhttpPositiveRange(
            xhttpOpts['sc-min-posts-interval-ms'],
        );
        if (scMinPostsIntervalMs != null) {
            target.scMinPostsIntervalMs = scMinPostsIntervalMs;
        }
    }

    const xmux = mapReuseSettingsToXmux(xhttpOpts['reuse-settings']);
    if (xmux) {
        if (xmuxTarget === 'extra') {
            target.extra = {
                ...(isPlainObject(target.extra) ? target.extra : {}),
                xmux,
            };
        } else {
            target.xmux = xmux;
        }
    }
}

function buildXhttpDownloadSettings(
    downloadSettings,
    outerXhttpOpts = {},
    proxy = {},
) {
    if (!isPlainObject(downloadSettings)) {
        return undefined;
    }

    const explicitNetwork =
        typeof downloadSettings.network === 'string'
            ? downloadSettings.network.toLowerCase()
            : '';
    const normalizedNetwork =
        explicitNetwork === 'xhttp' || explicitNetwork === 'splithttp'
            ? 'xhttp'
            : undefined;

    const result = {};
    if (downloadSettings.server) {
        result.address = downloadSettings.server;
    }
    const parsedPort = normalizeXhttpIntegerValue(downloadSettings.port, {
        allowNegative: false,
    });
    if (parsedPort != null) {
        result.port = parsedPort;
    }

    const realityOpts = isPlainObject(downloadSettings['reality-opts'])
        ? downloadSettings['reality-opts']
        : undefined;
    if (realityOpts) {
        result.security = 'reality';
    } else if (downloadSettings.tls) {
        result.security = 'tls';
    }

    const tlsSettings = {};
    if (downloadSettings.servername) {
        tlsSettings.serverName = downloadSettings.servername;
    }
    if (downloadSettings['client-fingerprint']) {
        tlsSettings.fingerprint = downloadSettings['client-fingerprint'];
    }
    if (downloadSettings['skip-cert-verify']) {
        tlsSettings.allowInsecure = true;
    }
    if (downloadSettings.alpn) {
        tlsSettings.alpn = Array.isArray(downloadSettings.alpn)
            ? downloadSettings.alpn
            : [downloadSettings.alpn];
    }
    const echFields = buildXrayEchFieldsFromMihomo(
        downloadSettings['ech-opts'],
        undefined,
        {
            dnsFieldPath: 'xhttp-opts.download-settings.ech-opts._dns',
            warnDefaultDns: (context) =>
                warnEchDefaultDns({
                    ...context,
                    echOptsPath: 'xhttp-opts.download-settings.ech-opts',
                    proxyName: proxy.name,
                }),
        },
    );
    if (echFields.echConfigList) {
        tlsSettings.echConfigList = echFields.echConfigList;
    }
    if (echFields.echForceQuery) {
        tlsSettings.echForceQuery = echFields.echForceQuery;
    }
    if (echFields.echSockopt) {
        tlsSettings.echSockopt = cloneXhttpExtraValue(echFields.echSockopt);
    }
    if (Object.keys(tlsSettings).length > 0) {
        result.tlsSettings = tlsSettings;
    }

    if (realityOpts) {
        const realitySettings = {};
        if (downloadSettings.servername) {
            realitySettings.serverName = downloadSettings.servername;
        }
        if (downloadSettings['client-fingerprint']) {
            realitySettings.fingerprint =
                downloadSettings['client-fingerprint'];
        }
        if (realityOpts['public-key']) {
            realitySettings.publicKey = realityOpts['public-key'];
        }
        if (realityOpts['short-id']) {
            realitySettings.shortId = realityOpts['short-id'];
        }
        if (Object.keys(realitySettings).length > 0) {
            result.realitySettings = realitySettings;
        }
    }

    const xhttpSettings = {};
    // Mirror Mihomo's inheritance: path and host fall back to outer xhttp-opts
    // when not explicitly set in download-settings. Mode is never a field in
    // Mihomo's XHTTPDownloadSettings struct, so it always comes from outer.
    const dsPath = downloadSettings.path ?? outerXhttpOpts.path;
    if (dsPath) {
        xhttpSettings.path = dsPath;
    }
    const downloadHost =
        getTransportHost('xhttp', downloadSettings) ??
        getTransportHost('xhttp', outerXhttpOpts);
    if (downloadHost) {
        xhttpSettings.host = downloadHost;
    }
    const mode = downloadSettings.mode ?? outerXhttpOpts.mode;
    if (mode) {
        xhttpSettings.mode = mode;
    }
    applyStructuredXhttpExtraFields(xhttpSettings, downloadSettings, {
        excludeHostHeader: true,
        xmuxTarget: 'extra',
    });
    if (Object.keys(xhttpSettings).length > 0) {
        result.xhttpSettings = xhttpSettings;
    }

    if (Object.keys(result).length === 0 && normalizedNetwork == null) {
        return undefined;
    }

    // Treat nested downloadSettings.network as a supported structured field.
    // Fresh structured exports still default to xhttp so Xray sees a nested
    // StreamConfig instead of falling back to tcp.
    return {
        ...(result.address != null ? { address: result.address } : {}),
        network: normalizedNetwork || 'xhttp',
        ...(result.port != null ? { port: result.port } : {}),
        ...(result.security != null ? { security: result.security } : {}),
        ...(result.tlsSettings != null
            ? { tlsSettings: result.tlsSettings }
            : {}),
        ...(result.realitySettings != null
            ? { realitySettings: result.realitySettings }
            : {}),
        ...(result.xhttpSettings != null
            ? { xhttpSettings: result.xhttpSettings }
            : {}),
    };
}

function buildStructuredVlessExtraObject(proxy) {
    const xhttpOpts = proxy['xhttp-opts'] || {};
    const extra = {};
    applyStructuredXhttpExtraFields(extra, xhttpOpts, {
        excludeHostHeader: true,
        xmuxTarget: 'root',
    });

    const downloadSettings = buildXhttpDownloadSettings(
        xhttpOpts['download-settings'],
        xhttpOpts,
        proxy,
    );
    if (downloadSettings) {
        extra.downloadSettings = downloadSettings;
    }

    return Object.keys(extra).length > 0 ? extra : undefined;
}

function cloneXhttpExtraValue(value) {
    if (Array.isArray(value)) {
        return value.map(cloneXhttpExtraValue);
    }

    if (isPlainObject(value)) {
        const clonedValue = {};
        for (const [key, entryValue] of Object.entries(value)) {
            clonedValue[key] = cloneXhttpExtraValue(entryValue);
        }
        return clonedValue;
    }

    return value;
}

function mergeUnsupportedXhttpExtraValue(baseValue, unsupportedValue) {
    if (baseValue == null) {
        return cloneXhttpExtraValue(unsupportedValue);
    }

    if (Array.isArray(baseValue) || Array.isArray(unsupportedValue)) {
        return cloneXhttpExtraValue(baseValue);
    }

    if (isPlainObject(baseValue) && isPlainObject(unsupportedValue)) {
        return mergeUnsupportedXhttpExtraObject(baseValue, unsupportedValue);
    }

    return cloneXhttpExtraValue(baseValue);
}

function mergeUnsupportedXhttpExtraObject(baseObject, unsupportedObject) {
    const mergedExtra = isPlainObject(baseObject)
        ? cloneXhttpExtraValue(baseObject)
        : {};
    if (!isPlainObject(unsupportedObject)) {
        return mergedExtra;
    }

    for (const [key, value] of Object.entries(unsupportedObject)) {
        if (!Object.prototype.hasOwnProperty.call(mergedExtra, key)) {
            mergedExtra[key] = cloneXhttpExtraValue(value);
            continue;
        }

        mergedExtra[key] = mergeUnsupportedXhttpExtraValue(
            mergedExtra[key],
            value,
        );
    }

    return mergedExtra;
}

function serializeUriJsonValue(value) {
    if (typeof value === 'string') {
        return value;
    }

    // Only serialize JSON-like plain objects, not Date/Map/class instances.
    if (isPlainObject(value)) {
        return JSON.stringify(value);
    }

    return undefined;
}

function buildVlessExtra(proxy) {
    const explicitExtraOverride = serializeUriJsonValue(proxy._extra);
    if (explicitExtraOverride != null) {
        // `_extra` is an explicit user override for the final URI extra. When
        // present as a string or plain object, we bypass the structured xhttp
        // rebuild entirely so users can hand-author extra without needing to
        // keep other structured fields in sync.
        return explicitExtraOverride;
    }

    if (proxy.network !== 'xhttp') {
        return proxy._extra || '';
    }

    const structuredExtra = buildStructuredVlessExtraObject(proxy);

    // IMPORTANT: `_extra_unsupported` is only the sidecar for URI extra fields
    // that Mihomo does not model structurally yet, and it only participates
    // when the user did not explicitly set `_extra`. Without an explicit
    // override, supported xhttp fields must still be emitted from the current
    // structured Mihomo node so later edits are reflected on export, while
    // `_extra_unsupported` fills the holes needed for VLESS URI -> node ->
    // VLESS URI lossless round-trips. That also means supported-field format
    // conflicts are resolved by the structured emitters here.
    const mergedExtra = mergeUnsupportedXhttpExtraObject(
        structuredExtra,
        proxy._extra_unsupported,
    );

    return Object.keys(mergedExtra).length > 0
        ? JSON.stringify(mergedExtra)
        : '';
}

function vless(proxy) {
    let security = 'none';
    const isReality = proxy['reality-opts'];
    let sid = '';
    let pbk = '';
    let spx = '';
    if (isReality) {
        security = 'reality';
        const publicKey = proxy['reality-opts']?.['public-key'];
        if (publicKey) {
            pbk = `&pbk=${encodeURIComponent(publicKey)}`;
            const mlkem = proxy['reality-opts']['support-x25519mlkem768'];
            if (mlkem) {
                pbk += `&support-x25519mlkem768=${encodeURIComponent(mlkem)}`;
            }
        }
        const shortId = proxy['reality-opts']?.['short-id'];
        if (shortId) {
            sid = `&sid=${encodeURIComponent(shortId)}`;
        }
        const spiderX = proxy['reality-opts']?.['_spider-x'];
        if (spiderX) {
            spx = `&spx=${encodeURIComponent(spiderX)}`;
        }
    } else if (proxy.tls) {
        security = 'tls';
    }
    let alpn = '';
    if (proxy.alpn) {
        alpn = `&alpn=${encodeURIComponent(
            Array.isArray(proxy.alpn) ? proxy.alpn : proxy.alpn.join(','),
        )}`;
    }
    let allowInsecure = '';
    if (proxy['skip-cert-verify']) {
        allowInsecure = `&allowInsecure=1`;
    }
    let h2 = '';
    if (proxy._h2) {
        h2 = `&h2=1`;
    }
    let pcs = '';
    if (proxy['tls-fingerprint']) {
        pcs = `&pcs=${encodeURIComponent(proxy['tls-fingerprint'])}`;
    }
    let vcn = '';
    const certNames = Array.isArray(proxy._vcn)
        ? proxy._vcn.join(',')
        : proxy['name-cert-verify'];
    if (Array.isArray(proxy._vcn) || certNames) {
        vcn = `&vcn=${encodeURIComponent(certNames)}`;
    }
    let ech = '';
    const echConfigList = buildXrayEchConfigListFromMihomo(
        proxy['ech-opts'],
        proxy._echConfigList,
        {
            dnsFieldPath: 'ech-opts._dns',
            warnDefaultDns: (context) =>
                warnEchDefaultDns({
                    ...context,
                    echOptsPath: 'ech-opts',
                    proxyName: proxy.name,
                }),
        },
    );
    if (echConfigList) {
        ech = `&ech=${encodeURIComponent(echConfigList)}`;
    }
    let sni = '';
    if (proxy.sni) {
        sni = `&sni=${encodeURIComponent(proxy.sni)}`;
    }
    let fp = '';
    if (proxy['client-fingerprint']) {
        fp = `&fp=${encodeURIComponent(proxy['client-fingerprint'])}`;
    }
    let flow = '';
    if (proxy.flow) {
        flow = `&flow=${encodeURIComponent(proxy.flow)}`;
    }
    let extra = '';
    const extraPayload = buildVlessExtra(proxy);
    if (extraPayload) {
        extra = `&extra=${encodeURIComponent(extraPayload)}`;
    }
    let fm = '';
    const finalmaskPayload = serializeUriJsonValue(proxy._finalmask);
    if (finalmaskPayload) {
        fm = `&fm=${encodeURIComponent(finalmaskPayload)}`;
    }
    let mode = '';
    if (
        ['xhttp'].includes(proxy.network) &&
        proxy[`${proxy.network}-opts`]?.mode
    ) {
        mode = `&mode=${encodeURIComponent(
            proxy[`${proxy.network}-opts`].mode,
        )}`;
    } else if (proxy._mode) {
        mode = `&mode=${encodeURIComponent(proxy._mode)}`;
    }
    let pqv = '';
    if (proxy._pqv) {
        pqv = `&pqv=${encodeURIComponent(proxy._pqv)}`;
    }
    let encryption = '';
    if (proxy.encryption) {
        encryption = `&encryption=${encodeURIComponent(proxy.encryption)}`;
    }
    let vlessType = proxy.network;
    if (proxy.network === 'ws' && proxy['ws-opts']?.['v2ray-http-upgrade']) {
        vlessType = 'httpupgrade';
    } else if (proxy.network === 'http') {
        vlessType = 'tcp';
    } else if (proxy.network === 'h2') {
        vlessType = 'http';
    }

    let vlessTransport = `&type=${encodeURIComponent(vlessType)}`;
    if (proxy.network === 'http') {
        vlessTransport += '&headerType=http';
    }
    if (['grpc'].includes(proxy.network)) {
        // https://github.com/XTLS/Xray-core/issues/91
        vlessTransport += `&mode=${encodeURIComponent(
            proxy[`${proxy.network}-opts`]?.['_grpc-type'] || 'gun',
        )}`;
        const authority = proxy[`${proxy.network}-opts`]?.['_grpc-authority'];
        if (authority) {
            vlessTransport += `&authority=${encodeURIComponent(authority)}`;
        }
    }

    const transportOpts = proxy[`${proxy.network}-opts`] || {};
    const isVlessHttpUpgrade =
        proxy.network === 'ws' && transportOpts?.['v2ray-http-upgrade'];
    let vlessTransportServiceName =
        transportOpts?.[`${proxy.network}-service-name`];
    let vlessTransportPath = transportOpts?.path;
    let vlessTransportHost = getTransportHost(proxy.network, transportOpts);
    const vlessWsEarlyData = getSafeEarlyDataValue(
        proxy['ws-opts']?.['max-early-data'],
    );
    if (Array.isArray(vlessTransportPath)) {
        vlessTransportPath = vlessTransportPath[0];
    }
    if (isVlessHttpUpgrade && transportOpts?.['v2ray-http-upgrade-fast-open']) {
        vlessTransportPath = setHttpUpgradeEarlyDataPath(
            vlessTransportPath,
            transportOpts,
        );
    } else if (
        proxy.network === 'ws' &&
        proxy['ws-opts']?.['max-early-data'] != null &&
        vlessTransportPath
    ) {
        vlessTransportPath = extractPathQueryParam(
            vlessTransportPath,
            'ed',
        ).path;
    }
    if (vlessTransportPath) {
        vlessTransport += `&path=${encodeURIComponent(vlessTransportPath)}`;
    }
    if (vlessTransportHost) {
        vlessTransport += `&host=${encodeURIComponent(
            Array.isArray(vlessTransportHost)
                ? vlessTransportHost[0]
                : vlessTransportHost,
        )}`;
    }
    if (vlessTransportServiceName) {
        vlessTransport += `&serviceName=${encodeURIComponent(
            vlessTransportServiceName,
        )}`;
    }
    if (proxy.network === 'http' && proxy['http-opts']?.method) {
        vlessTransport += `&method=${encodeURIComponent(
            proxy['http-opts'].method,
        )}`;
    }
    if (proxy.network === 'kcp') {
        if (proxy.seed) {
            vlessTransport += `&seed=${encodeURIComponent(proxy.seed)}`;
        }
        if (proxy.headerType) {
            vlessTransport += `&headerType=${encodeURIComponent(
                proxy.headerType,
            )}`;
        }
    }
    if (
        proxy.network === 'ws' &&
        !isVlessHttpUpgrade &&
        vlessWsEarlyData !== ''
    ) {
        vlessTransport += `&ed=${encodeURIComponent(vlessWsEarlyData)}`;
    }
    const earlyDataHeaderName = proxy['ws-opts']?.['early-data-header-name'];
    if (
        earlyDataHeaderName &&
        (isVlessHttpUpgrade ||
            proxy['ws-opts']?.['max-early-data'] == null ||
            earlyDataHeaderName !== 'Sec-WebSocket-Protocol')
    ) {
        vlessTransport += `&eh=${encodeURIComponent(earlyDataHeaderName)}`;
    }

    let packetEncoding = '';
    let canonicalPacketEncoding;
    if (proxy['packet-encoding'] != null) {
        canonicalPacketEncoding = `${proxy['packet-encoding']}`
            .trim()
            .toLowerCase();
    } else if (proxy.xudp) {
        canonicalPacketEncoding = 'xudp';
    } else if (proxy['packet-addr']) {
        canonicalPacketEncoding = 'packetaddr';
    } else if (proxy.udp === true) {
        canonicalPacketEncoding = '';
    }
    switch (canonicalPacketEncoding) {
        case '':
            packetEncoding = '&packetEncoding=none';
            break;
        case 'packetaddr':
            packetEncoding = '&packetEncoding=packet';
            break;
        case 'xudp':
            packetEncoding = '&packetEncoding=xudp';
            break;
    }

    return `vless://${proxy.uuid}@${proxy.server}:${
        proxy.port
    }?security=${encodeURIComponent(
        security,
    )}${vlessTransport}${packetEncoding}${alpn}${allowInsecure}${pcs}${vcn}${ech}${h2}${sni}${fp}${flow}${sid}${spx}${pbk}${mode}${extra}${fm}${pqv}${encryption}#${encodeURIComponent(
        proxy.name,
    )}`;
}

export default function URI_Producer() {
    const type = 'SINGLE';
    const produce = (proxy) => {
        let result = '';
        delete proxy.subName;
        delete proxy.collectionName;
        delete proxy.id;
        delete proxy.resolved;
        delete proxy['no-resolve'];
        for (const key in proxy) {
            if (proxy[key] == null) {
                delete proxy[key];
            }
        }
        if (
            [
                'tuic',
                'hysteria',
                'hysteria2',
                'juicity',
                'trusttunnel',
            ].includes(proxy.type)
        ) {
            delete proxy.tls;
        }
        if (
            !['vmess'].includes(proxy.type) &&
            proxy.server &&
            isIPv6(proxy.server)
        ) {
            proxy.server = `[${proxy.server}]`;
        }
        switch (proxy.type) {
            case 'socks5':
                result = `socks://${encodeURIComponent(
                    Base64.encode(
                        `${proxy.username ?? ''}:${proxy.password ?? ''}`,
                    ),
                )}@${proxy.server}:${proxy.port}#${proxy.name}`;
                break;
            case 'ss':
                const userinfo = `${proxy.cipher}:${proxy.password}`;
                result = `ss://${
                    proxy.cipher?.startsWith('2022-blake3-')
                        ? `${encodeURIComponent(
                              proxy.cipher,
                          )}:${encodeURIComponent(proxy.password)}`
                        : Base64.encode(userinfo)
                }@${proxy.server}:${proxy.port}${proxy.plugin ? '/' : ''}`;
                let query = '';
                if (proxy.plugin) {
                    query += '&plugin=';
                    const opts = proxy['plugin-opts'];
                    switch (proxy.plugin) {
                        case 'obfs':
                            query += encodeURIComponent(
                                `simple-obfs;obfs=${opts.mode}${
                                    opts.host ? ';obfs-host=' + opts.host : ''
                                }`,
                            );
                            break;
                        case 'v2ray-plugin':
                            const mux = normalizePluginMuxValue(opts.mux);
                            // 为了兼容性 多输出 mode 和 host 两个字段
                            query += encodeURIComponent(
                                `v2ray-plugin;obfs=${opts.mode};mode=${
                                    opts.mode
                                }${opts.host ? ';obfs-host=' + opts.host : ''}${
                                    opts.host ? ';host=' + opts.host : ''
                                }${opts.path ? ';path=' + opts.path : ''}${
                                    opts.tls ? ';tls' : ''
                                }${opts.sni ? ';sni=' + opts.sni : ''}${
                                    opts['skip-cert-verify']
                                        ? ';skip-cert-verify=' +
                                          opts['skip-cert-verify']
                                        : ''
                                }${mux != null ? ';mux=' + mux : ''}`,
                            );
                            break;
                        case 'shadow-tls':
                            query += encodeURIComponent(
                                `shadow-tls;host=${opts.host};password=${opts.password};version=${opts.version}`,
                            );
                            break;
                        default:
                            throw new Error(
                                `Unsupported plugin option: ${proxy.plugin}`,
                            );
                    }
                }
                if (proxy['udp-over-tcp']) {
                    query += '&uot=1';
                }
                if (proxy.tfo) {
                    query += '&tfo=1';
                }
                query += `&udp=${proxy.udp ? 1 : 0}`;
                let ssTransport = '';
                if (proxy.network) {
                    let ssType = proxy.network;
                    if (
                        proxy.network === 'ws' &&
                        proxy['ws-opts']?.['v2ray-http-upgrade']
                    ) {
                        ssType = 'httpupgrade';
                    }
                    ssTransport = `&type=${encodeURIComponent(ssType)}`;
                    if (['grpc'].includes(proxy.network)) {
                        let ssTransportServiceName =
                            proxy[`${proxy.network}-opts`]?.[
                                `${proxy.network}-service-name`
                            ];
                        let ssTransportAuthority =
                            proxy[`${proxy.network}-opts`]?.['_grpc-authority'];
                        if (ssTransportServiceName) {
                            ssTransport += `&serviceName=${encodeURIComponent(
                                ssTransportServiceName,
                            )}`;
                        }
                        if (ssTransportAuthority) {
                            ssTransport += `&authority=${encodeURIComponent(
                                ssTransportAuthority,
                            )}`;
                        }
                        ssTransport += `&mode=${encodeURIComponent(
                            proxy[`${proxy.network}-opts`]?.['_grpc-type'] ||
                                'gun',
                        )}`;
                    }
                    const ssTransportOpts =
                        proxy[`${proxy.network}-opts`] || {};
                    const isSsHttpUpgrade =
                        proxy.network === 'ws' &&
                        ssTransportOpts?.['v2ray-http-upgrade'];
                    let ssTransportPath = ssTransportOpts?.path;
                    let ssTransportHost = ssTransportOpts?.headers?.Host;
                    if (Array.isArray(ssTransportPath)) {
                        ssTransportPath = ssTransportPath[0];
                    }
                    if (isSsHttpUpgrade) {
                        ssTransportPath = setHttpUpgradeEarlyDataPath(
                            ssTransportPath,
                            ssTransportOpts,
                        );
                    } else if (proxy.network === 'ws') {
                        ssTransportPath = setWebSocketEarlyDataPath(
                            ssTransportPath,
                            ssTransportOpts,
                        );
                    }
                    if (ssTransportPath) {
                        ssTransport += `&path=${encodeURIComponent(
                            ssTransportPath,
                        )}`;
                    }
                    if (ssTransportHost) {
                        ssTransport += `&host=${encodeURIComponent(
                            Array.isArray(ssTransportHost)
                                ? ssTransportHost[0]
                                : ssTransportHost,
                        )}`;
                    }
                }
                let ssFp = '';
                if (proxy['client-fingerprint']) {
                    ssFp = `&fp=${encodeURIComponent(
                        proxy['client-fingerprint'],
                    )}`;
                }
                let ssAlpn = '';
                if (proxy.alpn) {
                    ssAlpn = `&alpn=${encodeURIComponent(
                        Array.isArray(proxy.alpn)
                            ? proxy.alpn
                            : proxy.alpn.join(','),
                    )}`;
                }
                const ssIsReality = proxy['reality-opts'];
                let ssSid = '';
                let ssPbk = '';
                let ssSpx = '';
                let ssSecurity = proxy.tls ? '&security=tls' : '';
                let ssMode = '';
                let ssExtra = '';
                if (ssIsReality) {
                    ssSecurity = `&security=reality`;
                    const publicKey = proxy['reality-opts']?.['public-key'];
                    if (publicKey) {
                        ssPbk = `&pbk=${encodeURIComponent(publicKey)}`;
                    }
                    const shortId = proxy['reality-opts']?.['short-id'];
                    if (shortId) {
                        ssSid = `&sid=${encodeURIComponent(shortId)}`;
                    }
                    const spiderX = proxy['reality-opts']?.['_spider-x'];
                    if (spiderX) {
                        ssSpx = `&spx=${encodeURIComponent(spiderX)}`;
                    }
                    if (proxy._extra) {
                        ssExtra = `&extra=${encodeURIComponent(proxy._extra)}`;
                    }
                    if (proxy._mode) {
                        ssMode = `&mode=${encodeURIComponent(proxy._mode)}`;
                    }
                }
                if (proxy.tls) {
                    query += `&sni=${encodeURIComponent(
                        proxy.sni || proxy.server,
                    )}${proxy['skip-cert-verify'] ? '&allowInsecure=1' : ''}`;
                }
                query += `${ssTransport}${ssAlpn}${ssFp}${ssSecurity}${ssSid}${ssPbk}${ssSpx}${ssMode}${ssExtra}#${encodeURIComponent(
                    proxy.name,
                )}`;
                result += query.replace(/^&/, '?');
                break;
            case 'ssr':
                result = `${proxy.server}:${proxy.port}:${proxy.protocol}:${
                    proxy.cipher
                }:${proxy.obfs}:${Base64.encode(proxy.password)}/`;
                result += `?remarks=${Base64.encode(proxy.name)}${
                    proxy['obfs-param']
                        ? '&obfsparam=' + Base64.encode(proxy['obfs-param'])
                        : ''
                }${
                    proxy['protocol-param']
                        ? '&protoparam=' +
                          Base64.encode(proxy['protocol-param'])
                        : ''
                }`;
                result = 'ssr://' + Base64.encode(result);
                break;
            case 'vmess':
                if (proxy['reality-opts'] || proxy._finalmask) {
                    // https://github.com/XTLS/Xray-core/discussions/716 excludes alterId/aid.
                    if (
                        proxy.aead === false ||
                        (proxy.aead !== true &&
                            Number(proxy.alterId || 0) !== 0)
                    ) {
                        throw new Error(
                            'VMess query URI format cannot represent non-AEAD authentication (alterId must be 0)',
                        );
                    }
                    result = vless({
                        ...proxy,
                        server: isIPv6(proxy.server)
                            ? `[${proxy.server}]`
                            : proxy.server,
                        network: proxy.network || 'tcp',
                        encryption: normalizeVmessSecurity(proxy.cipher),
                        flow: undefined,
                    }).replace(/^vless:\/\//, 'vmess://');
                    break;
                }
                // V2RayN URI format
                let type = '';
                let net = proxy.network || 'tcp';
                if (proxy.network === 'http') {
                    net = 'tcp';
                    type = 'http';
                } else if (
                    proxy.network === 'ws' &&
                    proxy['ws-opts']?.['v2ray-http-upgrade']
                ) {
                    net = 'httpupgrade';
                }
                result = {
                    v: '2',
                    ps: proxy.name,
                    add: proxy.server,
                    port: `${proxy.port}`,
                    id: proxy.uuid,
                    aid: `${proxy.alterId || 0}`,
                    scy: normalizeVmessSecurity(proxy.cipher),
                    net,
                    type,
                    tls: proxy.tls ? 'tls' : '',
                    alpn: Array.isArray(proxy.alpn)
                        ? proxy.alpn.join(',')
                        : proxy.alpn,
                    fp: proxy['client-fingerprint'],
                };
                if (proxy.tls && proxy.sni) {
                    result.sni = proxy.sni;
                }
                // obfs
                if (proxy.network) {
                    const vmessTransportOpts =
                        proxy[`${proxy.network}-opts`] || {};
                    const isVmessHttpUpgrade =
                        proxy.network === 'ws' &&
                        vmessTransportOpts?.['v2ray-http-upgrade'];
                    let vmessTransportPath = vmessTransportOpts?.path;
                    let vmessTransportHost = getTransportHost(
                        proxy.network,
                        vmessTransportOpts,
                    );

                    if (['grpc'].includes(proxy.network)) {
                        result.path =
                            proxy[`${proxy.network}-opts`]?.[
                                'grpc-service-name'
                            ];
                        // https://github.com/XTLS/Xray-core/issues/91
                        result.type =
                            proxy[`${proxy.network}-opts`]?.['_grpc-type'] ||
                            'gun';
                        result.host =
                            proxy[`${proxy.network}-opts`]?.['_grpc-authority'];
                    } else if (['kcp', 'quic'].includes(proxy.network)) {
                        // https://github.com/XTLS/Xray-core/issues/91
                        result.type =
                            proxy[`${proxy.network}-opts`]?.[
                                `_${proxy.network}-type`
                            ] || 'none';
                        result.host =
                            proxy[`${proxy.network}-opts`]?.[
                                `_${proxy.network}-host`
                            ];
                        result.path =
                            proxy[`${proxy.network}-opts`]?.[
                                `_${proxy.network}-path`
                            ];
                    } else {
                        if (Array.isArray(vmessTransportPath)) {
                            vmessTransportPath = vmessTransportPath[0];
                        }
                        if (isVmessHttpUpgrade) {
                            vmessTransportPath = setHttpUpgradeEarlyDataPath(
                                vmessTransportPath,
                                vmessTransportOpts,
                            );
                        } else if (proxy.network === 'ws') {
                            vmessTransportPath = setWebSocketEarlyDataPath(
                                vmessTransportPath,
                                vmessTransportOpts,
                            );
                        }
                        if (vmessTransportPath) {
                            result.path = vmessTransportPath;
                        }
                        if (vmessTransportHost) {
                            result.host = Array.isArray(vmessTransportHost)
                                ? vmessTransportHost[0]
                                : vmessTransportHost;
                        }
                    }
                }
                result = 'vmess://' + Base64.encode(JSON.stringify(result));
                break;
            case 'vless':
                result = vless(proxy);
                break;
            case 'trojan':
                let trojanTransport = '';
                if (proxy.network) {
                    let trojanType = proxy.network;
                    if (
                        proxy.network === 'ws' &&
                        proxy['ws-opts']?.['v2ray-http-upgrade']
                    ) {
                        trojanType = 'httpupgrade';
                    }
                    trojanTransport = `&type=${encodeURIComponent(trojanType)}`;
                    if (['grpc'].includes(proxy.network)) {
                        let trojanTransportServiceName =
                            proxy[`${proxy.network}-opts`]?.[
                                `${proxy.network}-service-name`
                            ];
                        let trojanTransportAuthority =
                            proxy[`${proxy.network}-opts`]?.['_grpc-authority'];
                        if (trojanTransportServiceName) {
                            trojanTransport += `&serviceName=${encodeURIComponent(
                                trojanTransportServiceName,
                            )}`;
                        }
                        if (trojanTransportAuthority) {
                            trojanTransport += `&authority=${encodeURIComponent(
                                trojanTransportAuthority,
                            )}`;
                        }
                        trojanTransport += `&mode=${encodeURIComponent(
                            proxy[`${proxy.network}-opts`]?.['_grpc-type'] ||
                                'gun',
                        )}`;
                    }
                    const trojanTransportOpts =
                        proxy[`${proxy.network}-opts`] || {};
                    const isTrojanHttpUpgrade =
                        proxy.network === 'ws' &&
                        trojanTransportOpts?.['v2ray-http-upgrade'];
                    let trojanTransportPath = trojanTransportOpts?.path;
                    let trojanTransportHost =
                        trojanTransportOpts?.headers?.Host;
                    if (Array.isArray(trojanTransportPath)) {
                        trojanTransportPath = trojanTransportPath[0];
                    }
                    if (isTrojanHttpUpgrade) {
                        trojanTransportPath = setHttpUpgradeEarlyDataPath(
                            trojanTransportPath,
                            trojanTransportOpts,
                        );
                    } else if (proxy.network === 'ws') {
                        trojanTransportPath = setWebSocketEarlyDataPath(
                            trojanTransportPath,
                            trojanTransportOpts,
                        );
                    }
                    if (trojanTransportPath) {
                        trojanTransport += `&path=${encodeURIComponent(
                            trojanTransportPath,
                        )}`;
                    }
                    if (trojanTransportHost) {
                        trojanTransport += `&host=${encodeURIComponent(
                            Array.isArray(trojanTransportHost)
                                ? trojanTransportHost[0]
                                : trojanTransportHost,
                        )}`;
                    }
                }
                let trojanFp = '';
                if (proxy['client-fingerprint']) {
                    trojanFp = `&fp=${encodeURIComponent(
                        proxy['client-fingerprint'],
                    )}`;
                }
                let trojanPcs = '';
                if (proxy['tls-fingerprint']) {
                    trojanPcs = `&pcs=${encodeURIComponent(
                        proxy['tls-fingerprint'],
                    )}`;
                }
                let trojanVcn = '';
                const trojanCertNames = Array.isArray(proxy._vcn)
                    ? proxy._vcn.join(',')
                    : proxy['name-cert-verify'];
                if (Array.isArray(proxy._vcn) || trojanCertNames) {
                    trojanVcn = `&vcn=${encodeURIComponent(trojanCertNames)}`;
                }
                let trojanAlpn = '';
                if (proxy.alpn) {
                    trojanAlpn = `&alpn=${encodeURIComponent(
                        Array.isArray(proxy.alpn)
                            ? proxy.alpn
                            : proxy.alpn.join(','),
                    )}`;
                }
                const trojanIsReality = proxy['reality-opts'];
                let trojanSid = '';
                let trojanPbk = '';
                let trojanSpx = '';
                let trojanSecurity = '';
                let trojanMode = '';
                let trojanExtra = '';
                if (trojanIsReality) {
                    trojanSecurity = `&security=reality`;
                    const publicKey = proxy['reality-opts']?.['public-key'];
                    if (publicKey) {
                        trojanPbk = `&pbk=${encodeURIComponent(publicKey)}`;
                    }
                    const shortId = proxy['reality-opts']?.['short-id'];
                    if (shortId) {
                        trojanSid = `&sid=${encodeURIComponent(shortId)}`;
                    }
                    const spiderX = proxy['reality-opts']?.['_spider-x'];
                    if (spiderX) {
                        trojanSpx = `&spx=${encodeURIComponent(spiderX)}`;
                    }
                    if (proxy._extra) {
                        trojanExtra = `&extra=${encodeURIComponent(
                            proxy._extra,
                        )}`;
                    }
                    if (proxy._mode) {
                        trojanMode = `&mode=${encodeURIComponent(proxy._mode)}`;
                    }
                }
                result = `trojan://${proxy.password}@${proxy.server}:${
                    proxy.port
                }?sni=${encodeURIComponent(proxy.sni || proxy.server)}${
                    proxy['skip-cert-verify'] ? '&allowInsecure=1' : ''
                }${trojanTransport}${trojanAlpn}${trojanFp}${trojanPcs}${trojanVcn}${trojanSecurity}${trojanSid}${trojanPbk}${trojanSpx}${trojanMode}${trojanExtra}#${encodeURIComponent(
                    proxy.name,
                )}`;
                break;
            case 'hysteria2':
                let hysteria2params = [];
                if (proxy['hop-interval']) {
                    hysteria2params.push(
                        `hop-interval=${proxy['hop-interval']}`,
                    );
                }
                if (proxy['keepalive']) {
                    hysteria2params.push(`keepalive=${proxy['keepalive']}`);
                }
                if (proxy['skip-cert-verify']) {
                    hysteria2params.push(`insecure=1`);
                }
                if (proxy.obfs) {
                    hysteria2params.push(
                        `obfs=${encodeURIComponent(proxy.obfs)}`,
                    );
                    if (proxy['obfs-password']) {
                        hysteria2params.push(
                            `obfs-password=${encodeURIComponent(
                                proxy['obfs-password'],
                            )}`,
                        );
                    }
                }
                if (proxy.sni) {
                    hysteria2params.push(
                        `sni=${encodeURIComponent(proxy.sni)}`,
                    );
                }
                if (proxy.ports) {
                    hysteria2params.push(`mport=${proxy.ports}`);
                }
                if (proxy['tls-fingerprint']) {
                    hysteria2params.push(
                        `pinSHA256=${encodeURIComponent(
                            proxy['tls-fingerprint'],
                        )}`,
                    );
                }
                if (proxy.tfo) {
                    hysteria2params.push(`fastopen=1`);
                }
                const hysteria2Ech = buildXrayEchConfigListFromMihomo(
                    proxy['ech-opts'],
                );
                if (hysteria2Ech) {
                    hysteria2params.push(
                        `ech=${encodeURIComponent(hysteria2Ech)}`,
                    );
                }
                result = `hysteria2://${encodeURIComponent(proxy.password)}@${
                    proxy.server
                }:${proxy.port}?${hysteria2params.join(
                    '&',
                )}#${encodeURIComponent(proxy.name)}`;
                break;
            case 'hysteria':
                let hysteriaParams = [];
                Object.keys(proxy).forEach((key) => {
                    if (!['name', 'type', 'server', 'port'].includes(key)) {
                        const i = key.replace(/-/, '_');
                        if (['alpn'].includes(key)) {
                            if (proxy[key]) {
                                hysteriaParams.push(
                                    `${i}=${encodeURIComponent(
                                        Array.isArray(proxy[key])
                                            ? proxy[key][0]
                                            : proxy[key],
                                    )}`,
                                );
                            }
                        } else if (['skip-cert-verify'].includes(key)) {
                            if (proxy[key]) {
                                hysteriaParams.push(`insecure=1`);
                            }
                        } else if (['tfo', 'fast-open'].includes(key)) {
                            if (
                                proxy[key] &&
                                !hysteriaParams.includes('fastopen=1')
                            ) {
                                hysteriaParams.push(`fastopen=1`);
                            }
                        } else if (['ports'].includes(key)) {
                            hysteriaParams.push(`mport=${proxy[key]}`);
                        } else if (['auth-str'].includes(key)) {
                            hysteriaParams.push(`auth=${proxy[key]}`);
                        } else if (['up'].includes(key)) {
                            hysteriaParams.push(`upmbps=${proxy[key]}`);
                        } else if (['down'].includes(key)) {
                            hysteriaParams.push(`downmbps=${proxy[key]}`);
                        } else if (['_obfs'].includes(key)) {
                            hysteriaParams.push(`obfs=${proxy[key]}`);
                        } else if (['obfs'].includes(key)) {
                            hysteriaParams.push(`obfsParam=${proxy[key]}`);
                        } else if (['sni'].includes(key)) {
                            hysteriaParams.push(`peer=${proxy[key]}`);
                        } else if (proxy[key] && !/^_/i.test(key)) {
                            hysteriaParams.push(
                                `${i}=${encodeURIComponent(proxy[key])}`,
                            );
                        }
                    }
                });

                result = `hysteria://${proxy.server}:${
                    proxy.port
                }?${hysteriaParams.join('&')}#${encodeURIComponent(
                    proxy.name,
                )}`;
                break;

            case 'tuic':
                if (!proxy.token || proxy.token.length === 0) {
                    let tuicParams = [];
                    Object.keys(proxy).forEach((key) => {
                        if (
                            ![
                                'name',
                                'type',
                                'uuid',
                                'password',
                                'server',
                                'port',
                                'tls',
                            ].includes(key)
                        ) {
                            const i = key.replace(/-/, '_');
                            if (['alpn'].includes(key)) {
                                if (proxy[key]) {
                                    tuicParams.push(
                                        `${i}=${encodeURIComponent(
                                            Array.isArray(proxy[key])
                                                ? proxy[key][0]
                                                : proxy[key],
                                        )}`,
                                    );
                                }
                            } else if (['skip-cert-verify'].includes(key)) {
                                if (proxy[key]) {
                                    tuicParams.push(`allow_insecure=1`);
                                }
                            } else if (['tfo', 'fast-open'].includes(key)) {
                                if (
                                    proxy[key] &&
                                    !tuicParams.includes('fast_open=1')
                                ) {
                                    tuicParams.push(`fast_open=1`);
                                }
                            } else if (
                                ['disable-sni', 'reduce-rtt'].includes(key) &&
                                proxy[key]
                            ) {
                                tuicParams.push(`${i.replace(/-/g, '_')}=1`);
                            } else if (
                                ['congestion-controller'].includes(key)
                            ) {
                                tuicParams.push(
                                    `congestion_control=${proxy[key]}`,
                                );
                            } else if (proxy[key] && !/^_/i.test(key)) {
                                tuicParams.push(
                                    `${i.replace(
                                        /-/g,
                                        '_',
                                    )}=${encodeURIComponent(proxy[key])}`,
                                );
                            }
                        }
                    });

                    result = `tuic://${encodeURIComponent(
                        proxy.uuid,
                    )}:${encodeURIComponent(proxy.password)}@${proxy.server}:${
                        proxy.port
                    }?${tuicParams.join('&')}#${encodeURIComponent(
                        proxy.name,
                    )}`;
                }
                break;
            case 'anytls':
                result = vless({
                    ...proxy,
                    uuid: proxy.password,
                    network: proxy.network || 'tcp',
                }).replace('vless', 'anytls');
                // 偷个懒
                let anytlsParams = [];
                Object.keys(proxy).forEach((key) => {
                    if (
                        ![
                            'name',
                            'type',
                            'password',
                            'server',
                            'port',
                            'tls',
                        ].includes(key)
                    ) {
                        const i = key.replace(/-/, '_');
                        if (['alpn'].includes(key)) {
                            if (proxy[key]) {
                                anytlsParams.push(
                                    `${i}=${encodeURIComponent(
                                        Array.isArray(proxy[key])
                                            ? proxy[key][0]
                                            : proxy[key],
                                    )}`,
                                );
                            }
                        } else if (['skip-cert-verify'].includes(key)) {
                            if (proxy[key]) {
                                anytlsParams.push(`insecure=1`);
                            }
                        } else if (['udp'].includes(key)) {
                            if (proxy[key]) {
                                anytlsParams.push(`udp=1`);
                            }
                        } else if (
                            proxy[key] &&
                            !/^_|client-fingerprint/i.test(key) &&
                            ['number', 'string', 'boolean'].includes(
                                typeof proxy[key],
                            )
                        ) {
                            anytlsParams.push(
                                `${i.replace(/-/g, '_')}=${encodeURIComponent(
                                    proxy[key],
                                )}`,
                            );
                        }
                    }
                });
                // Parse existing query parameters from result
                const urlParts = result.split('?');
                let baseUrl = urlParts[0];
                let existingParams = {};

                if (urlParts.length > 1) {
                    const queryString = urlParts[1].split('#')[0]; // Remove fragment if exists
                    const pairs = queryString.split('&');
                    pairs.forEach((pair) => {
                        const [key, value] = pair.split('=');
                        if (key) {
                            existingParams[key] = value;
                        }
                    });
                }

                // Merge anytlsParams with existing parameters
                anytlsParams.forEach((param) => {
                    const [key, value] = param.split('=');
                    if (key) {
                        existingParams[key] = value;
                    }
                });

                // Reconstruct query string
                const newParams = Object.keys(existingParams)
                    .map((key) => `${key}=${existingParams[key]}`)
                    .join('&');

                // Get fragment part if exists
                const fragmentMatch = result.match(/#(.*)$/);
                const fragment = fragmentMatch ? `#${fragmentMatch[1]}` : '';

                result = `${baseUrl}?${newParams}${fragment}`;
                // result = `anytls://${encodeURIComponent(proxy.password)}@${
                //     proxy.server
                // }:${proxy.port}/?${anytlsParams.join('&')}#${encodeURIComponent(
                //     proxy.name,
                // )}`;
                break;
            case 'wireguard':
                let wireguardParams = [];

                Object.keys(proxy).forEach((key) => {
                    if (
                        ![
                            'name',
                            'type',
                            'server',
                            'port',
                            'ip',
                            'ipv6',
                            'ip-cidr',
                            'ipv6-cidr',
                            'private-key',
                        ].includes(key)
                    ) {
                        if (['public-key'].includes(key)) {
                            wireguardParams.push(
                                `publickey=${encodeURIComponent(proxy[key])}`,
                            );
                        } else if (['udp'].includes(key)) {
                            if (proxy[key]) {
                                wireguardParams.push(`${key}=1`);
                            }
                        } else if (proxy[key] && !/^_/i.test(key)) {
                            wireguardParams.push(
                                `${key}=${encodeURIComponent(proxy[key])}`,
                            );
                        }
                    }
                });
                const wireguardIPv4 = getWireGuardAddressWithCIDR(
                    proxy,
                    'ipv4',
                );
                const wireguardIPv6 = getWireGuardAddressWithCIDR(
                    proxy,
                    'ipv6',
                );
                if (wireguardIPv4 && wireguardIPv6) {
                    wireguardParams.push(
                        `address=${encodeURIComponent(
                            `${wireguardIPv4},${wireguardIPv6}`,
                        )}`,
                    );
                } else if (wireguardIPv4) {
                    wireguardParams.push(
                        `address=${encodeURIComponent(wireguardIPv4)}`,
                    );
                } else if (wireguardIPv6) {
                    wireguardParams.push(
                        `address=${encodeURIComponent(wireguardIPv6)}`,
                    );
                }
                result = `wireguard://${encodeURIComponent(
                    proxy['private-key'],
                )}@${proxy.server}:${proxy.port}/?${wireguardParams.join(
                    '&',
                )}#${encodeURIComponent(proxy.name)}`;
                break;
        }
        return result;
    };
    return { type, produce };
}
