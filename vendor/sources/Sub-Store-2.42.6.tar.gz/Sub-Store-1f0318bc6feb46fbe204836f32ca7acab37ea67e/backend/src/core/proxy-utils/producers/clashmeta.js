import {
    getWireGuardAddressWithCIDR,
    isPresent,
    normalizePluginMuxBooleanValue,
    produceProxyListOutput,
    restoreShadowTLSProxyOpts,
    supportsShadowsocksV2rayPluginMode,
} from '@/core/proxy-utils/producers/utils';
import { isNotBlank, isPlainObject } from '@/utils';
import {
    deleteHttpUpgradeEarlyDataMetadata,
    normalizeWebSocketEarlyDataPath,
} from '../transport-path';
import { ECH_DNS_FIELD } from '../ech-utils';
import $ from '@/core/app';
import { normalizeVmessSecurity } from '../vmess-security';

const ipVersions = {
    dual: 'dual',
    'v4-only': 'ipv4',
    'v6-only': 'ipv6',
    'prefer-v4': 'ipv4-prefer',
    'prefer-v6': 'ipv6-prefer',
};

function warnMihomoUnsupportedEchDns(proxy, echOpts, echOptsPath) {
    if (!isPlainObject(echOpts) || !isNotBlank(echOpts[ECH_DNS_FIELD])) {
        return;
    }

    const queryServerName = isNotBlank(echOpts['query-server-name'])
        ? echOpts['query-server-name']
        : '这里是 query-server-name';
    $.warn(
        `mihomo 不支持在 ech-opts 中配置 ECH DNS. 如需跟节点 ECH 配置一致, 请在 mihomo 配置文件里设置 dns["nameserver-policy"]["${queryServerName}"] = ["${echOpts[ECH_DNS_FIELD]}"].`,
    );
}

function warnMihomoUnsupportedEchDnsFields(proxy, type) {
    if (type === 'internal') {
        return;
    }

    warnMihomoUnsupportedEchDns(proxy, proxy['ech-opts'], 'ech-opts');
    warnMihomoUnsupportedEchDns(
        proxy,
        proxy['xhttp-opts']?.['download-settings']?.['ech-opts'],
        'xhttp-opts.download-settings.ech-opts',
    );
}

export default function ClashMeta_Producer() {
    const type = 'ALL';
    const produce = (proxies, type, opts = {}) => {
        const list = proxies
            .filter((proxy) => {
                if (opts['include-unsupported-proxy']) return true;

                if (proxy.type === 'h2-connect') {
                    $.error(
                        `mihomo does not support HTTP/2 CONNECT proxy type. Proxy ${proxy.name} has been filtered.`,
                    );
                    return false;
                }
                if (proxy.type === 'masque-surge') {
                    $.error(
                        `mihomo does not support Surge MASQUE proxy type. Proxy ${proxy.name} has been filtered.`,
                    );
                    return false;
                }
                if (hasRootHeaders(proxy) && proxy.type === 'trusttunnel') {
                    $.error(
                        `mihomo does not support headers for TrustTunnel proxy ${proxy.name}. Proxy has been filtered.`,
                    );
                    return false;
                }
                if (!supportsShadowsocksV2rayPluginMode(proxy, ['websocket'])) {
                    return false;
                } else if (
                    proxy.type === 'snell' &&
                    !isSupportedMihomoVersion(proxy.version, [1, 2, 3, 4, 5])
                ) {
                    return false;
                } else if (
                    hasMihomoShadowTls(proxy) &&
                    (![
                        'ss',
                        'snell',
                        'vmess',
                        'vless',
                        'trojan',
                        'anytls',
                    ].includes(proxy.type) ||
                        !isSupportedMihomoVersion(
                            getMihomoShadowTlsVersion(proxy),
                            ['ss', 'snell'].includes(proxy.type)
                                ? [1, 2, 3]
                                : [0, 1, 2, 3],
                        ))
                ) {
                    return false;
                } else if (
                    proxy.type === 'vless' &&
                    proxy.network === 'xhttp' &&
                    hasMihomoShadowTls(
                        proxy['xhttp-opts']?.['download-settings'],
                    ) &&
                    !isSupportedMihomoVersion(
                        getMihomoShadowTlsVersion(
                            proxy['xhttp-opts']['download-settings'],
                        ),
                        [0, 1, 2, 3],
                    )
                ) {
                    return false;
                } else if (hasMihomoSnellShadowTlsObfsConflict(proxy)) {
                    $.error(
                        `Platform Mihomo does not support Snell shadow-tls with obfs for proxy ${proxy.name}. Proxy has been filtered.`,
                    );
                    return false;
                } else if (['juicity', 'naive'].includes(proxy.type)) {
                    return false;
                } else if (
                    ['ss'].includes(proxy.type) &&
                    ![
                        'aes-128-ctr',
                        'aes-192-ctr',
                        'aes-256-ctr',
                        'aes-128-cfb',
                        'aes-192-cfb',
                        'aes-256-cfb',
                        'aes-128-gcm',
                        'aes-192-gcm',
                        'aes-256-gcm',
                        'aes-128-ccm',
                        'aes-192-ccm',
                        'aes-256-ccm',
                        'aes-128-gcm-siv',
                        'aes-256-gcm-siv',
                        'chacha20-ietf',
                        'chacha20',
                        'xchacha20',
                        'chacha20-ietf-poly1305',
                        'xchacha20-ietf-poly1305',
                        'chacha8-ietf-poly1305',
                        'xchacha8-ietf-poly1305',
                        '2022-blake3-aes-128-gcm',
                        '2022-blake3-aes-256-gcm',
                        '2022-blake3-chacha20-poly1305',
                        'lea-128-gcm',
                        'lea-192-gcm',
                        'lea-256-gcm',
                        'rabbit128-poly1305',
                        'aegis-128l',
                        'aegis-256',
                        'aez-384',
                        'deoxys-ii-256-128',
                        'rc4-md5',
                        'none',
                    ].includes(proxy.cipher)
                ) {
                    // https://wiki.metacubex.one/config/proxies/ss/#cipher
                    return false;
                } else if (
                    ['anytls'].includes(proxy.type) &&
                    proxy.network &&
                    (!['tcp'].includes(proxy.network) ||
                        (['tcp'].includes(proxy.network) &&
                            proxy['reality-opts']))
                ) {
                    return false;
                } else if (
                    !['vless'].includes(proxy.type) &&
                    ['xhttp'].includes(proxy.network)
                ) {
                    return false;
                }
                return true;
            })
            .map((proxy) => {
                warnMihomoUnsupportedEchDnsFields(proxy, type);

                restoreShadowTLSProxyOpts(proxy);

                if (proxy['reality-opts'] && !proxy['client-fingerprint']) {
                    proxy['client-fingerprint'] = 'chrome';
                }
                if (proxy.type === 'vmess') {
                    // handle vmess aead
                    if (isPresent(proxy, 'aead')) {
                        if (proxy.aead) {
                            proxy.alterId = 0;
                        }
                        delete proxy.aead;
                    }
                    if (isPresent(proxy, 'sni')) {
                        proxy.servername = proxy.sni;
                        delete proxy.sni;
                    }
                    // https://github.com/MetaCubeX/Clash.Meta/blob/Alpha/docs/config.yaml#L400
                    // https://stash.wiki/proxy-protocols/proxy-types#vmess
                    proxy.cipher = normalizeVmessSecurity(proxy.cipher);
                } else if (proxy.type === 'tuic') {
                    if (isPresent(proxy, 'alpn')) {
                        proxy.alpn = Array.isArray(proxy.alpn)
                            ? proxy.alpn
                            : [proxy.alpn];
                    }
                    //  else {
                    //     proxy.alpn = ['h3'];
                    // }
                    if (
                        isPresent(proxy, 'tfo') &&
                        !isPresent(proxy, 'fast-open')
                    ) {
                        proxy['fast-open'] = proxy.tfo;
                    }
                    // https://github.com/MetaCubeX/Clash.Meta/blob/Alpha/adapter/outbound/tuic.go#L197
                    if (
                        (!proxy.token || proxy.token.length === 0) &&
                        !isPresent(proxy, 'version')
                    ) {
                        proxy.version = 5;
                    }
                } else if (proxy.type === 'hysteria') {
                    // auth_str 将会在未来某个时候删除 但是有的机场不规范
                    if (
                        isPresent(proxy, 'auth_str') &&
                        !isPresent(proxy, 'auth-str')
                    ) {
                        proxy['auth-str'] = proxy['auth_str'];
                    }
                    if (isPresent(proxy, 'alpn')) {
                        proxy.alpn = Array.isArray(proxy.alpn)
                            ? proxy.alpn
                            : [proxy.alpn];
                    }
                    if (
                        isPresent(proxy, 'tfo') &&
                        !isPresent(proxy, 'fast-open')
                    ) {
                        proxy['fast-open'] = proxy.tfo;
                    }
                } else if (proxy.type === 'wireguard') {
                    proxy.keepalive =
                        proxy.keepalive ?? proxy['persistent-keepalive'];
                    proxy['persistent-keepalive'] = proxy.keepalive;
                    proxy['preshared-key'] =
                        proxy['preshared-key'] ?? proxy['pre-shared-key'];
                    proxy['pre-shared-key'] = proxy['preshared-key'];
                    proxy.ip = getWireGuardAddressWithCIDR(proxy, 'ipv4');
                    proxy.ipv6 = getWireGuardAddressWithCIDR(proxy, 'ipv6');
                } else if (proxy.type === 'snell' && proxy.version < 3) {
                    delete proxy.udp;
                } else if (proxy.type === 'vless') {
                    if (isPresent(proxy, 'sni')) {
                        proxy.servername = proxy.sni;
                        delete proxy.sni;
                    }
                    // Mihomo 的运行时校验（`adapter/outbound/vless.go`）
                    // 会先把 flow 截断到 16 个字符，并且只接受
                    // `xtls-rprx-vision`。`xtls-rprx-direct`、
                    // `xtls-rprx-unknown` 等值在 Mihomo 加载时会报错。
                    //
                    // 另外，xhttp 使用 `alpn: [h3]` 时必须启用 TLS，
                    // 且不能启用 Reality；这条限制同时作用于根 xhttp
                    // 配置，以及继承根配置默认值后的嵌套
                    // `download-settings`。

                    // 1. mihomo 似乎不支持上行/下行有一个为 tls 一个不为 tls. 但是这跟转换无关了
                    // 2. 下行有 tls 且上行有 reality-opts 且下行无 reality-opts →
                    //    补 reality-opts: { public-key: '' }，阻断 reality 继承
                    if (
                        proxy.network === 'xhttp' &&
                        proxy['xhttp-opts']?.['download-settings']
                    ) {
                        const ds = proxy['xhttp-opts']['download-settings'];
                        if (
                            proxy.tls &&
                            ds.tls &&
                            proxy['reality-opts'] &&
                            !ds['reality-opts']
                        ) {
                            ds['reality-opts'] = { 'public-key': '' };
                        }
                    }
                } else if (
                    ['anytls'].includes(proxy.type) &&
                    proxy.reuse != null &&
                    !proxy.reuse
                ) {
                    proxy['disable-reuse'] = true;
                    delete proxy.reuse;
                }

                if (isPresent(proxy, 'plugin-opts.mux')) {
                    proxy['plugin-opts'].mux = normalizePluginMuxBooleanValue(
                        proxy['plugin-opts'].mux,
                    );
                }

                if (proxy.type === 'snell') {
                    const shadowTLSOpts = getMihomoShadowTlsOpts(proxy);
                    if (shadowTLSOpts) {
                        proxy['obfs-opts'] = {
                            mode: 'shadow-tls',
                            host: shadowTLSOpts.host,
                            password: shadowTLSOpts.password,
                            version: shadowTLSOpts.version,
                        };
                        if (shadowTLSOpts.alpn) {
                            proxy['obfs-opts'].alpn = shadowTLSOpts.alpn;
                        }
                        delete proxy.plugin;
                        delete proxy['plugin-opts'];
                    }
                }

                if (
                    ['vmess', 'vless'].includes(proxy.type) &&
                    proxy.network === 'http'
                ) {
                    let httpPath = proxy['http-opts']?.path;
                    if (
                        isPresent(proxy, 'http-opts.path') &&
                        !Array.isArray(httpPath)
                    ) {
                        proxy['http-opts'].path = [httpPath];
                    }
                    let httpHost = proxy['http-opts']?.headers?.Host;
                    if (
                        isPresent(proxy, 'http-opts.headers.Host') &&
                        !Array.isArray(httpHost)
                    ) {
                        proxy['http-opts'].headers.Host = [httpHost];
                    }
                }
                if (
                    ['vmess', 'vless'].includes(proxy.type) &&
                    proxy.network === 'h2'
                ) {
                    let path = proxy['h2-opts']?.path;
                    if (
                        isPresent(proxy, 'h2-opts.path') &&
                        Array.isArray(path)
                    ) {
                        proxy['h2-opts'].path = path[0];
                    }
                    let host =
                        proxy['h2-opts']?.host ??
                        proxy['h2-opts']?.headers?.host ??
                        proxy['h2-opts']?.headers?.Host;
                    if (
                        isPresent(proxy, 'h2-opts.host') ||
                        isPresent(proxy, 'h2-opts.headers.host') ||
                        isPresent(proxy, 'h2-opts.headers.Host')
                    ) {
                        proxy['h2-opts'].host = Array.isArray(host)
                            ? host
                            : [host];
                    }
                    if (proxy['h2-opts']?.headers) {
                        delete proxy['h2-opts'].headers.host;
                        delete proxy['h2-opts'].headers.Host;
                        if (
                            Object.keys(proxy['h2-opts'].headers).length === 0
                        ) {
                            delete proxy['h2-opts'].headers;
                        }
                    }
                }
                if (['ws'].includes(proxy.network)) {
                    const networkOptsKey = `${proxy.network}-opts`;
                    proxy[networkOptsKey] = proxy[networkOptsKey] || {};
                    if (!proxy[networkOptsKey].path) {
                        proxy[networkOptsKey].path = '/';
                    }
                    normalizeWebSocketEarlyDataPath(proxy[networkOptsKey]);
                }

                if (proxy['plugin-opts']?.tls) {
                    if (isPresent(proxy, 'skip-cert-verify')) {
                        proxy['plugin-opts']['skip-cert-verify'] =
                            proxy['plugin-opts']['skip-cert-verify'] ||
                            proxy['skip-cert-verify'];
                    }
                }
                if (
                    [
                        'trojan',
                        'tuic',
                        'hysteria',
                        'hysteria2',
                        'juicity',
                        'anytls',
                        'trusttunnel',
                        'naive',
                        'masque',
                        'shadowquic',
                    ].includes(proxy.type)
                ) {
                    delete proxy.tls;
                }

                if (proxy['tls-fingerprint']) {
                    proxy.fingerprint = proxy['tls-fingerprint'];
                }
                delete proxy['tls-fingerprint'];

                if (proxy['underlying-proxy']) {
                    proxy['dialer-proxy'] = proxy['underlying-proxy'];
                }
                delete proxy['underlying-proxy'];

                if (isPresent(proxy, 'tls') && typeof proxy.tls !== 'boolean') {
                    delete proxy.tls;
                }
                delete proxy.subName;
                delete proxy.collectionName;
                delete proxy.id;
                delete proxy.resolved;
                delete proxy['no-resolve'];
                delete proxy['ip-cidr'];
                delete proxy['ipv6-cidr'];
                if (type !== 'internal' || opts['delete-underscore-fields']) {
                    for (const key in proxy) {
                        if (proxy[key] == null || /^_/i.test(key)) {
                            delete proxy[key];
                        }
                    }
                    deleteHttpUpgradeEarlyDataMetadata(
                        proxy[`${proxy.network}-opts`],
                    );
                }
                if (
                    ['grpc'].includes(proxy.network) &&
                    proxy[`${proxy.network}-opts`]
                ) {
                    delete proxy[`${proxy.network}-opts`]['_grpc-type'];
                    delete proxy[`${proxy.network}-opts`]['_grpc-authority'];
                }

                if (proxy['ip-version']) {
                    proxy['ip-version'] =
                        ipVersions[proxy['ip-version']] || proxy['ip-version'];
                }
                return proxy;
            });

        return produceProxyListOutput(list, type, opts);
    };
    return { type, produce };
}

function hasRootHeaders(proxy) {
    return (
        proxy?.headers &&
        typeof proxy.headers === 'object' &&
        Object.keys(proxy.headers).length > 0
    );
}

function isSupportedMihomoVersion(version, supportedVersions) {
    if (version == null) {
        return true;
    }

    const normalized =
        typeof version === 'string' ? version.trim() : `${version}`;
    if (!normalized) {
        return false;
    }

    const parsed = Number(normalized);
    return Number.isInteger(parsed) && supportedVersions.includes(parsed);
}

function hasMihomoShadowTls(proxy) {
    return Boolean(getMihomoShadowTlsOpts(proxy));
}

function hasMihomoSnellShadowTlsObfsConflict(proxy) {
    return (
        proxy?.type === 'snell' &&
        proxy?.plugin === 'shadow-tls' &&
        (isPresent(proxy, 'obfs-opts.mode') ||
            isPresent(proxy, 'obfs-opts.host') ||
            isPresent(proxy, 'obfs-opts.path'))
    );
}

function getMihomoShadowTlsVersion(proxy) {
    return getMihomoShadowTlsOpts(proxy)?.version;
}

function getMihomoShadowTlsOpts(proxy) {
    if (proxy?.plugin === 'shadow-tls' && proxy?.['plugin-opts']) {
        return proxy['plugin-opts'];
    }
    if (
        proxy?.type === 'snell' &&
        proxy?.['obfs-opts']?.mode === 'shadow-tls'
    ) {
        return proxy['obfs-opts'];
    }
    return undefined;
}
