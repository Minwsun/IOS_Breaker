<template>
  <div class="page-wrapper" @click="handleEditGlobalClick">
    <div
      v-if="editorTabsEnabled"
      class="editor-section-tabs"
      :style="{ top: navBarHeight }"
    >
      <div class="editor-section-tab-list" role="tablist">
        <button
          v-for="tab in SUB_EDITOR_TABS"
          :key="tab"
          type="button"
          class="editor-section-tab"
          :class="{ current: activeEditorTab === tab }"
          role="tab"
          :aria-selected="activeEditorTab === tab"
          @click="activeEditorTab = tab"
        >
          {{ $t(`editorPage.subConfig.editorTabs.${tab}`) }}
        </button>
      </div>
      <EditorGroupingTips />
    </div>
    <!-- 基础表单 -->
    <div
      v-show="isSubFormTabActive"
      class="form-block-wrapper"
    >
      <div
        v-if="appearanceSetting.isShowIcon && (!editorTabsEnabled || activeEditorTab === 'display')"
        class="sticky-title-icon-container"
      >
        <nut-image
          :class="{ 'sub-item-customer-icon': !form.isIconColor }"
          :src="subIcon"
          :fit="formIconFit"
          show-loading
          @click="showIconPopup"
        />
      </div>
      <!-- <div class="sticky-title-wrapper">
        <p>{{ $t(`editorPage.subConfig.basic.label`) }}</p>
      </div> -->
      <nut-form class="form" :model-value="form" ref="ruleForm">
        <div v-show="!editorTabsEnabled || activeEditorTab === 'display'" class="editor-tab-content">
        <!-- name -->
        <nut-form-item
          required
          :label="$t(`editorPage.subConfig.basic.name.label`)"
          prop="name"
          :rules="[
            {
              required: true,
              message: $t(`editorPage.subConfig.basic.name.isEmpty`),
            },
            {
              validator: nameValidator,
              message: $t(`editorPage.subConfig.basic.name.isInvalid`),
            },
          ]"
        >
          <input
            class="nut-input-text"
            data-1p-ignore
            @blur="customerBlurValidate('name')"
            v-model.trim="form.name"
            :placeholder="$t(`editorPage.subConfig.basic.name.placeholder`)"
            type="text"
          />
        </nut-form-item>
        <!-- displayName -->
        <nut-form-item
          :label="$t(`editorPage.subConfig.basic.displayName.label`)"
          prop="displayName"
        >
          <input
            class="nut-input-text"
            data-1p-ignore
            v-model.trim="form.displayName"
            :placeholder="
              $t(`editorPage.subConfig.basic.displayName.placeholder`)
            "
            type="text"
          />
        </nut-form-item>
        <!-- remark -->
        <nut-form-item
          :label="$t(`editorPage.subConfig.basic.remark.label`)"
          prop="remark"
        >
          <nut-textarea
            class="nut-input-text"
            :border="false"
            v-model="form.remark"
            :placeholder="
              $t(`editorPage.subConfig.basic.remark.placeholder`)
            "
            type="text"
            input-align="right"
            rows="1"
            :autosize="{ maxHeight: 140 }"
            max-length="100"
          />
        </nut-form-item>
        <!-- tag -->
        <nut-form-item
          :label="$t(`editorPage.subConfig.basic.tag.label`)"
          prop="tag"
        >
          <nut-input
            class="nut-input-text"
            v-model.trim="form.tag"
            :border="false"
            :placeholder="$t(`editorPage.subConfig.basic.tag.placeholder`)"
            type="text"
            input-align="right"
            right-icon="rect-right"
            @click-right-icon="showTagPopup('tag')"
          >
          </nut-input>
        </nut-form-item>
        <!-- icon -->
        <nut-form-item
          :label="$t(`editorPage.subConfig.basic.icon.label`)"
          prop="icon"
        >
          <nut-input
              :border="false"
              class="nut-input-text"
              v-model.trim="form.icon"
              :placeholder="$t(`editorPage.subConfig.basic.icon.placeholder`)"
              type="text"
              input-align="right"
              left-icon="shop"
              @click-left-icon="showIconPopup"
            />
        </nut-form-item>
        <!-- isIconColor -->
        <nut-form-item
          :label="$t(`editorPage.subConfig.basic.isIconColor.label`)"
          prop="isIconColor"
          class="ignore-failed-wrapper"
        >
          <div class="switch-wrapper">
            <nut-switch v-model="form.isIconColor" />
          </div>
        </nut-form-item>
        <ImageFitPicker v-model="form.iconFit" :fallback-value="appearanceSetting.iconFit" />
        </div>
        <div v-show="!editorTabsEnabled || activeEditorTab === 'content'" class="editor-tab-content">
        <template v-if="editType === 'subs'">
          <!-- source -->
          <nut-form-item
            required
            :label="$t(`editorPage.subConfig.basic.source.label`)"
            prop="source"
          >
            <div class="radio-wrapper">
              <nut-radiogroup direction="horizontal" v-model="form.source">
                <nut-radio shape="button" label="remote">
                  {{ $t(`editorPage.subConfig.basic.source.remote`) }}
                </nut-radio>
                <nut-radio shape="button" label="local">
                  {{ $t(`editorPage.subConfig.basic.source.local`) }}
                </nut-radio>
              </nut-radiogroup>
            </div>
          </nut-form-item>
          <!-- url / content -->
          <!-- :label="$t(`editorPage.subConfig.basic.url.label`)" -->
          <nut-form-item
            required
            
            v-if="form.source === 'remote'"
            prop="url"
            :rules="[
              {
                required: true,
                message: $t(`editorPage.subConfig.basic.url.isEmpty`),
              },
              {
                validator: urlValidator,
                message: $t(`editorPage.subConfig.basic.url.isIllegal`),
              },
            ]"
          >
            <template v-slot:label>
              <span class="label-tips" @click="urlTips">
                <p>{{$t(`editorPage.subConfig.basic.url.label`)}}</p>
                <span class="tips">
                  <span>{{$t(`editorPage.subConfig.basic.url.tips.label`)}}</span>
                  <!-- <nut-icon name="tips"></nut-icon> -->
                </span>
              </span>
            </template>
            <nut-textarea
              class="textarea-wrapper"
              @blur="customerBlurValidate('url')"
              @change="strTrim('url')"
              v-model="form.url"
              :autosize="{ maxHeight: 110, minHeight: 50 }"
              :placeholder="$t(`editorPage.subConfig.basic.url.placeholder`)"
              type="text"
            />
          </nut-form-item>
          <nut-form-item
            v-else-if="form.source === 'local'"
            :label="undefined"
            prop="content"
          >
            <!-- <nut-textarea
              class="textarea-wrapper"
              v-model="form.content"
              text-align="left"
              :autosize="{ maxHeight: 410, minHeight: 50 }"
              :placeholder="
                $t(`editorPage.subConfig.basic.content.placeholder`)
              "
              type="text"
            /> -->
            <div style="margin-left: -15px; margin-right: -15px;max-height: 60vh;overflow: auto;">
              <cmView
                :isReadOnly="false"
                id="SubEditer"
                :placeholder="$t(`editorPage.subConfig.basic.content.tips.content`)"
                :editor-language="form.editorLanguage"
                @update:editor-language="setEditorLanguage"
              />
            </div>
          </nut-form-item>

          <nut-form-item
            v-if="
              form.source === 'remote' ||
              ['localFirst', 'remoteFirst'].includes(form.mergeSources)
            "
            :label="$t(`editorPage.subConfig.basic.noCache.label`)"
            prop="noCache"
            class="ignore-failed-wrapper"
          >
            <div class="switch-wrapper">
              <nut-switch v-model="form.noCache" />
            </div>
          </nut-form-item>
          <!-- ua -->
          <nut-form-item
            :label="$t(`editorPage.subConfig.basic.passThroughUA.label`)"
            prop="passThroughUA"
            class="ignore-failed-wrapper"
            v-if="form.source === 'remote'"
          >
            <div class="switch-wrapper">
              <nut-switch v-model="form.passThroughUA" @change="handlePassThroughUAChange"/>
            </div>
          </nut-form-item>
          <nut-form-item
            :label="$t(`editorPage.subConfig.basic.ua.label`)"
            prop="ua"
            v-if="form.source === 'remote'"
          >
            <nut-input
              :border="false"
              class="nut-input-text"
              v-model.trim="form.ua"
              :placeholder="userAgentPlaceholder"
              type="text"
              input-align="right"
              left-icon="tips"
              :readonly="passThroughUAOn"
              @click-left-icon="uaTips"
            />
          </nut-form-item>

          <nut-form-item
            :label="$t(`editorPage.subConfig.basic.noFlow.label`)"
            prop="noFlow"
            class="ignore-failed-wrapper"
          >
            <div class="switch-wrapper">
              <nut-switch v-model="form.noFlow" />
            </div>
          </nut-form-item>

          <nut-form-item
            :label="$t(`editorPage.subConfig.basic.subUserinfo.label`)"
            prop="subUserinfo"
          >
            <nut-input
              :border="false"
              class="nut-input-text"
              v-model.trim="form.subUserinfo"
              :placeholder="
                $t(`editorPage.subConfig.basic.subUserinfo.placeholder`)
              "
              type="text"
              input-align="right"
              left-icon="tips"
              @click-left-icon="subUserinfoTips"
            />
          </nut-form-item>

          <nut-form-item
            :label="$t(`editorPage.subConfig.basic.proxy.label`)"
            prop="proxy"
          >
            <nut-input
              :border="false"
              class="nut-input-text"
              v-model.trim="form.proxy"
              :placeholder="$t(`editorPage.subConfig.basic.proxy.placeholder`)"
              type="text"
              input-align="right"
              left-icon="tips"
              @click-left-icon="proxyTips"
            />
          </nut-form-item>

          <nut-form-item
            :label="$t(`editorPage.subConfig.basic.source.mergeSources`)"
            prop="mergeSources"
          >
            <div class="radio-wrapper">
              <nut-radiogroup
                direction="horizontal"
                v-model="form.mergeSources"
              >
                <nut-radio shape="button" label="">
                  {{ $t(`editorPage.subConfig.basic.source.noMerge`) }}
                </nut-radio>
                <nut-radio shape="button" label="localFirst">
                  {{ $t(`editorPage.subConfig.basic.source.localFirst`) }}
                </nut-radio>
                <nut-radio shape="button" label="remoteFirst">
                  {{ $t(`editorPage.subConfig.basic.source.remoteFirst`) }}
                </nut-radio>
              </nut-radiogroup>
            </div>
          </nut-form-item>
        </template>

        <template v-else-if="editType === 'collections'">
          <!-- subscriptionTags -->
          <nut-form-item
            :label="$t(`editorPage.subConfig.basic.subscriptionTags.label`)"
            prop="subscriptionTags"
          >
            <nut-input
              :border="false"
              class="nut-input-text"
              v-model.trim="form.subscriptionTags"
              :placeholder="$t(`editorPage.subConfig.basic.subscriptionTags.placeholder`)"
              type="text"
              input-align="right"
              left-icon="tips"
              right-icon="rect-right"
              @click-left-icon="subscriptionTagsTips"
              @click-right-icon="showTagPopup('linkTag')"
            />
          </nut-form-item>
          <nut-cell class="nut-form-item line include-subs-trigger" @click.stop="toggleManualSubscriptionsFold">
            <view class="nut-cell__title nut-form-item__label">
              {{ $t(`editorPage.subConfig.basic.subscriptions.label`) }}
            </view>
            <view class="nut-cell__value nut-form-item__body">
              <view class="nut-form-item__body__slots">
                <nut-input
                  :model-value="selectedSubsDisplay"
                  :border="false"
                  class="nut-input-text include-subs-trigger-input"
                  readonly
                  input-align="right"
                  :right-icon="manualSubscriptionsIsFold ? 'rect-right' : 'rect-down'"
                />
              </view>
            </view>
          </nut-cell>
          <div v-show="!manualSubscriptionsIsFold" class="include-subs-wrapper">
            <div v-show="!manualSubscriptionsIsFold && tags && tags.length > 0" class="tag-check">
              <div class="radio-wrapper">
                <span
                  v-for="i in tags"
                  :class="{ tag: true, current: i.value === tag }"
                  @click="setTag(i.value)"
                >
                  {{ i.label }}
                </span>
              </div>
              <nut-checkbox v-model="subCheckbox" :indeterminate="subCheckboxIndeterminate" @click="subCheckboxClick"></nut-checkbox>
            </div>
            <nut-checkboxgroup
              v-show="!manualSubscriptionsIsFold"
              v-model="visibleSelectedSubscriptions"
              :class="[
                'subs-checkbox-wrapper',
                {
                  'is-simple-mode': appearanceSetting.isSimpleMode,
                  'is-dragging': isDragging,
                },
              ]"
            >
              <draggable
                v-model="displayedSubsSelectList"
                item-key="0"
                animation="300"
                :scroll-sensitivity="200"
                :force-fallback="true"
                :scroll-speed="8"
                :scroll="true"
                handle=".drag-handle"
                @start="onStartDrag"
                @end="onEndDrag"
              >
                <template #item="{ element }">
                  <nut-checkbox
                    :key="element[0]"
                    :label="element[0]"
                    text-position="left"
                    class="subs-checkbox"
                  >
                    <div class="sub-img-wrapper">
                      <nut-avatar
                        :class="{ 'sub-item-customer-icon': !element[4], 'icon': true  }"
                        v-if="element[2]"
                        :size="chooserAvatarSize"
                        :url="rewriteGithubUrl(element[2])"
                        :style="{ '--icon-fit': element[5] }"
                        bg-color=""
                      ></nut-avatar>
                      <span class="sub-item">
                        <span class="name">{{ element[1] }}</span>
                        <span class="tag" v-for="i in element[3]" :key="i">
                          <nut-tag>{{ i }}</nut-tag>
                        </span>
                      </span>
                      <font-awesome-icon icon="fa-solid fa-bars" class="drag-handle"/>
                    </div>
                  </nut-checkbox>
                </template>
              </draggable>
            </nut-checkboxgroup>
          </div>
            <nut-form-item
              :label="$t(`editorPage.subConfig.basic.noFlow.label`)"
              prop="noFlow"
              class="ignore-failed-wrapper"
            >
              <div class="switch-wrapper">
                <nut-switch v-model="form.noFlow" />
              </div>
            </nut-form-item>
            <nut-form-item
              :label="$t(`editorPage.subConfig.basic.subUserinfo.label`)"
              prop="subUserinfo"
            >
              <nut-input
                :border="false"
                class="nut-input-text"
                v-model.trim="form.subUserinfo"
                :placeholder="
                  $t(`editorPage.subConfig.basic.subUserinfo.placeholder`)
                "
                type="text"
                input-align="right"
                left-icon="tips"
                @click-left-icon="subUserinfoTips"
              />
            </nut-form-item>
            <nut-form-item
              prop="firstSubFlow"
              class="ignore-failed-wrapper"
            >
              <template #label>
                <span class="label-with-tip" @click="firstSubFlowTips">
                  <span>{{ $t(`editorPage.subConfig.basic.firstSubFlow.label`) }}</span>
                  <nut-icon name="tips"></nut-icon>
                </span>
              </template>
              <div class="switch-wrapper">
                <nut-switch v-model="form.firstSubFlow" />
              </div>
            </nut-form-item>
            <nut-form-item
              :label="$t(`editorPage.subConfig.basic.proxy.label`)"
              prop="proxy"
            >
              <nut-input
                :border="false"
                class="nut-input-text"
                v-model.trim="form.proxy"
                :placeholder="$t(`editorPage.subConfig.basic.proxy.placeholder`)"
                type="text"
                input-align="right"
                left-icon="tips"
                @click-left-icon="proxyTips"
            />
          </nut-form-item>
        </template>

        <nut-form-item prop="age-public-key">
          <template #label>
            <span class="label-with-tip" @click="ageOutputTips">
              <span>{{ $t("ageKey.publicKey.label") }}</span>
              <nut-icon name="tips"></nut-icon>
            </span>
          </template>
          <div class="age-key-field">
            <nut-input
              :border="false"
              class="nut-input-text"
              v-model.trim="form['age-public-key']"
              :placeholder="$t('ageKey.publicKey.placeholder')"
              type="text"
              input-align="right"
            />
            <AgeKeyHelper v-model="form['age-public-key']" />
          </div>
        </nut-form-item>

        <nut-form-item
          :label="$t(`editorPage.subConfig.basic.ignoreFailedRemoteSub.label`)"
          class="failure-mode-trigger"
          prop="ignoreFailedRemoteSub"
        >
          <nut-input
            :model-value="subFailureModeLabel"
            :border="false"
            class="nut-input-text failure-mode-input"
            readonly
            input-align="right"
            right-icon="rect-right"
            @click="openSubFailureModePicker"
            @click-right-icon="openSubFailureModePicker"
          />
        </nut-form-item>
        </div>
      </nut-form>
    </div>

    <!-- 常用配置 -->
    <div
      v-show="(!editorTabsEnabled || activeEditorTab === 'actions') && showEditorCommonBlock"
      class="editor-tab-content editor-common-content"
      :class="{ 'editor-tab-fixed-offset': editorTabsEnabled }"
    >
      <CommonBlock :default-folded="editorCommonDefaultFolded" />
    </div>

    <!-- 节点操作 -->
    <div
      v-show="!editorTabsEnabled || activeEditorTab === 'actions'"
      class="editor-tab-content editor-actions-content"
      :class="{
        'editor-tab-fixed-offset': editorTabsEnabled && !showEditorCommonBlock,
      }"
    >
      <ActionBlock
        ref="actionBlockRef"
        :checked="actionsChecked"
        :list="actionsList"
        @updateCustomNameModeFlag="updateCustomNameModeFlag"
        @addAction="addAction"
        @deleteAction="deleteAction"
        @toggleAction="toggleAction"
      />
    </div>
  </div>

  <div class="bottom-btn-wrapper">
    <nut-button @click="compare" class="compare-btn btn" plain shape="square">
      <font-awesome-icon icon="fa-solid fa-eye" />
      {{ $t("editorPage.subConfig.btn.compare") }}
    </nut-button>
    <nut-button
      @click="submit"
      class="submit-btn btn"
      type="primary"
      shape="square"
    >
      <font-awesome-icon icon="fa-solid fa-floppy-disk" />
      {{ $t("editorPage.subConfig.btn.save") }}
    </nut-button>
  </div>
  <CompareTable
    v-if="compareTableIsVisible"
    :name="configName"
    :compareData="compareData"
    :showRefresh="true"
    @closeCompare="closeCompare"
    @refresh="refreshCompare"
  />
  <icon-popup
    v-model:visible="iconPopupVisible"
    @setIcon="setIcon">
  </icon-popup>
  <DesktopPicker
    v-model="selectedSubFailureMode"
    v-model:visible="showSubFailureModePicker"
    :columns="subFailureModeColumns"
    :title="$t(`editorPage.subConfig.basic.ignoreFailedRemoteSub.label`)"
    :cancel-text="$t(`editorPage.subConfig.sourceNamePicker.cancel`)"
    :ok-text="$t(`editorPage.subConfig.sourceNamePicker.confirm`)"
    @confirm="handleSubFailureModeConfirm"
  />
  <tag-popup
    v-model:visible="tagPopupVisible"
    ref="tagPopupRef"
    :currentTag="currentTag"
    @setTag="setTagValue">
  </tag-popup>
</template>

<script lang="ts" setup>
import { useArtifactsStore } from "@/store/artifacts";
import { useSubsApi } from "@/api/subs";
import logoIcon from "@/assets/icons/logo.png";
import logoRedIcon from "@/assets/icons/logo-red.png";
import { usePopupRoute } from "@/hooks/usePopupRoute";
import { useAppNotifyStore } from "@/store/appNotify";
import { useGlobalStore } from "@/store/global";
import { useSettingsStore } from '@/store/settings';
import { useSubsStore } from "@/store/subs";
import { useSystemStore } from "@/store/system";
import { addItem, deleteItem, toggleItem } from "@/utils/actionsOperate";
import { actionsToProcess } from "@/utils/actionsToPorcess";
import {
  getEditorFoldState,
  getEditorIsFolded,
  getEditorRouteValue,
  setEditorFoldState,
  setEditorRouteValue,
} from "@/utils/editorFoldState";
import {
  getEditorActiveTab,
  setEditorActiveTab,
} from "@/utils/editorTabState";
import { getEditorTabForValidationErrors } from "@/utils/editorTabValidation";
import { initStores } from "@/utils/initApp";
import draggable from "vuedraggable";
import CompareTable from "@/views/CompareTable.vue";
import ActionBlock from "@/views/editor/ActionBlock.vue";
import CommonBlock from "@/views/editor/CommonBlock.vue";
import ActionRadio from "@/views/editor/components/ActionRadio.vue";
import FilterSelect from "@/views/editor/components/FilterSelect.vue";
import HandleDuplicate from "@/views/editor/components/HandleDuplicate.vue";
import Regex from "@/views/editor/components/Regex.vue";
import Script from "@/views/editor/components/Script.vue";
import IconPopup from "@/views/icon/IconPopup.vue";
import ImageFitPicker from "@/components/ImageFitPicker.vue";
import TagPopup from "@/components/TagPopup.vue";
import AgeKeyHelper from "@/components/AgeKeyHelper.vue";
import DesktopPicker from "@/components/DesktopPicker.vue";
import EditorGroupingTips from "@/components/EditorGroupingTips.vue";
import { Dialog, Toast } from "@nutui/nutui";
import { storeToRefs } from "pinia";
import {
  computed,
  provide,
  reactive,
  ref,
  shallowRef,
  toRaw,
  watchEffect,
  watch,
} from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";
import cmView from "@/views/editCode/cmView.vue";
import { useCodeStore } from "@/store/codeStore";
import { createGithubProxyUrlRewriter } from "@/utils/githubProxy";
import { normalizeOptionalImageFit, resolveImageFit } from "@/utils/iconFit";
const cmStore = useCodeStore();
const { t, locale } = useI18n();
const route = useRoute();
const router = useRouter();
const SUB_EDITOR_TAB_STORAGE_KEY = "sub-editor-active-tab";
const MANUAL_SUBSCRIPTIONS_FOLD_STORAGE_KEY = "manual-subscriptions-fold";
const MANUAL_SUBSCRIPTIONS_GROUP_STORAGE_KEY = "manual-subscriptions-group";
const subsApi = useSubsApi();
const editType = route.params.editType as string;
const configName = route.params.id as string;
const subsStore = useSubsStore();
const { showNotify } = useAppNotifyStore();

const globalStore = useGlobalStore();
const systemStore = useSystemStore();
const settingsStore = useSettingsStore();
const { appearanceSetting, githubProxy, githubProxyRegex } = storeToRefs(settingsStore);
const { navBarHeight } = storeToRefs(systemStore);

const {
    bottomSafeArea,
    // isEditorCommon,
    // isDefaultIcon, 
    // isIconColor 
  } = storeToRefs(globalStore);
const padding = bottomSafeArea.value + "px";
const githubUrlRewriter = computed(() => {
  return createGithubProxyUrlRewriter(githubProxy.value, githubProxyRegex.value);
});
const rewriteGithubUrl = (url?: string | null) => {
  return githubUrlRewriter.value(url);
};
const editorCommonDisplayMode = computed<EditorCommonDisplayMode>(() => {
  return appearanceSetting.value.editorCommonDisplayMode || (appearanceSetting.value.isEditorCommon ? "expanded" : "hidden");
});
const showEditorCommonBlock = computed(() => editorCommonDisplayMode.value !== "hidden");
const editorCommonDefaultFolded = computed(() => editorCommonDisplayMode.value === "collapsed");
const routeConfigName = computed(() => route.params.id as string);
const isEditMode = computed(() => routeConfigName.value !== "UNTITLED");
const editorGroupingMode = computed<EditorGroupingMode>(() => appearanceSetting.value.editorGroupingMode || "edit-only");
const editorTabsEnabled = computed(() => {
  if (editorGroupingMode.value === "disabled") return false;
  if (editorGroupingMode.value === "always") return true;
  return isEditMode.value;
});
const SUB_EDITOR_TABS = ["display", "content", "actions"] as const;
type SubEditorTab = (typeof SUB_EDITOR_TABS)[number];
const SUB_EDITOR_PROP_TO_TAB: Partial<Record<string, SubEditorTab>> = {
  name: "display",
  displayName: "display",
  remark: "display",
  tag: "display",
  icon: "display",
  isIconColor: "display",
  iconFit: "display",
  source: "content",
  url: "content",
  content: "content",
  passThroughUA: "content",
  ua: "content",
  noCache: "content",
  noFlow: "content",
  subUserinfo: "content",
  proxy: "content",
  mergeSources: "content",
  subscriptionTags: "content",
  firstSubFlow: "content",
  "age-public-key": "content",
  ignoreFailedRemoteSub: "content",
};
const availableEditorTabs = computed(() => [...SUB_EDITOR_TABS]);
const getSubEditorActiveTab = (
  path: string,
  tabs: readonly (typeof SUB_EDITOR_TABS)[number][],
) => {
  const defaultTab = tabs[0] || "display";

  if (!isEditMode.value) {
    return defaultTab;
  }

  return getEditorActiveTab(
    SUB_EDITOR_TAB_STORAGE_KEY,
    path,
    tabs,
    defaultTab,
  );
};
const activeEditorTab = ref(getSubEditorActiveTab(route.path, availableEditorTabs.value));
const isSubFormTabActive = computed(() => {
  return !editorTabsEnabled.value || ["display", "content"].includes(activeEditorTab.value);
});
watch(
  [() => route.path, availableEditorTabs, isEditMode],
  ([path, tabs]) => {
    activeEditorTab.value = getSubEditorActiveTab(path, tabs);
  },
  { immediate: true },
);
watch(activeEditorTab, (tab) => {
  if (!isEditMode.value) return;

  setEditorActiveTab(SUB_EDITOR_TAB_STORAGE_KEY, route.path, tab);
});
const setActiveSubEditorTab = (tab: SubEditorTab) => {
  if (!editorTabsEnabled.value) return;

  activeEditorTab.value = tab;
};
const focusValidationErrorTab = (errors: unknown) => {
  const tab = getEditorTabForValidationErrors(errors, SUB_EDITOR_PROP_TO_TAB);
  if (tab) {
    setActiveSubEditorTab(tab);
  }
};
const manualSubscriptionsDefaultFolded = computed(() => {
  return (appearanceSetting.value.manualSubscriptionsDisplayMode || "collapsed") === "collapsed";
});
const manualSubscriptionsIsFold = ref(
  getEditorIsFolded(
    MANUAL_SUBSCRIPTIONS_FOLD_STORAGE_KEY,
    route.path,
    manualSubscriptionsDefaultFolded.value,
  ),
);
const toggleManualSubscriptionsFold = () => {
  manualSubscriptionsIsFold.value = !manualSubscriptionsIsFold.value;
  setEditorFoldState(
    MANUAL_SUBSCRIPTIONS_FOLD_STORAGE_KEY,
    route.path,
    manualSubscriptionsIsFold.value,
  );
};
watch(
  [() => route.path, manualSubscriptionsDefaultFolded],
  ([path, defaultFolded]) => {
    if (getEditorFoldState(MANUAL_SUBSCRIPTIONS_FOLD_STORAGE_KEY, path) === undefined) {
      manualSubscriptionsIsFold.value = defaultFolded;
      return;
    }

    manualSubscriptionsIsFold.value = getEditorIsFolded(
      MANUAL_SUBSCRIPTIONS_FOLD_STORAGE_KEY,
      path,
      defaultFolded,
    );
  },
);
const chooserAvatarSize = computed(() => {
  return appearanceSetting.value.isSimpleMode ? "28" : "32";
});

type SubSelectRow = [string, string, string | undefined, string[] | undefined, boolean, ImageFit];

  const sub = computed(() => subsStore.getOneSub(configName));
  const collection = computed(() => subsStore.getOneCollection(configName));

  
  const subsSelectList = computed<SubSelectRow[]>(() => {
    return subsStore.subs.map(item => {
      return [
        item.name,
        item.displayName || item['display-name'] || item.name,
        item.icon || (appearanceSetting.value.isDefaultIcon ? logoIcon : logoRedIcon),
        item.tag,
        item.isIconColor !== false,
        resolveImageFit(item.iconFit, appearanceSetting.value.iconFit),
      ];
    });
  });
  const hasUntagged = ref(false);
  const tags = computed(() => {
    if(!subsStore.subs || subsStore.subs.length === 0) return []
    const set = new Set()
    subsStore.subs.forEach(sub => {
      if (Array.isArray(sub.tag) && sub.tag.length > 0) {
        sub.tag.forEach(i => {
          set.add(i)
        });
      } else {
        hasUntagged.value = true
      }
    })

    let tags: any[] = Array.from(set)
    // if(tags.length === 0) return []
    tags = tags.map(i => ({ label: i, value: i }));
    const result = [{ label: t("specificWord.all"), value: "all" }, ...tags]
    if(hasUntagged.value) result.push({ label: t("specificWord.untagged"), value: "untagged" })
    return result
  });
  const tag = ref('all');
  const manualSubscriptionsGroupInitialized = ref(false);
  const manualSubscriptionsGroupTouched = ref(false);
  const tagPopupVisible = ref(false);
  const tagType = ref('tag'); // 标签tag | 关联订阅标签linkTag
  const tagPopupRef = ref(null);
  const currentTag = computed(() => {
    if (tagType.value === 'linkTag') {
      return form.subscriptionTags
    } else {
      return form.tag
    }
  })
  const showTagPopup = (type:string) => {
    tagType.value = type || 'tag'
    tagPopupVisible.value = true
  };
  const setTagValue = (tag: any) => {
    if (tagType.value === 'linkTag') {
      form.subscriptionTags = tag;
    } else {
      form.tag = tag;      
    }
  };
const selectedSubs = computed(() => {
  const subscriptions = form.subscriptions || [];
  if(!Array.isArray(subscriptions) || subscriptions.length === 0) {
    if (!Array.isArray(subsSelectList.value) || subsSelectList.value.length === 0) return `: ${t(`editorPage.subConfig.basic.subscriptions.empty`)}`
    return `: ${t(`editorPage.subConfig.basic.subscriptions.none`)}`
  }
    return `: ${subscriptions.map((name) => {
      const sub = subsStore.getOneSub(name);
      if(!sub) form.subscriptions = form.subscriptions.filter((n) => n !== name);
      return sub?.displayName || sub?.["display-name"] || sub?.name || `${name}(🚫)`;
    }).join(', ')}`
  });
const selectedSubsDisplay = computed(() => selectedSubs.value.replace(/^:\s*/, ""));
  const subFailureModeOptions = computed(() => {
    const prefix = "editorPage.subConfig.basic.ignoreFailedRemoteSub";
    return [
      {
        value: "disabled",
        label: t(`${prefix}.disabled`),
        note: t(`${prefix}.disabledNote`),
      },
      {
        value: "enabled",
        label: t(`${prefix}.enabled`),
        note: t(`${prefix}.enabledNote`),
      },
      {
        value: "quiet",
        label: t(`${prefix}.quiet`),
        note: t(`${prefix}.quietNote`),
      },
      {
        value: "fallbackNotify",
        label: t(`${prefix}.fallbackNotify`),
        note: t(`${prefix}.fallbackNotifyNote`),
      },
      {
        value: "fallbackQuiet",
        label: t(`${prefix}.fallbackQuiet`),
        note: t(`${prefix}.fallbackQuietNote`),
      },
    ];
  });
  const formatFailureModePickerText = (label: string, note?: string) => {
    if (!note) return label;
    return locale.value.startsWith("zh")
      ? `${label}（${note}）`
      : `${label} (${note})`;
  };
  const subFailureModeValue = computed(() => {
    return form.ignoreFailedRemoteSub === false || form.ignoreFailedRemoteSub == null
      ? "disabled"
      : form.ignoreFailedRemoteSub;
  });
  const subFailureModeColumns = computed(() => {
    return subFailureModeOptions.value.map((option) => ({
      text: formatFailureModePickerText(option.label, option.note),
      value: option.value,
    }));
  });
  const subFailureModeLabel = computed(() => {
    return subFailureModeOptions.value.find(
      (option) => option.value === subFailureModeValue.value
    )?.label || "";
  });
  const showSubFailureModePicker = ref(false);
  const selectedSubFailureMode = ref<string[]>([]);
  const openSubFailureModePicker = () => {
    selectedSubFailureMode.value = [subFailureModeValue.value];
    showSubFailureModePicker.value = true;
  };
  const handleSubFailureModeConfirm = ({ selectedValue }) => {
    const nextValue =
      selectedValue[0] ?? subFailureModeColumns.value[0]?.value ?? "disabled";
    selectedSubFailureMode.value = [nextValue];
    form.ignoreFailedRemoteSub = nextValue;
    showSubFailureModePicker.value = false;
  };
  const compareTableIsVisible = ref(false);
  usePopupRoute(compareTableIsVisible);
  const compareData = ref();

let scrollTop = 0;
const isInit = ref(false);
const ruleForm = ref<any>(null);
const actionsChecked = reactive([]);
const actionsList = reactive([]);
const isget = ref(false);
const form = reactive<any>({
  name: "",
  displayName: "",
  form: "",
  remark: "",
  mergeSources: "",
  ignoreFailedRemoteSub: false,
  passThroughUA: false,
  noFlow: undefined,
  icon: "",
  isIconColor: true,
  iconFit: undefined,
  process: [
    {
      type: "Quick Setting Operator",
    },
  ],
});
provide("form", form);

// 排除非动作卡片
const ignoreList = ["Quick Setting Operator"];
watch(
  () => cmStore.EditCode['SubEditer'],
  (newCode) => {
    form.content = newCode;
  }
);

watchEffect(() => {
  if (isInit.value) return;
  if (configName === "UNTITLED") {
    // 新建时，初始化表单
    switch (editType) {
      case "collections":
        form.subscriptions = [];
        form.firstSubFlow = true;
        break;
      case "subs":
        form.source = "remote";
        form.url = "";
        form.content = "";
        form.ua = "";
        form.noCache = false;
        cmStore.setEditCode('SubEditer', "");
        break;
    }
    // 标记 加载完成
    isInit.value = true;
    return;
  }

  const sourceData: any = toRaw(sub.value) || toRaw(collection.value);
  if (!sourceData) {
    return;
  }
  if (!Array.isArray(sourceData.process)) {
    sourceData.process = [];
  }
  const newProcess = JSON.parse(JSON.stringify(sourceData.process));
  form.mergeSources = sourceData.mergeSources;
  let ignoreFailedRemoteSub = sourceData.ignoreFailedRemoteSub;
  if (ignoreFailedRemoteSub === true) {
    ignoreFailedRemoteSub = 'quiet';
  } else if (ignoreFailedRemoteSub === false || ignoreFailedRemoteSub == null) {
    ignoreFailedRemoteSub = 'disabled';
  }
  form.ignoreFailedRemoteSub = ignoreFailedRemoteSub;
  form.passThroughUA = sourceData.passThroughUA;
  form["age-public-key"] = sourceData["age-public-key"] || "";
  form.name = sourceData.name;
  form.displayName = sourceData.displayName || sourceData["display-name"];
  form.remark = sourceData.remark;
  form.icon = sourceData.icon;
  form.isIconColor = sourceData.isIconColor !== false;
  form.iconFit = normalizeOptionalImageFit(sourceData.iconFit);
  form.editorLanguage = sourceData.editorLanguage;
  form.process = newProcess;
  form.noFlow = sourceData.noFlow;
  form.subUserinfo = sourceData.subUserinfo;
  form.proxy = sourceData.proxy;
  form.tag = Array.isArray(sourceData.tag)
    ? sourceData.tag.join(", ")
    : sourceData.tag;
  form.subscriptionTags = Array.isArray(sourceData.subscriptionTags)
    ? sourceData.subscriptionTags.join(", ")
    : sourceData.subscriptionTags;

  switch (editType) {
    case "collections":
      form.subscriptions = Array.isArray(sourceData.subscriptions)
        ? [...sourceData.subscriptions]
        : [];
      form.firstSubFlow = sourceData.firstSubFlow !== false;
      console.log('form.subscriptions ==>', form.subscriptions);
      break;
    case "subs":
      form.source = sourceData.source;
      form.url = sourceData.url;
      form.content = sourceData.content;
      cmStore.setEditCode('SubEditer', sourceData.content);
      form.ua = sourceData.ua;
      form.noCache = sourceData.noCache === true;
      form._savedUA = sourceData._savedUA;
      if(form.passThroughUA && form.ua){
        showNotify({
          type: "warning",
          title: t(`editorPage.subConfig.basic.passThroughUA.warning`),
          duration: 65535,
        });
      }
      break;
  }

  if (sourceData.process.length > 0) {
    form.process.forEach((item) => {
      const { type, id, customName, disabled } = item;

      if (!ignoreList.includes(type)) {
        actionsChecked.push([id, type !== "Response Transformer"]);
        const action = {
          type,
          id,
          customName,
          tipsDes: t(`editorPage.subConfig.nodeActions['${type}'].tipsDes`),
          component: null,
          enabled: !disabled,
        };
        switch (type) {
          case "Flag Operator":
          case "Sort Operator":
          case "Resolve Domain Operator":
            action.component = shallowRef(ActionRadio);
            break;
          case "Region Filter":
          case "Type Filter":
            action.component = shallowRef(FilterSelect);
            break;
          case "Regex Filter":
          case "Regex Sort Operator":
          case "Regex Delete Operator":
          case "Regex Rename Operator":
            action.component = shallowRef(Regex);
            break;
          case "Handle Duplicate Operator":
            action.component = shallowRef(HandleDuplicate);
            break;
          case "Script Filter":
          case "Script Operator":
          case "Response Transformer":
            action.component = shallowRef(Script);
            break;
          default:
            break;
        }
        actionsList.push(action);
      }
    });
  }
  // 标记 加载完成
  isInit.value = true;
  return;
});

const addAction = (val) => {
  addItem(form, actionsList, actionsChecked, val, t);
};

const setEditorLanguage = (language) => {
  form.editorLanguage = language || null;
};

const deleteAction = (id) => {
  deleteItem(form, actionsList, actionsChecked, id);
};

const toggleAction = (id) => {
  toggleItem(actionsList, id);
};

const closeCompare = () => {
  document.querySelector("html").style["overflow-y"] = "";
  document.querySelector("html").style.height = "";
  document.body.style.height = "";
  document.body.style["overflow-y"] = "";
  (document.querySelector("#app") as HTMLElement).style["overflow-y"] = "";
  (document.querySelector("#app") as HTMLElement).style.height = "";

  compareTableIsVisible.value = false;

  window.scrollTo({
    top: scrollTop,
    behavior: "instant" as any,
  });

  router.back();
};
const fetchCompareData = async () => {
  Toast.loading("生成节点对比中...", {
    id: "compare",
    cover: true,
    duration: 1500,
  });
  try {
    const data: any = JSON.parse(JSON.stringify(toRaw(form)));
    data.process = actionsToProcess(data.process, actionsList, ignoreList);
    if (data.ignoreFailedRemoteSub === "disabled") {
      data.ignoreFailedRemoteSub = false;
    }
    if (editType === "collections") {
      data.firstSubFlow = data.firstSubFlow !== false;
    } else {
      delete data.firstSubFlow;
    }
    data.tag = [
      ...new Set(
        (data.tag || "")
          .split(",")
          .map((item: string) => item.trim())
          .filter((item: string) => item.length)
      ),
    ];
    data.subscriptionTags = [
      ...new Set(
        (data.subscriptionTags || "")
          .split(",")
          .map((item: string) => item.trim())
          .filter((item: string) => item.length)
      ),
    ];
    actionsChecked.forEach((item) => {
      if (!item[1]) {
        const index = data.process.findIndex((i) => i.id === item[0]);
        if (index > -1) {
          data.process.splice(index, 1);
        }
      }
    });
    // if (configName !== "UNTITLED") {
    //   await subsStore.fetchFlows(ref([data]).value);
    // }
    const type = editType === "collections" ? "collection" : "sub";
    const res = await subsApi.compareSub(type, data);
    if (res?.data?.status === "success") {
      compareData.value = res.data.data;
    } else {
      compareData.value = null;
    }
  } catch (e) {
    console.error(e);
    compareData.value = null;
  }
  Toast.hide("compare");
};

const openComparePanel = () => {
  scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
  globalStore.setSavedPositions(route.path, { left: 0, top: scrollTop });

  document.querySelector("html").style["overflow-y"] = "hidden";
  document.querySelector("html").style.height = "100%";
  document.body.style.height = "100%";
  document.body.style["overflow-y"] = "hidden";
  (document.querySelector("#app") as HTMLElement).style["overflow-y"] = "hidden";
  (document.querySelector("#app") as HTMLElement).style.height = "100%";

  compareTableIsVisible.value = true;
};

const compare = () => {
  ruleForm.value.validate().then(async ({ valid, errors }: any) => {
    if (!valid) {
      focusValidationErrorTab(errors);
      Dialog({
        title: t(`editorPage.subConfig.pop.errorTitle`),
        content: errors[0].message,
        popClass: "auto-dialog",
        noCancelBtn: true,
        okText: t(`editorPage.subConfig.pop.errorBtn`),
        // @ts-ignore
        closeOnClickOverlay: true,
      });
      return;
    }
    await fetchCompareData();
    openComparePanel();
  });
};

const refreshCompare = async () => {
  await fetchCompareData();
};

const passThroughUAOn = computed(() => {
  return form.source === "remote" && form.passThroughUA;
});

const userAgentPlaceholder = computed(() => {
  return passThroughUAOn.value
    ? t(`editorPage.subConfig.basic.ua.placeholderDisabled`)
    : t(`editorPage.subConfig.basic.ua.placeholder`);
});

const handlePassThroughUAChange = (val) => {
  if (val) {
    form._savedUA = form.ua;
    form.ua = "";
  } else {
    if (form._savedUA !== undefined) {
      form.ua = form._savedUA;
      form._savedUA = undefined;
    }
  }
};

const submit = () => {
  if (isget.value) {
    showNotify({
      type: "success",
      title: "拉取订阅中，请勿重复点击...",
    });
    return;
  }
  ruleForm.value.validate().then(async ({ valid, errors }: any) => {
    isget.value = true;
    // 如果验证失败
    if (!valid) {
      isget.value = false;
      focusValidationErrorTab(errors);
      Dialog({
        title: t(`editorPage.subConfig.pop.errorTitle`),
        content: errors[0].message,
        popClass: "auto-dialog",
        noCancelBtn: true,
        okText: t(`editorPage.subConfig.pop.errorBtn`),
        // @ts-ignore
        closeOnClickOverlay: true,
      });
      return;
    }
    Toast.loading("拉取订阅中...", {
      id: "submits",
      cover: true,
      duration: 1500,
    });
    // 如果验证成功，开始保存/修改
    const data: any = JSON.parse(JSON.stringify(toRaw(form)));
    const iconFit = normalizeOptionalImageFit(form.iconFit);
    if (iconFit) {
      data.iconFit = iconFit;
    } else if (configName === "UNTITLED") {
      delete data.iconFit;
    } else {
      data.iconFit = null;
    }
    const agePublicKey = `${data["age-public-key"] || ""}`.trim();
    if (agePublicKey) {
      data["age-public-key"] = agePublicKey;
    } else if (configName === "UNTITLED") {
      delete data["age-public-key"];
    } else {
      data["age-public-key"] = null;
    }
    data.tag = [
      ...new Set(
        (data.tag || "")
          .split(",")
          .map((item: string) => item.trim())
          .filter((item: string) => item.length)
      ),
    ];
    data.subscriptionTags = [
      ...new Set(
        (data.subscriptionTags || "")
          .split(",")
          .map((item: string) => item.trim())
          .filter((item: string) => item.length)
      ),
    ];
    data["display-name"] = data.displayName;
    data.process = actionsToProcess(data.process, actionsList, ignoreList);
    if (data.ignoreFailedRemoteSub === "disabled"){
      data.ignoreFailedRemoteSub = false;
    }
    if (editType === "collections") {
      data.firstSubFlow = data.firstSubFlow !== false;
    } else {
      delete data.firstSubFlow;
    }

    console.log('submit.....\n', data);

    let res = null;

    if (configName === "UNTITLED") {
      res = await subsApi.createSub(editType, data);
      await subsStore.fetchSubsData();
      if (data.source === "remote") await initStores(false, true, false);
    } else {
      let apiType = "";
      if (editType === "subs") {
        apiType = "sub";
      } else if (editType === "collections") {
        apiType = "collection";
      }
      res = await subsApi.editSub(apiType, configName, data);

      if (configName === data.name) {
        // @ts-ignore
        await subsStore.updateOneData(editType, configName);
      } else {
        await subsStore.fetchSubsData();
        await useArtifactsStore().fetchArtifactsData();
      }
    }

    if (res?.data?.status === "success") {
      router.replace("/").then(() => {
        if (res)
          showNotify({
            type: "success",
            title: t(`editorPage.subConfig.pop.succeedMsg`),
          });
      });
    }
    isget.value = false;
    Toast.hide("submits");
  });
};

// 名称验证器
const nameValidator = (val: string): Promise<boolean> => {
  return new Promise((resolve) => {
    if (val === "UNTITLED") resolve(false);
    if (/\//.test(val)) {
      resolve(false);
    }
    const nameList = [
      ...subsStore.subs.map((item) => item.name),
      ...subsStore.collections.map((item) => item.name),
    ];
    nameList.includes(val) && configName !== val
      ? resolve(false)
      : resolve(true);
  });
};

// url 格式验证器
const urlValidator = (val: string): Promise<boolean> => {
  return new Promise((resolve) => {
    if (/\n/.test(val)) {
      resolve(
        val
          .split(/[\r\n]+/)
          .map((i) => i.trim())
          .filter((i) => i.length)
          .every((i) => /^(http|https):\/\/\S+$/.test(i) || /^\/api\/(file|module)\/(.+)/.test(i) || /^\/.+/.test(i))
      );
    } else {
      resolve(/^(http|https):\/\/\S+$/.test(val) || /^\/api\/(file|module)\/(.+)/.test(val) || /^\/.+/.test(val));
    }
  });
};

  // 失去焦点触发验证
  const customerBlurValidate = (prop: string) => {
    ruleForm.value.validate(prop);
  };
  // 去除空格
  const strTrim = (prop: string) => {
    if (typeof form[prop] === "string") {
      // 去除首尾空格
      form[prop] = form[prop].trim();
    }
  }
  // 图标
  const subIcon = computed(() => {
    if (form.icon) {
      return rewriteGithubUrl(form.icon)
    } else {
      return rewriteGithubUrl(appearanceSetting.value.isDefaultIcon ? logoIcon : logoRedIcon)
    }
  })
  const formIconFit = computed(() => resolveImageFit(form.iconFit, appearanceSetting.value.iconFit));
  const iconPopupVisible = ref(false)
  const showIconPopup = () => {
    iconPopupVisible.value = true
  }
  const setIcon = (icon: any) => {
    form.icon = icon.url
  }
  const uaTips = () => {
    Dialog({
        title: '默认使用配置中的全局 UA',
        content: '可尝试设置为 clash-verge/v2.4.6, v2rayNG 等客户端的 User-Agent 让机场后端下发更多协议(可根据实际情况改成最新版本号)',
        popClass: 'auto-dialog',
        okText: 'OK',
        noCancelBtn: true,
        closeOnPopstate: true,
        lockScroll: false,
      });
  };
  const subUserinfoTips = () => {
    Dialog({
        title: '手动设置订阅流量信息',
        content: '若填写链接, 则使用链接的响应体内容/响应头 subscription-userinfo 作为值. 链接支持 headers/noCache/headersCacheTtl 等参数.\n\n此项值的格式为:\n\nupload=1024; download=10240; total=102400; expire=4115721600; reset_day=14; plan_name=VIP1; app_url=http://a.com\n\n1. app_url, 订阅将有一个可点击跳转的按钮\n\n2. plan_name, hover 时将显示套餐名称\n\n3. reset_day, 流量重置剩余天数(若要设置周期性重置, 可查看订阅链接中的参数说明)\n\n⚠️ 注意: 手动设置的订阅流量信息会附加到订阅自己的流量信息之前. 若包含不合法的内容, 订阅将无法正常使用\n\n例如: http://官网.com 应编码为 http%3A%2F%2F%E5%AE%98%E7%BD%91.com',
        popClass: 'auto-dialog',
        okText: 'OK',
        noCancelBtn: true,
        closeOnPopstate: true,
        lockScroll: false,
      });
  };
  const firstSubFlowTips = () => {
    Dialog({
        title: t(`editorPage.subConfig.basic.firstSubFlow.tips.title`),
        content: t(`editorPage.subConfig.basic.firstSubFlow.tips.content`),
        popClass: 'auto-dialog',
        textAlign: 'left',
        okText: t(`editorPage.subConfig.basic.firstSubFlow.tips.okText`),
        noCancelBtn: true,
        closeOnPopstate: true,
        lockScroll: false,
        onOk: () => {
          window.open("https://telegram.me/zhetengsha/3070");
        },
      });
  };
  const proxyTips = () => {
    Dialog({
        title: '通过代理/节点/策略获取订阅',
        content: '1. Surge/Egern(参数 policy/policy-descriptor)\n\n可设置节点代理 例: Test = snell, 1.2.3.4, 80, psk=password, version=4\n\n或设置策略/节点 例: 国外加速\n\n2. Loon(参数 node)\n\nLoon 官方文档: \n\n指定该请求使用哪一个节点或者策略组（可以是节点名称、策略组名称，也可以是一个 Loon 格式的节点描述，如：shadowsocksr,example.com,1070,chacha20-ietf,"password",protocol=auth_aes128_sha1,protocol-param=test,obfs=plain,obfs-param=edge.microsoft.com）\n\n3. Stash(参数 headers["X-Surge-Policy"])/Shadowrocket(参数 headers.X-Surge-Policy)/QX(参数 opts.policy)\n\n可设置策略/节点\n\n4. Node.js 版(http/https/socks5):\n\n例: socks5://a:b@127.0.0.1:7890\n\n※ 优先级由高到低: 单条订阅, 组合订阅, 默认配置\n\n完整说明 请查看 https://telegram.me/zhetengsha/1843',
        popClass: 'auto-dialog',
        textAlign: 'left',
        okText: 'OK',
        noCancelBtn: true,
        closeOnPopstate: true,
        lockScroll: false,
      });
  };
  const subscriptionTagsTips = () => {
    Dialog({
        title: '组合订阅与单条订阅',
        content: '组合订阅中将包含\n\n1. 含有关联订阅标签的单条订阅\n\n2. 手动选择的单条订阅\n\n举例: 设置了关联订阅标签为 "A, B" 后\n包含标签 "A" 或 "B" 的单条订阅将自动关联到此组合订阅',
        popClass: 'auto-dialog',
        textAlign: 'left',
        okText: 'OK',
        noCancelBtn: true,
        closeOnPopstate: true,
        lockScroll: false,
      });
  };
  const urlTips = () => {
    Dialog({
        title: t('editorPage.subConfig.basic.url.tips.title'),
        content: t('editorPage.subConfig.basic.url.tips.content'),
        popClass: 'auto-dialog',
        textAlign: 'left',
        okText: 'OK',
        noCancelBtn: true,
        closeOnPopstate: true,
        lockScroll: false,
      });
  };
  const ageOutputTips = () => {
    Dialog({
        title: t('ageKey.publicKey.tips.title'),
        content: t('ageKey.publicKey.tips.content'),
        popClass: 'auto-dialog',
        textAlign: 'left',
        okText: 'OK',
        noCancelBtn: true,
        closeOnPopstate: true,
        lockScroll: false,
      });
  };
  const normalizeTagList = (value: any): string[] => {
    const source = Array.isArray(value) ? value : String(value || "").split(",");
    return source
      .map((item) => String(item).trim())
      .filter((item) => item.length);
  };
  const getMatchingCollectionGroup = () => {
    const collectionTags = normalizeTagList(form.tag);
    if (collectionTags.length === 0) return "";

    const subTagSet = new Set<string>();
    subsSelectList.value.forEach(([, , , subTags]) => {
      normalizeTagList(subTags).forEach((item) => subTagSet.add(item));
    });

    return collectionTags.find((item) => subTagSet.has(item)) || "";
  };
  const isManualSubscriptionsGroupAvailable = (group: string) => {
    if (group === "all") return true;
    if (!Array.isArray(tags.value) || tags.value.length === 0) return false;

    return tags.value.some((item) => item.value === group);
  };
  const applyInitialManualSubscriptionsGroup = () => {
    if (editType !== "collections") return;
    if (!isInit.value) return;
    if (manualSubscriptionsGroupInitialized.value || manualSubscriptionsGroupTouched.value) return;
    if (tag.value !== "all") return;

    const rememberedGroup = getEditorRouteValue(
      MANUAL_SUBSCRIPTIONS_GROUP_STORAGE_KEY,
      route.path,
    );
    if (rememberedGroup && isManualSubscriptionsGroupAvailable(rememberedGroup)) {
      tag.value = rememberedGroup;
      manualSubscriptionsGroupInitialized.value = true;
      return;
    }
    if (rememberedGroup && subsSelectList.value.length === 0) return;

    const matchedGroup = getMatchingCollectionGroup();
    if (!matchedGroup) return;

    tag.value = matchedGroup;
    manualSubscriptionsGroupInitialized.value = true;
  };
  const setTag = (current) => {
    manualSubscriptionsGroupTouched.value = true;
    tag.value = current;
    setEditorRouteValue(
      MANUAL_SUBSCRIPTIONS_GROUP_STORAGE_KEY,
      route.path,
      current,
    );
  };
  const shouldShowElement = (element) => {
    if(tag.value === 'all') return true
    if(tag.value === 'untagged') return !Array.isArray(element) || element.length === 0
    return element.includes(tag.value)
  };
  const ensureSubscriptions = (): string[] => {
    if (!Array.isArray(form.subscriptions)) {
      form.subscriptions = [];
    }
    return form.subscriptions;
  };
  const hasSameSubscriptions = (left: string[], right: string[]) => {
    return left.length === right.length && left.every((name, index) => name === right[index]);
  };
  const skipNextDisplayedListSync = ref(false);
  const replaceSubscriptions = (
    nextSubscriptions: string[],
    options?: { preserveDisplayedOrder?: boolean },
  ) => {
    const subscriptions = ensureSubscriptions();

    if (hasSameSubscriptions(subscriptions, nextSubscriptions)) {
      return;
    }

    if (options?.preserveDisplayedOrder) {
      skipNextDisplayedListSync.value = true;
    }

    subscriptions.splice(0, subscriptions.length, ...nextSubscriptions);
  };
  const syncSubscriptionsFromRows = (rows: SubSelectRow[]) => {
    const selectedSet = new Set(ensureSubscriptions());
    const nextSubscriptions = rows
      .filter(([name]) => selectedSet.has(name))
      .map(([name]) => name);

    replaceSubscriptions(nextSubscriptions, { preserveDisplayedOrder: true });
  };
  const selectedSubscriptions = computed(() => {
    return Array.isArray(form.subscriptions) ? form.subscriptions : [];
  });
  const isRowVisibleByName = (name: string) => {
    const row = subsSelectList.value.find((item) => item[0] === name);
    return row ? shouldShowElement(row[3]) : false;
  };
  const orderedSubsSelectList = computed<SubSelectRow[]>(() => {
    const selectedRows = selectedSubscriptions.value
      .map(name => subsSelectList.value.find(item => item[0] === name))
      .filter((item): item is SubSelectRow => Boolean(item));
    const selectedSet = new Set(selectedRows.map(([name]) => name));

    return [
      ...selectedRows,
      ...subsSelectList.value.filter(([name]) => !selectedSet.has(name)),
    ];
  });
  const getCurrentVisibleRows = () => {
    if (displayedSubsSelectList.value.length > 0) {
      return displayedSubsSelectList.value;
    }

    return orderedSubsSelectList.value.filter((item) => shouldShowElement(item[3]));
  };
  const visibleSelectedSubscriptions = computed<string[]>({
    get: () => {
      return selectedSubscriptions.value.filter((name) => isRowVisibleByName(name));
    },
    set: (visibleSelectedNames) => {
      const subscriptions = ensureSubscriptions();
      const visibleRowOrder = getCurrentVisibleRows().map(([name]) => name);
      const visibleSet = new Set(visibleRowOrder);
      const visibleSelectedSet = new Set(visibleSelectedNames);
      const visibleSelectedRowOrder = visibleRowOrder.filter((name) => visibleSelectedSet.has(name));
      const nextSubscriptions = subscriptions.filter((name) => {
        return !visibleSet.has(name) || visibleSelectedSet.has(name);
      });
      const findExistingIndex = (name: string) => nextSubscriptions.indexOf(name);

      visibleSelectedRowOrder.forEach((name, index) => {
        if (findExistingIndex(name) > -1) return;

        const nextVisibleAnchor = visibleSelectedRowOrder
          .slice(index + 1)
          .find((candidate) => findExistingIndex(candidate) > -1);

        if (nextVisibleAnchor) {
          nextSubscriptions.splice(findExistingIndex(nextVisibleAnchor), 0, name);
          return;
        }

        const previousVisibleAnchor = visibleSelectedRowOrder
          .slice(0, index)
          .reverse()
          .find((candidate) => findExistingIndex(candidate) > -1);

        if (previousVisibleAnchor) {
          nextSubscriptions.splice(findExistingIndex(previousVisibleAnchor) + 1, 0, name);
          return;
        }

        nextSubscriptions.push(name);
      });

      replaceSubscriptions(nextSubscriptions, { preserveDisplayedOrder: true });
    },
  });
  const mergeVisibleOrder = <T>(
    source: T[],
    reorderedVisibleItems: T[],
    shouldInclude: (item: T) => boolean,
  ) => {
    let visibleIndex = 0;

    return source.map((item) => {
      if (!shouldInclude(item)) {
        return item;
      }

      const reorderedItem = reorderedVisibleItems[visibleIndex];
      visibleIndex += 1;
      return reorderedItem ?? item;
    });
  };
  const subCheckboxIndeterminate = ref(true);
  const subCheckbox = ref(true);
  // const subCheckboxChange = (v) => {
  //   console.log(`${!v} -> ${v}`)
  // };
  const subCheckboxClick = () => {
    const group = getCurrentVisibleRows().map(([name]) => name);
    if (subCheckboxIndeterminate.value) {
      console.log(`半选, 应变为全选`)  
      visibleSelectedSubscriptions.value = group;
    } else if (!subCheckbox.value) {
      console.log(`全选, 应变为不选`)
      visibleSelectedSubscriptions.value = [];
      // subCheckbox.value = !subCheckbox.value
    } else {
      console.log(`不选, 应变为全选`)
      visibleSelectedSubscriptions.value = group;
      // subCheckbox.value = !subCheckbox.value
    }
    subCheckboxIndeterminate.value = false
  };
  const displayedSubsSelectList = ref<SubSelectRow[]>([]);
  const isDragging = ref(false);
  const syncDisplayedSubsSelectList = () => {
    displayedSubsSelectList.value = orderedSubsSelectList.value.filter((item) => shouldShowElement(item[3]));
  };

  const onStartDrag = () => {
    console.log("开始拖拽");
    isDragging.value = true;
  };

  const onEndDrag = () => {
    console.log("结束拖拽");
    const mergedRows = mergeVisibleOrder(
      orderedSubsSelectList.value,
      displayedSubsSelectList.value,
      (item) => shouldShowElement(item[3]),
    );
    isDragging.value = false;
    syncSubscriptionsFromRows(mergedRows);
    syncDisplayedSubsSelectList();
  };
  watch([() => form.tag, subsSelectList, tags, isInit], () => {
    applyInitialManualSubscriptionsGroup();
  }, { immediate: true, deep: true });
  watch([tag, subsSelectList], () => {
    if (isDragging.value) return;
    syncDisplayedSubsSelectList();
  }, { immediate: true });
  watch(selectedSubscriptions, () => {
    if (isDragging.value) return;
    if (skipNextDisplayedListSync.value) {
      skipNextDisplayedListSync.value = false;
      return;
    }
    syncDisplayedSubsSelectList();
  }, { deep: true });
  watch([tag, selectedSubscriptions, subsSelectList], () => {
    const selected = toRaw(selectedSubscriptions.value) || []
    const group = subsSelectList.value.filter(item => shouldShowElement(item[3])).map(item => item[0]) || []
    // 1. group 中不包含 selected 中的任何元素, subCheckbox 为 false, subCheckboxIndeterminate 为 false
    // 2. group 中包含 selected 中的任意元素, subCheckbox 为 true, subCheckboxIndeterminate 为 true
    // 3. group 中包含 selected 中的所有元素, subCheckbox 为 true, subCheckboxIndeterminate 为 false
    if (group.every(item => selected.includes(item))) {
      // console.log('group 中包含 selected 中的所有元素')
      subCheckbox.value = true
      subCheckboxIndeterminate.value = false
    } else if (group.some(item => selected.includes(item))) {
      // console.log('group 中包含 selected 中的任意元素')
      subCheckbox.value = true
      subCheckboxIndeterminate.value = true
    } else {
      // console.log('group 中不包含 selected 中的任意元素')
      subCheckbox.value = false
      subCheckboxIndeterminate.value = false
    }
  }, { immediate: true, deep: true });
  // const subCheckboxIndeterminate = computed(() => {
  //   const selected = toRaw(form.subscriptions)
  //   const currentGroup = subsSelectList.value.filter(item => shouldShowElement(item[3])).map(item => item[0])
  //   return true
  // });

const actionBlockRef = ref(null)
const customNameModeFlag = ref(false)
const updateCustomNameModeFlag = (flag) => customNameModeFlag.value = flag
const handleEditGlobalClick = () => {
  if (actionBlockRef.value) {
    if (customNameModeFlag.value) {
      // exit
      actionBlockRef.value.exitAllEditName();
    }
  }
}
</script>

<style lang="scss" scoped>
.page-wrapper {
  padding: 0 var(--safe-area-side) calc(v-bind("padding") + 63px)
    var(--safe-area-side);

  :deep(.nut-cell-group__warp) {
    border-radius: var(--item-card-radios);
  }
  :deep(.nut-icon-tips:before), :deep(.nut-icon-shop:before) {
    cursor: pointer;
  }
}
.tag-check {
  display: flex;
  justify-content: space-between;
  :deep(.nut-checkbox__label) {
    margin-left: 0;
    margin-right: 0;
  }
}
.radio-wrapper {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;

  :deep(.nut-radiogroup) {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-end;
    align-items: center;
    gap: 5px;
  }

  :deep(.nut-radio) {
    display: inline-flex;
    align-items: center;
    margin: 0;
    line-height: 1;
  }

  :deep(.nut-radio__button.false) {
    background: var(--divider-color);
    border-color: transparent;
    color: var(--second-text-color);
  }
  :deep(.nut-radio__button) {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
    height: 30px;
    padding: 0 9px;
    line-height: 18px;
    white-space: nowrap;
  }
}

.form-block-wrapper {
  position: relative;
  .sticky-title-icon-container {
    display: flex;
    justify-content: center;
    .nut-image {
      cursor: pointer;
      width: 70px;
      height: 70px;
      border-radius: 10px;
      overflow: hidden;
      background: transparent;
      padding: 10px;
      :deep(img) {
        width: 100%;
        height: 100%;
        border-radius: 12px;
      }
    }
    .sub-item-customer-icon {
      :deep(img) {
        & {
          opacity: 0.8;
          filter: brightness(var(--img-brightness));
        }
      }
    }
  }
  .button-tips {
    color: var(--primary-color);
    cursor: pointer;
    font-size: 12px;
    text-decoration: underline;
    margin-left: 6px;
  }
  .label-tips {
    display: inline-flex;
    flex-direction: column;
    cursor: pointer;
    .tips {
      display: inline-flex;
      align-items: center;
      span {
        color: var(--primary-color);
        text-decoration: underline;
        font-size: 12px;
        // color: #fa2c19;
      }
    }
  }
  .label-with-tip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;

    :deep(.nut-icon) {
      color: inherit;
    }

    :deep(.nut-icon-tips) {
      display: inline-flex;
      width: 20px;
      height: 20px;
      flex: 0 0 auto;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      line-height: 20px;
    }
  }
  :deep(.nut-form-item__label) {
    width: auto;
  }
  :deep(.nut-input-text){
    .nut-input-inner {
      .nut-input-right-icon {
        margin-left: 8px;
      }
    }
  }
}

.bottom-btn-wrapper {
  position: fixed;
  display: flex;
  justify-content: space-between;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 8px var(--safe-area-side) calc(v-bind("padding") + 8px)
    var(--safe-area-side);
  z-index: 20;
  background: var(--background-color);
  border-top: 1px solid var(--divider-color);
  @include centered-fixed-container;

  .btn {
    border-radius: 8px;
    padding: 4px 12px;
    font-size: 14px;
    display: flex;
    justify-content: center;
    align-items: center;
    svg {
      margin-right: 4px;
    }
  }

  .compare-btn {
    background: transparent;
    width: 36%;
  }

  .submit-btn {
    width: 62%;
  }
}

.ignore-failed-wrapper {
  flex-direction: row;
  justify-content: space-between;
  :deep(.nut-form-item__label) {
    width: auto;
  }
  .switch-wrapper {
    display: flex;
    justify-content: flex-end
  }
}

.failure-mode-input {
  cursor: pointer;

  :deep(.nut-input),
  :deep(.nut-input-value),
  :deep(.nut-input-inner),
  :deep(.nut-input-box),
  :deep(.input-text),
  :deep(.nut-input__text--readonly),
  :deep(.nut-input-right-icon) {
    cursor: pointer;
  }
}

.failure-mode-trigger {
  :deep(.nut-form-item__body),
  :deep(.nut-cell__value) {
    cursor: pointer;
  }
}

.include-subs-trigger {
  cursor: pointer;

  :deep(.nut-form-item__label),
  :deep(.nut-form-item__body),
  :deep(.nut-cell__title),
  :deep(.nut-cell__value),
  :deep(.nut-input),
  :deep(.nut-input-value),
  :deep(.nut-input-inner),
  :deep(.nut-input-right-icon),
  :deep(input) {
    cursor: pointer;
  }

  :deep(.include-subs-trigger-input .nut-input-inner .nut-input-right-icon) {
    margin-left: 14px;
  }
}

.age-key-field {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 8px;
  align-items: center;
  width: 100%;
}

.include-subs-wrapper {
  display: flex;
  flex-direction: column;
  padding: 0 24px 12px;

  .tag-check {
    flex: 1;
    min-width: 0;
  }

  .radio-wrapper {
    display: flex;
    justify-content: flex-start;

    // :deep(.nut-radio__button.false) {
    //   background: var(--divider-color);
    //   border-color: transparent;
    //   color: var(--second-text-color);
    // }
    .tag {
      font-size: 12px;
      color: var(--second-text-color);
      margin: 0px 5px 0 0;
      padding: 7.5px 2.5px 4px;
      cursor: pointer;
      -webkit-user-select: none;
      user-select: none;
      border-bottom: 1px solid transparent;
    }
    .current {
      border-bottom: 1px solid var(--primary-color);
      color: var(--primary-color);
    }
  }

  :deep(.nut-form-item__label) {
    width: 100%;
    font-size: 12px;
    // margin-bottom: 12px;
  }

  .subs-checkbox-wrapper {
    flex-direction: row-reverse;

    &.is-dragging {
      .subs-checkbox,
      .sub-img-wrapper,
      .sub-img-wrapper * {
        -webkit-user-select: none;
        user-select: none;
      }
    }

    &.is-simple-mode {
      .subs-checkbox {
        padding: 10px 0 0 0;

        &:not(:last-child) {
          padding: 10px 0;
        }

        .sub-img-wrapper {
          font-size: 13px;

          .icon {
            margin-right: 6px;
          }

          .sub-item {
            margin: -3px 0 0 -3px;

            .name {
              margin: 3px 0 0 3px;
            }

            .tag {
              margin: 3px 0 0 3px;
            }
          }

          .sub-item-customer-icon {
            margin-right: 8px;
          }

          .drag-handle {
            font-size: 14px;
            padding: 6px;
          }
        }
      }
    }

    .subs-checkbox {
      justify-content: space-between;
      // margin-left: 16px;
      padding: 16px 0 0 0;

      &:not(:last-child) {
        padding: 16px 0 16px 0;
        border-bottom: 1px solid;
        border-color: var(--divider-color);
      }

      .sub-img-wrapper {
        max-width: 100%;
        display: flex;
        align-items: center;
        font-size: 14px;
        color: var(--second-text-color);
        position: relative;
        .icon {
          margin-right: 8px;
        }
        span {
          max-width: 56vw;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 1;
          word-wrap: break-word;
          word-break: break-all;
          overflow: hidden;
        }

        .sub-item {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          margin: -4px 0 0 -4px;
          .name {
            margin: 4px 0 0 4px;
          }
          .tag {
            margin: 4px 0 0 4px;
            // white-space: nowrap;
          }
        }

        .sub-item-customer-icon {
          margin-right: 12px;

          :deep(img) {
            object-fit: var(--icon-fit, cover);

            &:not(.nut-icon__img) {
              filter: brightness(var(--img-brightness));
            }
          }
        }
        .drag-handle {
          position: absolute;
          right: 0;
          top: 50%;
          transform: translateY(-50%);
          color: var(--second-text-color);
          font-size: 16px;
          padding: 10px;
        }
      }
    }
  }
}
</style>
