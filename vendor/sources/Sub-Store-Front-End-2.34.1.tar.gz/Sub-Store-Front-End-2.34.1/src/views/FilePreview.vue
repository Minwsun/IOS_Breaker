<template>
  <Teleport to="#app" :disabled="!!url">
    <div
      class="compare-page-wrapper"
      :class="{ 'compare-page-wrapper-overlay': !url }"
      :style="{ height: url ? 'calc(100vh - 80px)' : '100vh' }"
    >
      <header class="compare-page-header" :class="{ 'preview-popup-header': !url }">
        <template v-if="url">
          <h1>
            <span class="title" @click="copyUrl"><font-awesome-icon class="copy" icon="fa-solid fa-clone" @click="copyUrl" /><span class="titleText">点击复制, 在外部资源中使用:</span></span>
            <span class="displayName">
              <a class="url" :href="url" target="_blank">{{ url }}</a>
            </span>
          </h1>
        </template>
        <template v-else>
          <div class="btn-groups preview-leading">
            <button type="button" class="btn close" @click="clickClose">
              <font-awesome-icon icon="fa-solid fa-xmark" />
            </button>
            <button v-if="showRefresh" type="button" class="btn refresh" @click="emit('refresh')">
              <font-awesome-icon icon="fa-solid fa-arrows-rotate" />
            </button>
          </div>
          <h1 class="preview-popup-title">{{ $t(`comparePage.title`) }}</h1>
          <div class="btn-groups preview-trailing">
            <button
              type="button"
              class="btn logs"
              :aria-label="t('logsPage.floating.open')"
              :title="t('logsPage.floating.open')"
              @click.stop="openLogsOverlay"
            >
              <font-awesome-icon icon="fa-solid fa-file-lines" />
            </button>
          </div>
        </template>
      </header>
      <cmView
        :isReadOnly="true"
        id="filePreview"
        :editor-language="previewLanguage"
        :toolbar-actions="previewToolbarActions"
        toolbar-variant="preview"
        @update:editor-language="setPreviewLanguage"
      />
      <!-- <div class="compare-page-body">
        <div class="block-wrapper">
          <div class="input-wrapper">
            <nut-textarea
              v-model="processedData"
              :rows="23"
              autosize
              placeholder=" "
              readonly
            /> 
          </div>
        </div>
      </div> -->
    </div>
  </Teleport>
</template>

<script lang="ts" setup>
import axios from 'axios';
import { useFilesApi } from "@/api/files";
import { useSubsApi } from "@/api/subs";
import { useSubsStore } from "@/store/subs";
import { Toast } from "@nutui/nutui";
import { computed, ref, watch, watchEffect } from "vue";
import { useI18n } from "vue-i18n";
import { copyText } from "@/utils/clipboard";
import { useAppNotifyStore } from "@/store/appNotify";
import { useLogsOverlayStore } from "@/store/logsOverlay";
import cmView from "@/views/editCode/cmView.vue";
import { useCodeStore } from "@/store/codeStore";
import { useRoute } from 'vue-router';

const cmStore = useCodeStore();
const logsOverlayStore = useLogsOverlayStore();
const { showNotify } = useAppNotifyStore();

const { t } = useI18n();
const subsStore = useSubsStore();
const filesApi = useFilesApi();
const subsApi = useSubsApi();

const route = useRoute();
const { url } = route.query as { url: string };
const props = defineProps<{
  previewData: any;
  name: string;
  showRefresh?: boolean;
}>();
const emit = defineEmits(["closePreview", "refresh"]);

const processedData = ref('')
const previewToolbarActions = ["language", "search", "copy"];
const previewLanguage = ref<string | undefined>(undefined);
const isSavingPreviewLanguage = ref(false);
const loadedPreviewLanguageSources = new Set<string>();
let previewLanguageSyncToken = 0;

type PreviewSourceType = "sub" | "collection" | "file";

const getRouteQueryString = (value: unknown) => {
  if (Array.isArray(value)) return value[0];
  return typeof value === "string" ? value : undefined;
};

const parsePreviewSourceFromUrl = (): { type: PreviewSourceType; name: string } | null => {
  if (!url) return null;

  try {
    const previewUrl = new URL(url, window.location.origin);
    const segments = previewUrl.pathname
      .split("/")
      .map((segment) => decodeURIComponent(segment))
      .filter(Boolean);
    const downloadIndex = segments.findIndex((segment) => segment === "download");
    if (downloadIndex < 0) return null;

    if (segments[downloadIndex + 1] === "collection" && segments[downloadIndex + 2]) {
      return {
        type: "collection",
        name: segments[downloadIndex + 2],
      };
    }

    if (segments[downloadIndex + 1]) {
      return {
        type: "sub",
        name: segments[downloadIndex + 1],
      };
    }
  } catch (error) {
    console.warn("Failed to parse preview source from URL", error);
  }

  return null;
};

const getPreviewSource = (): { type: PreviewSourceType; name: string } | null => {
  if (!url && props.name) {
    return {
      type: "file",
      name: props.name,
    };
  }

  const sourceType = getRouteQueryString(route.query.sourceType);
  const sourceName = getRouteQueryString(route.query.sourceName);
  if (
    sourceName &&
    (sourceType === "sub" || sourceType === "collection" || sourceType === "file")
  ) {
    return {
      type: sourceType,
      name: sourceName,
    };
  }

  return parsePreviewSourceFromUrl();
};

const getPreviewSourceData = (source = getPreviewSource()) => {
  if (!source) return null;

  if (source.type === "file") {
    return subsStore.getOneFile(source.name);
  }
  if (source.type === "collection") {
    return subsStore.getOneCollection(source.name);
  }
  return subsStore.getOneSub(source.name);
};

const getPreviewStoreType = (type: PreviewSourceType) => {
  if (type === "file") return "files";
  if (type === "collection") return "collections";
  return "subs";
};

const getPreviewSourceKey = (source: { type: PreviewSourceType; name: string }) =>
  `${source.type}:${source.name}`;

const syncPreviewLanguageFromSource = async () => {
  if (isSavingPreviewLanguage.value) return;

  const token = ++previewLanguageSyncToken;
  const source = getPreviewSource();
  if (!source) {
    previewLanguage.value = undefined;
    return;
  }

  const sourceKey = getPreviewSourceKey(source);
  let sourceData = getPreviewSourceData(source);
  if (!sourceData && !loadedPreviewLanguageSources.has(sourceKey)) {
    loadedPreviewLanguageSources.add(sourceKey);
    await subsStore.fetchSubsData();

    const currentSource = getPreviewSource();
    if (
      token !== previewLanguageSyncToken ||
      isSavingPreviewLanguage.value ||
      !currentSource ||
      getPreviewSourceKey(currentSource) !== sourceKey
    ) {
      return;
    }

    sourceData = getPreviewSourceData(source);
  }

  previewLanguage.value = sourceData?.previewLanguage || undefined;
};

watchEffect(() => {
  void syncPreviewLanguageFromSource();
});

const setPreviewLanguage = async (language?: string) => {
  previewLanguage.value = language;

  const source = getPreviewSource();
  if (!source) return;

  isSavingPreviewLanguage.value = true;

  try {
    let sourceData = getPreviewSourceData(source);
    if (!sourceData) {
      await subsStore.fetchSubsData();
      sourceData = getPreviewSourceData(source);
    }
    if (!sourceData) return;

    const nextLanguage = language || null;
    if ((sourceData.previewLanguage || null) === nextLanguage) return;

    const data = {
      previewLanguage: nextLanguage,
    };

    const res =
      source.type === "file"
        ? await filesApi.editFile(source.name, data)
        : await subsApi.editSub(source.type, source.name, data as any);

    if (res?.data?.status !== "success") {
      throw new Error("Save preview language failed");
    }

    const nextSourceData = res?.data?.data || {
      ...sourceData,
      previewLanguage: nextLanguage,
    };
    if (!nextLanguage) {
      delete nextSourceData.previewLanguage;
    }

    subsStore.setOneData(
      getPreviewStoreType(source.type),
      source.name,
      nextSourceData
    );
  } catch (error) {
    console.error("Failed to save preview language", error);
    showNotify({
      type: "warning",
      title: "语言选择保存失败",
    });
  } finally {
    isSavingPreviewLanguage.value = false;
  }
};

watchEffect(async () => {
  if (url) {
    try {
      cmStore.setEditCode('filePreview', 'Loading...')
      const response = await axios.get(url as string, {
        responseType: 'text',
        transformResponse: [(data) => data],
      })
      console.log(typeof response.data)
      processedData.value = response.data
      cmStore.setEditCode('filePreview', processedData.value || '')
    } catch (error) {
      let data = error.response?.data
      if (data) {
        try {
          data = JSON.stringify(JSON.parse(error.response?.data), null, 2)
        } catch (e) {
          
        }
      }
      console.error('Error fetching URL:', error, data)
      cmStore.setEditCode('filePreview', `Error: ${
      error.response ? `${error.response.status} ${error.response.statusText}\n\n${data}` : error.message
      }`)
      showNotify({ title: `加载失败: ${error.message}` })
    }
  }
  if (route.query.name) {
    document.title = `${route.query.name} - Sub-Store`
  }
})

const showRefresh = computed(() => props.showRefresh !== false);

const isOriginalVisible = ref(true);
const isProcessedVisible = ref(true);

const displayName = computed(() => {
  if(route.query.name) return route.query.name
  const sub = subsStore.getOneFile(props.name);
  return sub?.displayName || sub?.["display-name"] || props.name;
});

watch(() => props.previewData?.processed, (val) => {
  if (!url && val != null) {
    cmStore.setEditCode('filePreview', val)
  }
}, { immediate: true });

 
const clickClose = () => {
  emit("closePreview");
};
const openLogsOverlay = () => {
  logsOverlayStore.open();
};
const copyUrl = async () => {
  try {
    await copyText(url);
    showNotify({ title: `已复制链接: ${url}` });
  } catch (error) {
    Toast.fail(t("globalNotify.copyFailed", { e: error?.message ?? String(error) }));
  }
};
</script>

<style lang="scss" scoped>
.type-tag {
  padding: 1px 4px;
  line-height: 1;
  margin-right: 3px;
  color: var(--compare-tag-text-color);
  background: var(--compare-tag-background-color);
}

.item-true {
  color: var(--primary-color);
}

.item-false {
  width: 8px;
  height: 1px;
  border-radius: 2px;
  background: var(--lowest-text-color);
}

.name-wrapper {
  display: flex;
  flex-direction: column;
  flex: 1;
  width: 100%;
  min-width: 0;

  > div {
    width: 100%;
    min-width: 0;
    max-width: 100%;
    white-space: normal;
    overflow-wrap: anywhere;
    word-break: break-all;
  }
}

.compare-table-body {
  width: 100%;

  .processed-tr {
    padding-top: 20px;
    padding-bottom: 0;
  }

  .original-tr {
    padding-top: 10px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--divider-color);
  }
}

.compare-table-row {
  padding: 0 var(--safe-area-side);
}

.compare-table-head {
  padding: 10px var(--safe-area-side);
}

.compare-table-head,
.compare-table-row {
  margin: 0;
  display: grid;
  grid-template-columns: 46% 1fr 1fr 1fr 1fr;

  li,
  td {
    display: flex;
    justify-content: center;
    align-items: center;
    min-width: 0;
  }

  li:first-child,
  td:first-child {
    justify-content: start;
  }
}

.compare-table-head {
  position: sticky;
  z-index: 7;
  top: 114px;
  border-bottom: 1px solid var(--divider-color);
  font-weight: bold;
  background: var(--background-color);
  color: var(--comment-text-color);

  &.filter-table-head {
    top: 84px;
  }
}

.processed-item,
.original-item {
  display: flex;
  align-items: center;
  width: 100%;
  min-width: 0;

  &::before {
    content: "";
    display: block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    margin-right: 10px;
    background: var(--primary-color);
    flex-shrink: 0;
  }
}

.indicator {
  margin-right: 24px;
}

.processed-item::before {
  background: var(--third-color);
}

.block-wrapper {
  position: relative;
  background: var(--compare-item-background-color);

  .compare-title {
    padding: 0 var(--safe-area-side);
    z-index: 9;
    margin-top: 0;
    top: 56px;
    background: var(--background-color);
  }

  .compare-des {
    padding: 6px var(--safe-area-side);
    z-index: 8;
    display: flex;
    position: sticky;
    top: 84px;
    background: var(--background-color);
    color: var(--comment-text-color);
  }
}

.compare-page-body {
  font-size: 12px;
  background: inherit;
  color: var(--comment-text-color);
}

.compare-page-header {
  padding: env(safe-area-inset-top) var(--safe-area-side) 0;
  position: sticky;
  top: 0;
  z-index: 19;
  display: flex;
  gap: 12px;
  justify-content: space-between;
  align-items: center;
  min-height: var(--compare-header-offset);
  box-sizing: border-box;
  border-bottom: 1px solid;
  color: var(--primary-text-color);
  background: var(--background-color);
  border-color: var(--divider-color);
  width: 100%;

  &.preview-popup-header {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    gap: 0;
  }

  .title {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    white-space: nowrap;
    cursor: pointer;
    min-width: 0;

    .titleText {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
  .displayName {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    min-width: 0;
    overflow: hidden;
    flex: 1;
    .displayNameText,
    .url {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .displayNameText,
    .url {
      display: block;
    }
    > svg {
      flex-shrink: 0;
    }
    .copy {
      cursor: pointer;
      font-size: 16px;
      flex-shrink: 0;
    }
    .url {
      text-decoration: underline;
    }
  }
  h1 {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    min-width: 0;
    margin: 0;
    font-size: 20px;
    line-height: 1;
    font-weight: 500;

    > svg {
      width: 20px;
      height: 20px;
      flex-shrink: 0;
    }

    span {
      font-size: 14px;
      color: var(--second-text-color);

      > svg {
        color: var(--comment-text-color);
      }
    }
  }

  button {
    cursor: pointer;
    background: none;
    border: none;
    font-size: 20px;
    padding: 8px;
    color: var(--lowest-text-color);
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0;
    &.refresh {
      font-size: 18px;
    }
  }
  .btn-groups {
    display: flex;
    align-items: center;
    flex-shrink: 0;
    gap: 10px;
  }
}

.compare-page-header .preview-leading {
  gap: 0;
  justify-content: flex-start;
}

.compare-page-header .preview-trailing {
  grid-column: 3;
  justify-self: end;
  gap: 0;
  justify-content: flex-end;
}

.compare-page-header .preview-leading button,
.compare-page-header .preview-trailing button {
  width: 32px;
  height: 32px;
  padding: 0;
  color: var(--icon-nav-bar-right);
  display: inline-flex;
  align-items: center;
  justify-content: center;

  :deep(svg) {
    width: 14px;
    height: 14px;
    font-size: 14px;
  }
}

.compare-page-header .preview-popup-title {
  grid-column: 2;
  justify-self: center;
  display: block;
  flex: none;
  margin: 0;
  min-width: 20px;
  font-size: 18px;
  line-height: 1;
  font-weight: 600;
  color: var(--primary-text-color);
  text-align: center;
  overflow: hidden;
}

.compare-page-wrapper {
  --compare-header-height: 56px;
  --compare-header-offset: calc(var(--compare-header-height) + env(safe-area-inset-top));
  // top: 0;
  // left: 0;
  // position: absolute;
  width: 100%;
  height: 100vh;
  z-index: 1000;
  overflow-x: hidden;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  display: flex;
  flex-direction: column;
  align-items: center;
  background: var(--background-color);
  .cmviewRef {
    width: 100%;
  }
  @media screen and (min-width: 768px) {
    .compare-page-header,
    .compare-page-body,
    .cmviewRef {
      width: 85%;
      max-width: 800px;
    }
  }
  
  @media screen and (min-width: 900px) {
    .compare-page-header,
    .compare-page-body,
    .cmviewRef {
      width: 80%;
      max-width: 900px;
    }
  }
  
  @media screen and (min-width: 1200px) {
    .compare-page-header,
    .compare-page-body,
    .cmviewRef {
      width: 75%;
      max-width: 1000px;
    }
  }
}

.compare-page-wrapper-overlay {
  position: fixed;
  inset: 0;
  width: 100vw;
}

.divider,
.divider::before,
.divider::after {
  color: var(--lowest-text-color);
  border-color: var(--lowest-text-color);
}
.input-wrapper {
  display: flex;
  align-items: center;

  > view.nut-textarea {
    background: transparent;
    padding: 8px 12px;
    // border-bottom: 1px solid;
    color: var(--second-text-color);
    border-color: var(--lowest-text-color);

    :deep(textarea) {
      color: inherit;
    }
  }
}
</style>
