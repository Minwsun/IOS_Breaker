import { nextTick } from 'vue';
import { useEnvApi } from '@/api/env';

import AppLayout from '@/layout/AppLayout.vue';
import { useGlobalStore } from '@/store/global';
import { useSubsStore } from '@/store/subs';
import { useAppNotifyStore } from '@/store/appNotify';
import { initStores } from '@/utils/initApp';
import { isDynamicImportFailure, resetPwaCacheAndReload } from '@/utils/pwa';
import My from '@/views/My.vue';
import i18n from '@/locales';

import File from '@/views/File.vue';
import Sub from '@/views/Sub.vue';
import Sync from '@/views/Sync.vue';

// import editScript from '@/views/editCode/editScript.vue';
// import themeSetting from '@/views/themeSetting.vue';

import { Dialog, Toast } from '@nutui/nutui';
import { toRaw } from 'vue';
import 'vue-router';
import { createRouter, createWebHistory } from 'vue-router';

// import { SwipeBack } from 'vue-swipe-back'

let globalStore = null;
let pwaRefreshDialogVisible = false;
const { t: i18nGlobal } = i18n.global;

const scrollContainers = ['#app', '.app-layout-wrapper', '.page-body'];

const isTabRoute = (route?: { meta?: { needTabBar?: boolean } }) => route?.meta?.needTabBar === true;

const isTabSwitch = (
  to?: { path?: string; meta?: { needTabBar?: boolean } },
  from?: { path?: string; meta?: { needTabBar?: boolean } },
) => Boolean(to?.path && from?.path && to.path !== from.path && isTabRoute(to) && isTabRoute(from));

const resetDocumentScrollStyles = () => {
  ['html', 'body', '#app'].forEach(selector => {
    const element = document.querySelector(selector) as HTMLElement | null;

    if (!element) return;

    element.style['overflow-y'] = '';
    element.style.height = '';
  });
};

const getElementScrollTop = (selector: string) => {
  return (document.querySelector(selector) as HTMLElement | null)?.scrollTop || 0;
};

const getCurrentScrollTop = () => {
  return document.documentElement.scrollTop
    || document.body.scrollTop
    || getElementScrollTop('#app')
    || getElementScrollTop('.app-layout-wrapper')
    || getElementScrollTop('.page-body')
    || 0;
};

const scrollToPosition = (top = 0) => {
  window.scrollTo({ left: 0, top, behavior: "instant" as any });
  document.documentElement.scrollTop = top;
  document.body.scrollTop = top;

  scrollContainers.forEach(selector => {
    document.querySelector(selector)?.scrollTo?.({ left: 0, top });
  });
};

const resetPwaRefreshDialogVisible = () => {
  pwaRefreshDialogVisible = false;
};

declare module 'vue-router' {
  interface RouteMeta {
    title: string;
    needTabBar: boolean;
    needNavBack: boolean;
    supportsListViewMode?: boolean;
    supportsListSearch?: boolean;
    hideSideBarInWideScreenNarrowMode?: boolean;
  }
}

const history = createWebHistory();
const router = createRouter({
  // scrollBehavior(to, from, savedPosition) {
  //   // console.log(`scrollBehavior ${from.path} => ${to.path}`)
  //   document.querySelector('html').style['overflow-y'] = '';
  //   document.querySelector('html').style.height = '';
  //   document.body.style.height = '';
  //   document.body.style['overflow-y'] = '';
  //   (document.querySelector('#app') as HTMLElement).style['overflow-y'] = '';
  //   (document.querySelector('#app') as HTMLElement).style.height = '';

  //   if (to.hash) {
  //     return {
  //       el: to.hash,
  //       behavior: 'smooth',
  //     }
  //   }
  //   if (globalStore !== null) {
  //     const savedPositions = toRaw(globalStore.savedPositions);
  //     if (savedPositions[to.path]) {
  //       // console.log(`读取到 ${to.path} 保存的滚动位置：${savedPositions[to.path]?.top}`)
  //       return savedPositions[to.path]
  //     }
  //   }
  //   if (savedPosition) {
  //     // console.log(`接受到 ${to.path} savedPosition 滚动位置：${savedPosition?.top}`)
  //     return savedPosition
  //   } else {
  //     return { top: 0, left: 0 }
  //   }
  // },
  history,
  routes: [
    {
      path: '/',
      component: AppLayout,
      redirect: '/subs',
      children: [
        {
          path: '/subs',
          component: Sub,
          meta: {
            title: 'sub',
            needTabBar: true,
            needNavBack: false,
            supportsListViewMode: true,
            supportsListSearch: true,
          },
        },
        {
          path: '/sync',
          component: Sync,
          meta: {
            title: 'sync',
            needTabBar: true,
            needNavBack: false,
            supportsListViewMode: true,
            supportsListSearch: true,
          },
        },
        {
          path: '/my',
          component: My,
          meta: {
            title: 'my',
            needTabBar: true,
            needNavBack: false,
          },
        },
        {
          path: '/files',
          component: File,
          meta: {
            title: 'file',
            needTabBar: true,
            needNavBack: false,
            supportsListViewMode: true,
            supportsListSearch: true,
          },
        },
        {
          path: '/shares',
          component: () => import('@/views/share/Share.vue'),
          meta: {
            title: 'shareManage',
            needTabBar: true,
            needNavBack: false,
            supportsListViewMode: true,
            supportsListSearch: true,
            hideSideBarInWideScreenNarrowMode: true,
          },
        },
        {
          path: '/edit/shares/:name',
          component: () => import('@/views/share/ShareEditorPage.vue'),
          meta: {
            title: 'shareEditor',
            needTabBar: false,
            needNavBack: true,
          },
        },
        {
          path: '/archives',
          component: () => import('@/views/archive/Archive.vue'),
          meta: {
            title: 'archive',
            needTabBar: false,
            needNavBack: true,
            supportsListViewMode: true,
            supportsListSearch: true,
            hideSideBarInWideScreenNarrowMode: true,
          },
        },
        {
          path: '/logs',
          component: () => import('@/views/Logs.vue'),
          meta: {
            title: 'logs',
            needTabBar: false,
            needNavBack: true,
            hideSideBarInWideScreenNarrowMode: true,
          },
        },
        // {
        //   path: '/edit/Script/:id',
        //   component: editScript,
        //   meta: {
        //     title: 'editScript',
        //     needTabBar: false,
        //     needNavBack: true,
        //   },
        // },
        {
          path: '/preview',
          component: () => import('@/views/FilePreview.vue'),
          meta: {
            title: 'preview',
            needTabBar: false,
            needNavBack: false,
          },
        },
        {
          path: '/edit/:editType(files)/:id',
          component: () => import('@/views/FileEditor.vue'),
          meta: {
            title: 'fileEditor',
            needTabBar: false,
            needNavBack: true,
          },
        },
        {
          path: '/edit/:editType(subs|collections)/:id',
          component: () => import('@/views/SubEditor.vue'),
          meta: {
            title: 'subEditor',
            needTabBar: false,
            needNavBack: true,
          },
        },
        {
          path: '/edit/sync/:id',
          component: () => import('@/views/SyncEditor.vue'),
          meta: {
            title: 'syncEditor',
            needTabBar: false,
            needNavBack: true,
          },
        },
        // {
        //   path: '/settings/theme',
        //   component: themeSetting,
        //   meta: {
        //     title: 'themeSetting',
        //     needTabBar: false,
        //     needNavBack: true,
        //   },
        // },
        {
          path: '/settings/more',
          component: () => import('@/views/settings/moreSetting.vue'),
          meta: {
            title: 'moreSetting',
            needTabBar: false,
            needNavBack: true,
            hideSideBarInWideScreenNarrowMode: true,
          },
        },
        {
          path: '/settings/api',
          component: () => import('@/views/settings/APISetting.vue'),
          meta: {
            title: 'apiSetting',
            needTabBar: false,
            needNavBack: true,
            hideSideBarInWideScreenNarrowMode: true,
          },
        },
        {
          path: '/aboutUs',
          component: () => import('@/views/settings/AboutUs.vue'),
          meta: {
            title: 'aboutUs',
            needTabBar: false,
            needNavBack: true,
            hideSideBarInWideScreenNarrowMode: true,
          },
        },
      ],
    },
    {
      path: '/404',
      component: () => import('@/views/NotFound.vue'),
      meta: {
        title: 'notFound',
        needTabBar: false,
        needNavBack: true,
      },
    },
    {
      path: '/:pathMatch(.*)',
      component: () => import('@/views/NotFound.vue'),
      meta: {
        title: 'notFound',
        needTabBar: false,
        needNavBack: true,
      },
    },
  ],
});

router.onError((error) => {
  if (!isDynamicImportFailure(error) || pwaRefreshDialogVisible) {
    return;
  }

  pwaRefreshDialogVisible = true;
  Dialog({
    title: i18nGlobal("globalNotify.refresh.dynamicImportFailedTitle"),
    content: i18nGlobal("globalNotify.refresh.dynamicImportFailedContent"),
    popClass: "auto-dialog",
    textAlign: "left",
    okText: i18nGlobal("globalNotify.refresh.reloadNow"),
    cancelText: i18nGlobal("globalNotify.refresh.backHome"),
    closeOnPopstate: true,
    closeOnClickOverlay: false,
    lockScroll: false,
    beforeClose: () => {
      resetPwaRefreshDialogVisible();
      return true;
    },
    onClosed: resetPwaRefreshDialogVisible,
    onCancel: async () => {
      resetPwaRefreshDialogVisible();
      await router.replace("/");
    },
    onOk: async () => {
      resetPwaRefreshDialogVisible();
      await resetPwaCacheAndReload({
        notify: useAppNotifyStore().showNotify,
        t: i18nGlobal,
      });
    },
  });
});

// 全局前置守卫
router.afterEach(async (to, from) => {
  resetDocumentScrollStyles();
  // console.log(`afterEach ${from.path} => ${to.path}`)
  if (to?.path && from?.path !== to?.path) {
    const shouldResetTabScroll = isTabSwitch(to, from);
    let scrollTop = 0;
    if (to?.meta?.needTabBar && globalStore !== null && !shouldResetTabScroll) {
      const savedPositions = toRaw(globalStore.savedPositions);
      if (savedPositions[to.path]?.top) {
        scrollTop = savedPositions[to.path]?.top
        // console.log(`读取到 ${to.path} 保存的滚动位置：${scrollTop}`)
      }
    }
    // console.log(`${to.path} 滚动到：${scrollTop}`)
    await nextTick()
    scrollToPosition(scrollTop);

    if (shouldResetTabScroll) {
      requestAnimationFrame(() => scrollToPosition(0));
    }
  }
});
router.beforeEach((to, from) => {
  document.title = 'Sub-Store';
  // console.log(`beforeEach ${from.path} => ${to.path}`)
  if (to?.path !== '/subs') {
    useSubsStore().cancelFetchFlows();
  }
  if (!globalStore) {
    globalStore = useGlobalStore();
  }
  if (globalStore) {
    if (from?.meta?.needTabBar && from?.path !== to?.path) {
      // if (from?.meta?.needTabBar) {
        const scrollTop = isTabSwitch(to, from) ? 0 : getCurrentScrollTop();
        // console.log(`保存 ${from.path} 滚动位置：${scrollTop}`)
        globalStore.setSavedPositions(from.path, { left: 0, top: scrollTop })
      }
  }
  return true
})
router.beforeResolve(async (to, from) => {
  // document.body.classList.remove('nut-overflow-hidden');
  if (!globalStore) {
    globalStore = useGlobalStore();
  }
  // 路由跳转时查询环境，决定是否更新数据
  if (globalStore !== null) {
    const storeEnv = toRaw(globalStore.env);
    if (storeEnv?.backend && storeEnv?.version) {
      useEnvApi()
      .getEnv()
      .then(async res => {
        const envNow = res;
        if (envNow?.data?.status === 'success') {
          const backend = envNow.data.data.backend;
          const version = envNow.data.data.version;
          const hasNewVersion = envNow.data.data.hasNewVersion;
          const latestVersion = envNow.data.data.latestVersion;
          if (backend !== storeEnv.backend || version !== storeEnv.version) {
            Toast.loading('检测到后端变化，更新数据中...', {
              cover: true,
              id: 'fetchLoading',
            });
            await initStores(false, true, true);
            Toast.hide('fetchLoading');
          }
        }
      });
    }
  } else {
    globalStore = useGlobalStore();
  }

  // console.log(`beforeResolve ${from.path} => ${to.path}`)
  // if (to?.path && from?.path !== to?.path) {
  //   let scrollTop = 0;
  //   if (to?.meta?.needTabBar && globalStore !== null) {
  //     const savedPositions = toRaw(globalStore.savedPositions);
  //     if (savedPositions[to.path]?.top) {
  //       scrollTop = savedPositions[to.path]?.top
  //       console.log(`读取到 ${to.path} 保存的滚动位置：${scrollTop}`)
  //     }
  //   }
  //   console.log(`${to.path} 滚动到：${scrollTop}`)
  //   window.scrollTo({
  //     top: 1000,
  //     behavior: "instant" as any
  //   });
  // }
  // 允许跳转
  return true;
});

export default router;
