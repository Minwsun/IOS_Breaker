import { useSettingsApi } from "@/api/settings";
import i18n from "@/locales";
import { useGlobalStore } from '@/store/global';
import { useAppNotifyStore } from "@/store/appNotify";
import { DEFAULT_IMAGE_FIT, normalizeImageFit } from "@/utils/iconFit";
import { runFrontendRequestTask } from "@/utils/requestConcurrency";
import { Toast } from "@nutui/nutui";
import { defineStore } from "pinia";
// import { useEnvApi } from '@/api/env';
// import { useSubsStore } from '@/store/subs';

const settingsApi = useSettingsApi();
const { t } = i18n.global;
const LIST_PAGE_VIEW_MODE_STORAGE_KEY = "appearanceSetting.listPageViewMode";
const NARROW_MODE_LIST_PAGE_VIEW_MODE_STORAGE_KEY = "appearanceSetting.listPageViewModeInWideScreenNarrowMode";
const WIDE_SCREEN_NARROW_MODE_STORAGE_KEY = "appearanceSetting.useNarrowModeOnWideScreen";
const EDITOR_GROUPING_MODE_STORAGE_KEY = "appearanceSetting.editorGroupingMode";
const SIMPLE_MODE_CACHE_STORAGE_KEY = "appearanceSetting.isSimpleMode";
const TAB_BAR_CACHE_STORAGE_KEY = "appearanceSetting.istabBar";
const TAB_BAR2_CACHE_STORAGE_KEY = "appearanceSetting.istabBar2";
const TAB_BAR3_CACHE_STORAGE_KEY = "appearanceSetting.istabBar3";
const LEGACY_APPEARANCE_STORAGE_KEYS = [
  "isSimpleMode",
  "isLr",
  "iconColor",
  "isDefaultIcon",
  "iseditorCommon",
  "isSimpleReicon",
  "showFloatingRefreshButton",
  "istabBar",
  "istabBar2",
  "subProgressStyle",
];

const normalizeSettingInputValue = (value: unknown) => {
  return value === null || value === undefined ? "" : String(value);
};

const getSettingsErrorMessage = (data?: MyAxiosRes) => {
  return data?.status === "failed" ? data.error?.message : "";
};

export const normalizeGistDownloadTokenStrategy = (
  value: unknown,
): DownloadTokenStrategy => {
  return value === "overwrite" || value === "keep" || value === "ask"
    ? value
    : "ask";
};

const createAppearanceSettingPatch = (
  next?: SettingsPostData["appearanceSetting"],
  current?: SettingsPostData["appearanceSetting"],
  options?: {
    forceEditorGroupingMode?: boolean;
  },
) => {
  if (!next) return next;

  const patch: SettingsPostData["appearanceSetting"] = {};
  (Object.keys(next) as Array<keyof NonNullable<SettingsPostData["appearanceSetting"]>>).forEach((key) => {
    if (next[key] !== current?.[key]) {
      Object.assign(patch, { [key]: next[key] });
    }
  });
  if (options?.forceEditorGroupingMode && isEditorGroupingMode(next.editorGroupingMode)) {
    patch.editorGroupingMode = next.editorGroupingMode;
  }

  return patch;
};

const getCachedListPageViewMode = (storageKey: string): ListPageViewMode | undefined => {
  const cachedMode = localStorage.getItem(storageKey);
  if (cachedMode === "single-column" || cachedMode === "dual-column") {
    return cachedMode;
  }

  return undefined;
};

const syncCachedListPageViewMode = (storageKey: string, mode?: ListPageViewMode) => {
  if (mode) {
    localStorage.setItem(storageKey, mode);
  } else {
    localStorage.removeItem(storageKey);
  }
};

const isEditorGroupingMode = (value: unknown): value is EditorGroupingMode => {
  return value === "edit-only" || value === "disabled" || value === "always";
};

const getCachedEditorGroupingMode = (): EditorGroupingMode | undefined => {
  const cachedMode = localStorage.getItem(EDITOR_GROUPING_MODE_STORAGE_KEY);
  return isEditorGroupingMode(cachedMode) ? cachedMode : undefined;
};

const syncCachedEditorGroupingMode = (mode?: EditorGroupingMode) => {
  if (mode) {
    localStorage.setItem(EDITOR_GROUPING_MODE_STORAGE_KEY, mode);
  } else {
    localStorage.removeItem(EDITOR_GROUPING_MODE_STORAGE_KEY);
  }
};

const getCachedAppearanceBoolean = (storageKey: string, legacyStorageKey: string) => {
  const cachedValue = localStorage.getItem(storageKey);
  if (cachedValue === "1") return true;
  if (cachedValue === "0") return false;

  const legacyValue = localStorage.getItem(legacyStorageKey);
  if (legacyValue === "1") return true;

  return undefined;
};

const getCachedSimpleMode = () => {
  const cachedValue = getCachedAppearanceBoolean(SIMPLE_MODE_CACHE_STORAGE_KEY, "isSimpleMode");
  if (cachedValue !== undefined) return cachedValue;

  return localStorage.getItem("isSimpleMode") === "0" ? false : undefined;
};

const hasCachedAppearanceNavigationSetting = () => {
  return getCachedAppearanceBoolean(TAB_BAR_CACHE_STORAGE_KEY, "istabBar") !== undefined
    || getCachedAppearanceBoolean(TAB_BAR2_CACHE_STORAGE_KEY, "istabBar2") !== undefined
    || getCachedAppearanceBoolean(TAB_BAR3_CACHE_STORAGE_KEY, "istabBar3") !== undefined;
};

const syncCachedAppearanceNavigationSetting = (
  appearanceSetting: SettingsPostData["appearanceSetting"],
) => {
  localStorage.setItem(TAB_BAR_CACHE_STORAGE_KEY, appearanceSetting?.istabBar ? "1" : "0");
  localStorage.setItem(TAB_BAR2_CACHE_STORAGE_KEY, appearanceSetting?.istabBar2 ? "1" : "0");
  localStorage.setItem(TAB_BAR3_CACHE_STORAGE_KEY, appearanceSetting?.istabBar3 ? "1" : "0");
};

const getCachedWideScreenNarrowMode = () => {
  return localStorage.getItem(WIDE_SCREEN_NARROW_MODE_STORAGE_KEY) === "1";
};

const hasLocalAppearanceSetting = () => {
  return LEGACY_APPEARANCE_STORAGE_KEYS.some((key) => localStorage.getItem(key) !== null)
    || getCachedAppearanceBoolean(TAB_BAR3_CACHE_STORAGE_KEY, "istabBar3") !== undefined;
};

const hasRemoteAppearanceSetting = (appearanceSetting?: SettingsPostData["appearanceSetting"]) => {
  return Boolean(appearanceSetting && Object.keys(appearanceSetting).length > 0);
};

const hasRemoteEditorGroupingMode = (appearanceSetting?: SettingsPostData["appearanceSetting"]) => {
  return isEditorGroupingMode(appearanceSetting?.editorGroupingMode);
};

const isEditorCommonDisplayMode = (value: unknown): value is EditorCommonDisplayMode => {
  return value === "expanded" || value === "collapsed" || value === "hidden";
};

const isEditorSectionFoldMode = (value: unknown): value is EditorSectionFoldMode => {
  return value === "expanded" || value === "collapsed";
};

const isActionButtonsDisplayMode = (value: unknown): value is ActionButtonsDisplayMode => {
  return value === "responsive" || value === "compact" || value === "loose";
};

const normalizeEditorCommonDisplayMode = (
  appearanceSetting?: SettingsPostData["appearanceSetting"],
): EditorCommonDisplayMode => {
  if (isEditorCommonDisplayMode(appearanceSetting?.editorCommonDisplayMode)) {
    return appearanceSetting.editorCommonDisplayMode;
  }

  if (typeof appearanceSetting?.isEditorCommon === "boolean") {
    return appearanceSetting.isEditorCommon ? "expanded" : "hidden";
  }

  return "expanded";
};

const normalizeManualSubscriptionsDisplayMode = (
  appearanceSetting?: SettingsPostData["appearanceSetting"],
): EditorSectionFoldMode => {
  if (isEditorSectionFoldMode(appearanceSetting?.manualSubscriptionsDisplayMode)) {
    return appearanceSetting.manualSubscriptionsDisplayMode;
  }

  return "collapsed";
};

const normalizeActionButtonsDisplayMode = (
  appearanceSetting?: SettingsPostData["appearanceSetting"],
): ActionButtonsDisplayMode => {
  if (isActionButtonsDisplayMode(appearanceSetting?.actionButtonsDisplayMode)) {
    return appearanceSetting.actionButtonsDisplayMode;
  }

  return "responsive";
};

const normalizeEditorGroupingMode = (
  appearanceSetting?: SettingsPostData["appearanceSetting"],
): EditorGroupingMode => {
  if (isEditorGroupingMode(appearanceSetting?.editorGroupingMode)) {
    return appearanceSetting.editorGroupingMode;
  }

  return getCachedEditorGroupingMode() ?? "edit-only";
};

export const useSettingsStore = defineStore("settingsStore", {
  state: (): SettingsStoreState => {
    return {
      syncPlatform: "",
      gistToken: "",
      ageSecretKey: "",
      githubProxy: "",
      githubApiUrl: "",
      githubApiTimeout: "",
      artifactSyncBatchSize: "",
      githubProxyRegex: "",
      githubUser: "",
      defaultUserAgent: "",
      defaultFlowUserAgent: "",
      defaultProxy: "",
      defaultTimeout: "",
      backendRequestConcurrency: "",
      backendRequestConcurrencyWaitTime: "",
      cacheThreshold: "",
      resourceCacheTtl: "",
      headersCacheTtl: "",
      scriptCacheTtl: "",
      logsMaxCount: "",
      syncTime: 0,
      theme: {
        auto: true,
        name: "light",
        dark: "dark",
        light: "light",
      },
      appearanceSetting: {
        isSimpleMode: getCachedSimpleMode() ?? true,
        isLeftRight: false,
        isDefaultIcon: false,
        isIconColor: false,
        isShowIcon: true,
        iconFit: DEFAULT_IMAGE_FIT,
        isSimpleShowRemark: false,
        isEditorCommon: true,
        editorCommonDisplayMode: "expanded",
        manualSubscriptionsDisplayMode: "collapsed",
        editorGroupingMode: getCachedEditorGroupingMode() ?? "edit-only",
        actionButtonsDisplayMode: "responsive",
        isSimpleReicon: false,
        isSubItemMenuFold: true,
        showFloatingRefreshButton: false,
        showFloatingAddButton: false,
        createItemPosition: "bottom",
        displayPreviewInWebPage: true,
        invalidShareFakeNode: false,
        istabBar: getCachedAppearanceBoolean(TAB_BAR_CACHE_STORAGE_KEY, "istabBar") ?? false,
        istabBar2: getCachedAppearanceBoolean(TAB_BAR2_CACHE_STORAGE_KEY, "istabBar2") ?? false,
        istabBar3: getCachedAppearanceBoolean(TAB_BAR3_CACHE_STORAGE_KEY, "istabBar3") ?? false,
        subProgressStyle: "hidden",
        hidePublicLinkActionButton: false,
        listPageViewMode: getCachedListPageViewMode(LIST_PAGE_VIEW_MODE_STORAGE_KEY),
        listPageViewModeInWideScreenNarrowMode: getCachedListPageViewMode(NARROW_MODE_LIST_PAGE_VIEW_MODE_STORAGE_KEY),
        useNarrowModeOnWideScreen: getCachedWideScreenNarrowMode(),
      },
      gistUpload: "base64",
      gistDownloadTokenStrategy: "ask",
      avatarUrl: "",
      artifactStore: "",
      artifactStoreStatus: "",
      hasFetchedSettings: false,
      hasRemoteAppearanceSetting: false,
      hasRemoteEditorGroupingMode: false,
      hasCachedEditorGroupingMode: getCachedEditorGroupingMode() !== undefined,
      hasCachedAppearanceNavigationSetting: hasCachedAppearanceNavigationSetting(),
      // ishostApi: localStorage.getItem('hostApi'),
    };
  },
  getters: {},
  actions: {
    applyAppearanceSetting(
      appearanceSetting?: SettingsPostData["appearanceSetting"],
      options?: {
        cacheEditorGroupingMode?: boolean;
      },
    ) {
      const cachedNarrowModeListPageViewMode = getCachedListPageViewMode(
        NARROW_MODE_LIST_PAGE_VIEW_MODE_STORAGE_KEY,
      );
      const hasInputEditorGroupingMode = hasRemoteEditorGroupingMode(appearanceSetting);
      const editorCommonDisplayMode = normalizeEditorCommonDisplayMode(appearanceSetting);
      const manualSubscriptionsDisplayMode = normalizeManualSubscriptionsDisplayMode(appearanceSetting);
      const editorGroupingMode = normalizeEditorGroupingMode(appearanceSetting);
      const actionButtonsDisplayMode = normalizeActionButtonsDisplayMode(appearanceSetting);

      this.appearanceSetting.isSimpleMode =
        appearanceSetting?.isSimpleMode
        ?? getCachedSimpleMode()
        ?? true;
      this.appearanceSetting.isLeftRight = appearanceSetting?.isLeftRight ?? "";
      this.appearanceSetting.isDefaultIcon = appearanceSetting?.isDefaultIcon ?? "";
      this.appearanceSetting.isIconColor = appearanceSetting?.isIconColor ?? "";
      this.appearanceSetting.isShowIcon = appearanceSetting?.isShowIcon ?? true;
      this.appearanceSetting.iconFit = normalizeImageFit(appearanceSetting?.iconFit);
      this.appearanceSetting.isSimpleShowRemark = appearanceSetting?.isSimpleShowRemark ?? "";
      this.appearanceSetting.editorCommonDisplayMode = editorCommonDisplayMode;
      this.appearanceSetting.manualSubscriptionsDisplayMode = manualSubscriptionsDisplayMode;
      this.appearanceSetting.editorGroupingMode = editorGroupingMode;
      this.appearanceSetting.actionButtonsDisplayMode = actionButtonsDisplayMode;
      this.appearanceSetting.isEditorCommon = editorCommonDisplayMode !== "hidden";
      this.appearanceSetting.isSimpleReicon = appearanceSetting?.isSimpleReicon ?? "";
      this.appearanceSetting.isSubItemMenuFold = appearanceSetting?.isSubItemMenuFold ?? true;
      this.appearanceSetting.showFloatingRefreshButton = appearanceSetting?.showFloatingRefreshButton ?? "";
      this.appearanceSetting.showFloatingAddButton = appearanceSetting?.showFloatingAddButton ?? false;
      this.appearanceSetting.createItemPosition = appearanceSetting?.createItemPosition ?? "bottom";
      this.appearanceSetting.displayPreviewInWebPage = appearanceSetting?.displayPreviewInWebPage ?? true;
      this.appearanceSetting.invalidShareFakeNode = appearanceSetting?.invalidShareFakeNode ?? false;
      this.appearanceSetting.istabBar = appearanceSetting?.istabBar ?? "";
      this.appearanceSetting.istabBar2 = appearanceSetting?.istabBar2 ?? "";
      this.appearanceSetting.istabBar3 = appearanceSetting?.istabBar3 ?? false;
      this.appearanceSetting.subProgressStyle = appearanceSetting?.subProgressStyle ?? "hidden";
      this.appearanceSetting.hidePublicLinkActionButton = appearanceSetting?.hidePublicLinkActionButton ?? false;
      this.appearanceSetting.listPageViewMode = appearanceSetting?.listPageViewMode;
      this.appearanceSetting.listPageViewModeInWideScreenNarrowMode =
        appearanceSetting?.listPageViewModeInWideScreenNarrowMode ?? cachedNarrowModeListPageViewMode;
      this.appearanceSetting.useNarrowModeOnWideScreen = appearanceSetting?.useNarrowModeOnWideScreen ?? false;

      syncCachedListPageViewMode(LIST_PAGE_VIEW_MODE_STORAGE_KEY, this.appearanceSetting.listPageViewMode);
      syncCachedListPageViewMode(
        NARROW_MODE_LIST_PAGE_VIEW_MODE_STORAGE_KEY,
        this.appearanceSetting.listPageViewModeInWideScreenNarrowMode,
      );
      localStorage.setItem(
        SIMPLE_MODE_CACHE_STORAGE_KEY,
        this.appearanceSetting.isSimpleMode ? "1" : "0",
      );

      if (this.appearanceSetting.useNarrowModeOnWideScreen) {
        localStorage.setItem(WIDE_SCREEN_NARROW_MODE_STORAGE_KEY, "1");
      } else {
        localStorage.removeItem(WIDE_SCREEN_NARROW_MODE_STORAGE_KEY);
      }

      syncCachedAppearanceNavigationSetting(this.appearanceSetting);
      if (options?.cacheEditorGroupingMode ?? (hasInputEditorGroupingMode || this.hasCachedEditorGroupingMode)) {
        syncCachedEditorGroupingMode(this.appearanceSetting.editorGroupingMode);
        this.hasCachedEditorGroupingMode = true;
      }
      this.hasCachedAppearanceNavigationSetting = true;
    },
    async fetchSettings() {
      const { showNotify } = useAppNotifyStore();
      const res = await runFrontendRequestTask(() => settingsApi.getSettings(), "settings.getSettings");
      if (res?.data?.status === "success" && res?.data?.data) {
        this.syncPlatform = res.data.data.syncPlatform || "";
        this.gistToken = res.data.data.gistToken || "";
        this.ageSecretKey = res.data.data["age-secret-key"] || "";
        this.githubProxy = res.data.data.githubProxy || "";
        this.githubApiUrl = normalizeSettingInputValue(res.data.data.githubApiUrl);
        this.githubApiTimeout = normalizeSettingInputValue(res.data.data.githubApiTimeout);
        this.artifactSyncBatchSize = normalizeSettingInputValue(res.data.data.artifactSyncBatchSize);
        this.githubProxyRegex = res.data.data.githubProxyRegex || "";
        this.githubUser = res.data.data.githubUser || "";
        this.defaultProxy = res.data.data.defaultProxy || "";
        this.defaultUserAgent = res.data.data.defaultUserAgent || "";
        this.defaultFlowUserAgent = res.data.data.defaultFlowUserAgent || "";
        this.defaultTimeout = res.data.data.defaultTimeout || "";
        this.backendRequestConcurrency = normalizeSettingInputValue(res.data.data.backendRequestConcurrency);
        this.backendRequestConcurrencyWaitTime = normalizeSettingInputValue(res.data.data.backendRequestConcurrencyWaitTime);
        this.cacheThreshold = res.data.data.cacheThreshold || "";
        this.resourceCacheTtl = res.data.data.resourceCacheTtl || "";
        this.headersCacheTtl = res.data.data.headersCacheTtl || "";
        this.scriptCacheTtl = res.data.data.scriptCacheTtl || "";
        this.logsMaxCount = normalizeSettingInputValue(res.data.data.logsMaxCount);
        this.syncTime = res.data.data.syncTime || 0;
        this.avatarUrl = res.data.data.avatarUrl || "";
        this.artifactStore = res.data.data.artifactStore || "";
        this.artifactStoreStatus = res.data.data.artifactStoreStatus || "";

        this.theme.auto = res.data.data.theme?.auto ?? true;
        this.theme.name = res.data.data.theme?.name ?? "light";
        this.theme.dark = res.data.data.theme?.dark ?? "dark";
        this.theme.light = res.data.data.theme?.light ?? "light";

        this.hasFetchedSettings = true;
        this.hasRemoteAppearanceSetting = hasRemoteAppearanceSetting(res.data.data.appearanceSetting);
        this.hasRemoteEditorGroupingMode = hasRemoteEditorGroupingMode(res.data.data.appearanceSetting);
        this.applyAppearanceSetting(res.data.data.appearanceSetting);
        this.gistUpload = res.data.data?.gistUpload ?? "base64";
        this.gistDownloadTokenStrategy = normalizeGistDownloadTokenStrategy(
          res.data.data.gistDownloadTokenStrategy,
        );
      } else {
        this.hasFetchedSettings = false;
        showNotify({
          title: `获取配置失败`,
          type: "danger",
        });
      }
    },
    async changeSettings(
      data: SettingsPostData,
      options?: { notifySuccess?: boolean },
    ) {
      const { showNotify } = useAppNotifyStore();
      const res = await settingsApi.setSettings(data);
      if (res?.data?.status === "success" && res?.data?.data) {
        this.syncPlatform = res.data.data.syncPlatform || "";
        this.gistToken = res.data.data.gistToken || "";
        this.ageSecretKey = res.data.data["age-secret-key"] || "";
        this.githubProxy = res.data.data.githubProxy || "";
        this.githubApiUrl = normalizeSettingInputValue(res.data.data.githubApiUrl);
        this.githubApiTimeout = normalizeSettingInputValue(res.data.data.githubApiTimeout);
        this.artifactSyncBatchSize = normalizeSettingInputValue(res.data.data.artifactSyncBatchSize);
        this.githubProxyRegex = res.data.data.githubProxyRegex || "";
        this.githubUser = res.data.data.githubUser || "";
        this.defaultProxy = res.data.data.defaultProxy || "";
        this.defaultUserAgent = res.data.data.defaultUserAgent || "";
        this.defaultFlowUserAgent = res.data.data.defaultFlowUserAgent || "";
        this.defaultTimeout = res.data.data.defaultTimeout || "";
        this.backendRequestConcurrency = normalizeSettingInputValue(res.data.data.backendRequestConcurrency);
        this.backendRequestConcurrencyWaitTime = normalizeSettingInputValue(res.data.data.backendRequestConcurrencyWaitTime);
        this.cacheThreshold = res.data.data.cacheThreshold || "";
        this.resourceCacheTtl = res.data.data.resourceCacheTtl || "";
        this.headersCacheTtl = res.data.data.headersCacheTtl || "";
        this.scriptCacheTtl = res.data.data.scriptCacheTtl || "";
        this.logsMaxCount = normalizeSettingInputValue(res.data.data.logsMaxCount);
        this.avatarUrl = res.data.data.avatarUrl || "";
        this.artifactStore = res.data.data.artifactStore || "";
        this.artifactStoreStatus = res.data.data.artifactStoreStatus || "";
        this.gistUpload = res.data.data.gistUpload || "base64";
        this.gistDownloadTokenStrategy = normalizeGistDownloadTokenStrategy(
          res.data.data.gistDownloadTokenStrategy,
        );
        if (options?.notifySuccess !== false) {
          showNotify({ type: "success", title: t(`myPage.notify.save.succeed`) });
        }
        return true;
      } else {
        showNotify({
          title: getSettingsErrorMessage(res?.data) || `更新配置失败`,
          type: "danger",
        });
        return false;
      }
    },
    // 备份本地配置到后端（用于兼容外观设置）
    async syncLocalAppearanceSetting() {
      const globalStore = useGlobalStore();
      const {
        isSimpleMode,
        isLeftRight,
        isIconColor,
        isDefaultIcon,
        isEditorCommon,
        isSimpleReicon,
        showFloatingRefreshButton,
        istabBar,
        istabBar2,
        subProgressStyle,
      } = globalStore;
      const hasLocalEditorCommonSetting = localStorage.getItem('iseditorCommon') !== null;
      const cachedHideShareTab = getCachedAppearanceBoolean(TAB_BAR3_CACHE_STORAGE_KEY, "istabBar3");
      const editorCommonDisplayMode = hasLocalEditorCommonSetting
        ? (isEditorCommon ? "expanded" : "hidden")
        : "expanded";
      const editorGroupingMode = this.appearanceSetting.editorGroupingMode || "edit-only";
      const hasLocalLegacyAppearanceSetting = hasLocalAppearanceSetting();
      const shouldSyncEditorGroupingMode = this.hasCachedEditorGroupingMode
        && !this.hasRemoteEditorGroupingMode
        && isEditorGroupingMode(editorGroupingMode);
      const data = {
        isSimpleMode: isSimpleMode ?? false,
        isLeftRight: isLeftRight ?? false,
        isIconColor: isIconColor ?? false,
        isDefaultIcon: isDefaultIcon ?? false,
        isEditorCommon: editorCommonDisplayMode !== "hidden",
        editorCommonDisplayMode,
        manualSubscriptionsDisplayMode: "collapsed",
        editorGroupingMode,
        isSimpleReicon: isSimpleReicon ?? false,
        showFloatingRefreshButton: showFloatingRefreshButton ?? false,
        istabBar: istabBar ?? false,
        istabBar2: istabBar2 ?? false,
        istabBar3: cachedHideShareTab ?? this.appearanceSetting.istabBar3 ?? false,
        subProgressStyle: subProgressStyle ?? "hidden",
      };
      if (!hasLocalLegacyAppearanceSetting && !shouldSyncEditorGroupingMode) {
        return;
      }

      if (!this.hasFetchedSettings) {
        return;
      }

      if (this.hasRemoteAppearanceSetting) {
        if (shouldSyncEditorGroupingMode) {
          await this.changeAppearanceSetting({ appearanceSetting: { editorGroupingMode } });
        }
        if (hasLocalLegacyAppearanceSetting && this.hasRemoteAppearanceSetting) {
          this.removeLocalAppearanceSetting();
        }
        return;
      }

      // 如果有本地持久化的外观设置且后端还没有外观设置，则将其同步到后端
      await this.changeAppearanceSetting({
        appearanceSetting: hasLocalLegacyAppearanceSetting ? data : { editorGroupingMode },
      });
      if (hasLocalLegacyAppearanceSetting && this.hasRemoteAppearanceSetting) {
        this.removeLocalAppearanceSetting();
      }
    },
    // 清除本地持久化的外观设置
    removeLocalAppearanceSetting() {
      const globalStore = useGlobalStore();
      localStorage.removeItem('isSimpleMode');
      globalStore.isSimpleMode = this.appearanceSetting.isSimpleMode ?? true;
      globalStore.setLeftRight(false);
      globalStore.setIconColor(false);
      globalStore.setIsDefaultIcon(false);
      globalStore.setEditorCommon(false);
      localStorage.removeItem('iseditorCommon');
      globalStore.isEditorCommon = true;
      globalStore.setSimpleReicon(false);
      globalStore.setShowFloatingRefreshButton(false);
      globalStore.settabBar(false);
      globalStore.settabBar2(false);
      globalStore.setSubProgressStyle('hidden');
    },
    async changeTheme(data: SettingsPostData) {
      Toast.loading("切换主题中...", { cover: true, id: "theme__loading" });
      const { showNotify } = useAppNotifyStore();
      const res = await settingsApi.setSettings(data);
      if (res?.data?.status === "success" && res?.data?.data) {
        this.theme = res.data.data.theme;
      } else {
        showNotify({
          title: `切换主题失败`,
          type: "danger",
        });
      }
      Toast.hide("theme__loading");
    },
    async changeAppearanceSetting(data: SettingsPostData) {
      Toast.loading("保存外观设置中...", { cover: true, id: "theme__loading" });
      const { showNotify } = useAppNotifyStore();
      try {
        const forceEditorGroupingMode = Boolean(
          data.appearanceSetting
          && !this.hasRemoteEditorGroupingMode
          && this.hasCachedEditorGroupingMode
          && isEditorGroupingMode(data.appearanceSetting.editorGroupingMode)
        );
        const requestData = data.appearanceSetting
          ? {
              ...data,
              appearanceSetting: createAppearanceSettingPatch(
                data.appearanceSetting,
                this.appearanceSetting,
                { forceEditorGroupingMode },
              ),
            }
          : data;
        const res = await settingsApi.setSettings(requestData);
        if (res?.data?.status === "success" && res?.data?.data) {
          const hasAppearanceSettingPatch = hasRemoteAppearanceSetting(requestData.appearanceSetting);
          const responseHasAppearanceSetting = hasRemoteAppearanceSetting(res.data.data.appearanceSetting);
          const responseHasEditorGroupingMode = hasRemoteEditorGroupingMode(res.data.data.appearanceSetting);
          const requestHasEditorGroupingMode = isEditorGroupingMode(requestData.appearanceSetting?.editorGroupingMode);
          this.hasRemoteAppearanceSetting = this.hasRemoteAppearanceSetting
            || responseHasAppearanceSetting;
          this.hasRemoteEditorGroupingMode = responseHasEditorGroupingMode;
          this.applyAppearanceSetting(
            hasAppearanceSettingPatch
              ? {
                  ...this.appearanceSetting,
                  ...requestData.appearanceSetting,
                }
              : res.data.data.appearanceSetting,
            {
              cacheEditorGroupingMode: responseHasEditorGroupingMode
                || requestHasEditorGroupingMode
                || this.hasCachedEditorGroupingMode,
            },
          );
        } else {
          showNotify({
            title: `保存外观设置失败`,
            type: "danger",
          });
        }
      } finally {
        Toast.hide("theme__loading");
      }
    },
  },
});
